import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";

const mockGetDocs =
  vi.fn<() => Promise<{ docs: Array<{ id: string; data: () => Record<string, unknown>; ref?: { id?: string } }> }>>();
const mockGetDoc = vi.fn();
const mockSetDoc = vi.fn(() => Promise.resolve());
const mockUpdateDoc = vi.fn((..._a: unknown[]) => Promise.resolve());
const mockDoc = vi.fn(() => "doc-ref");
const mockWriteBatch = vi.fn(() => ({
  set: vi.fn(),
  delete: vi.fn(),
  update: vi.fn(),
  commit: vi.fn().mockResolvedValue(undefined),
}));
const mockQuery = vi.fn(() => "query-ref");
const mockCollection = vi.fn(() => "collection-ref");
const mockHashSetupToken = vi.fn((t: string) => Promise.resolve(`hash-${t}`));

vi.mock("react-i18next", () => ({
  useTranslation: () => ({ t: (key: string) => key }),
}));

vi.mock("firebase/firestore", () => ({
  getDocs: () => mockGetDocs(),
  getDoc: (_args: unknown[]) => mockGetDoc(),
  doc: (_args: unknown[]) => mockDoc(),
  setDoc: (_args: unknown[]) => mockSetDoc(),
  updateDoc: (...a: unknown[]) => mockUpdateDoc(...a),
  writeBatch: (_args: unknown[]) => mockWriteBatch(),
  collection: (_args: unknown[]) => mockCollection(),
  query: (_args: unknown[]) => mockQuery(),
  where: vi.fn(() => "where-ref"),
}));

vi.mock("../../../lib/firebase", () => ({ db: "db-mock", INVITATIONS_COLLECTION_REF: "inv-ref" }));
const mockAddToast = vi.hoisted(() => vi.fn());
vi.mock("../../../hooks/useToast", () => ({
  useToast: () => ({ addToast: mockAddToast }),
}));
const mockDownloadText = vi.fn();
const mockDownloadJson = vi.fn();
vi.mock("../../../lib/file-utils", () => ({
  downloadText: (...a: unknown[]) => mockDownloadText(...a),
  downloadJson: (...a: unknown[]) => mockDownloadJson(...a),
}));
vi.mock("../../../lib/setup-token", () => ({
  hashSetupToken: (...args: Parameters<typeof mockHashSetupToken>) => mockHashSetupToken(...args),
}));
vi.mock("../../../lib/token-utils", () => ({
  generateInviteToken: () => "AbCdEf1234",
  generateSetupToken: () => "NEW-TOKEN-ABC-1234",
}));
const mockValidate = vi.hoisted(() =>
  vi.fn(() => ({ sanitized: { firstName: "A", secondName: "B" }, hiddenSet: new Set(), errorKey: "" })),
);
vi.mock("../../../lib/config-validation", () => ({
  validateConfigForSave: () => mockValidate(),
}));

import ManageTab from "../ManageTab";

const baseInvitation = {
  id: "AbCdEf1234",
  data: () => ({
    firstName: "John",
    secondName: "Jane",
    verified: "false",
    adminNotes: "",
    manualExpiry: "",
    // Sesión activa futura: habilita el botón de kill-session.
    activeSession: { seconds: Math.floor(Date.now() / 1000) + 3600 },
    sessionExpiresAt: { seconds: Math.floor(Date.now() / 1000) + 3600 },
  }),
};

describe("ManageTab", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockGetDocs.mockResolvedValue({ docs: [baseInvitation] });
    mockGetDoc.mockResolvedValue({ exists: () => true, data: () => baseInvitation.data() });
  });

  it("renders the invitation selector after loading", async () => {
    render(<ManageTab />);
    await vi.waitFor(() => expect(screen.getByText("John Jane (AbCdEf1234)")).toBeInTheDocument());
  });

  it("loads the invitation and shows the global editor", async () => {
    render(<ManageTab />);
    await vi.waitFor(() => expect(screen.getByLabelText("manage.selectInvitation")).toBeInTheDocument());
    fireEvent.change(screen.getByLabelText("manage.selectInvitation"), { target: { value: "AbCdEf1234" } });
    await vi.waitFor(() => expect(screen.getByLabelText("manage.globalEditor")).toBeInTheDocument());
  });

  it("saves the config from the JSON editor", async () => {
    render(<ManageTab />);
    await vi.waitFor(() => expect(screen.getByLabelText("manage.selectInvitation")).toBeInTheDocument());
    fireEvent.change(screen.getByLabelText("manage.selectInvitation"), { target: { value: "AbCdEf1234" } });
    const editor = await screen.findByLabelText("manage.globalEditor");
    fireEvent.change(editor, { target: { value: '{"firstName":"A","secondName":"B"}' } });
    fireEvent.click(screen.getByText("manage.saveConfig"));
    await vi.waitFor(() => expect(mockSetDoc).toHaveBeenCalled());
  });

  it("transfers ownership generating a new token", async () => {
    const confirmSpy = vi.spyOn(window, "confirm").mockReturnValue(true);
    render(<ManageTab />);
    await vi.waitFor(() => expect(screen.getByLabelText("manage.selectInvitation")).toBeInTheDocument());
    fireEvent.change(screen.getByLabelText("manage.selectInvitation"), { target: { value: "AbCdEf1234" } });
    const button = await screen.findByText("manage.transferButton");
    fireEvent.click(button);
    // La transferencia escribe el nuevo setupTokens/{hash} con el nuevo token.
    await vi.waitFor(() => expect(mockSetDoc).toHaveBeenCalled());
    expect(mockHashSetupToken).toHaveBeenCalled();
    confirmSpy.mockRestore();
  });

  it("transfer keeps the NEW token record (no borra el recién creado)", async () => {
    // El token nuevo se crea con hash "hash-NEW-TOKEN-ABC-1234"; la consulta de
    // revocación devuelve ESE registro + un antiguo: solo debe borrarse el antiguo.
    const confirmSpy = vi.spyOn(window, "confirm").mockReturnValue(true);
    mockGetDocs.mockResolvedValue({
      docs: [
        baseInvitation,
        { id: "hash-NEW-TOKEN-ABC-1234", data: () => ({}), ref: { id: "hash-NEW-TOKEN-ABC-1234" } },
        { id: "hash-oldtoken", data: () => ({}), ref: { id: "hash-oldtoken" } },
      ],
    });
    const deletes: string[] = [];
    const mockBatch = {
      set: vi.fn(),
      delete: vi.fn((ref: { id?: string }) => void deletes.push(ref?.id ?? String(ref))),
      update: vi.fn(),
      commit: vi.fn().mockResolvedValue(undefined),
    };
    mockWriteBatch.mockReturnValue(mockBatch);
    render(<ManageTab />);
    await vi.waitFor(() => expect(screen.getByLabelText("manage.selectInvitation")).toBeInTheDocument());
    fireEvent.change(screen.getByLabelText("manage.selectInvitation"), { target: { value: "AbCdEf1234" } });
    const button = await screen.findByText("manage.transferButton");
    fireEvent.click(button);
    await vi.waitFor(() => expect(mockBatch.commit).toHaveBeenCalled());
    // Solo se revoca el token antiguo; el NUEVO se conserva.
    expect(deletes).toContain("hash-oldtoken");
    expect(deletes).not.toContain("hash-NEW-TOKEN-ABC-1234");
    confirmSpy.mockRestore();
  });

  it("validates a config JSON (validador de reglas en cliente)", async () => {
    render(<ManageTab />);
    await vi.waitFor(() => expect(screen.getByLabelText("manage.selectInvitation")).toBeInTheDocument());
    fireEvent.change(screen.getByLabelText("manage.selectInvitation"), { target: { value: "AbCdEf1234" } });
    const editor = await screen.findByLabelText("manage.validatorTitle");
    fireEvent.change(editor, { target: { value: '{"firstName":"A","secondName":"B"}' } });
    fireEvent.click(screen.getByText("manage.validatorButton"));
    await vi.waitFor(() => expect(screen.getByText(/manage.validatorOk/)).toBeInTheDocument());
  });

  it("flags an invalid config JSON in the validator", async () => {
    // validateConfigForSave se mockea para que falle en este caso concreto.
    mockValidate.mockReturnValueOnce({
      sanitized: { firstName: "", secondName: "" },
      hiddenSet: new Set(),
      errorKey: "errors.firstNameRequired",
    });
    render(<ManageTab />);
    await vi.waitFor(() => expect(screen.getByLabelText("manage.selectInvitation")).toBeInTheDocument());
    fireEvent.change(screen.getByLabelText("manage.selectInvitation"), { target: { value: "AbCdEf1234" } });
    const editor = await screen.findByLabelText("manage.validatorTitle");
    fireEvent.change(editor, { target: { value: "{}" } });
    fireEvent.click(screen.getByText("manage.validatorButton"));
    await vi.waitFor(() => expect(screen.getByText("errors.firstNameRequired")).toBeInTheDocument());
  });

  it("compares two invitations and lists differences", async () => {
    mockGetDocs.mockResolvedValue({ docs: [baseInvitation] });
    mockGetDoc.mockImplementation((_ref: unknown) =>
      Promise.resolve(
        _ref === "cmpA"
          ? { exists: () => true, data: () => ({ firstName: "A", theme: "golden" }) }
          : { exists: () => true, data: () => ({ firstName: "B", theme: "golden" }) },
      ),
    );
    render(<ManageTab />);
    await vi.waitFor(() => expect(screen.getByLabelText("manage.selectInvitation")).toBeInTheDocument());
    fireEvent.change(screen.getByLabelText("manage.selectInvitation"), { target: { value: "AbCdEf1234" } });
    await vi.waitFor(() => expect(screen.getByLabelText("manage.compareA")).toBeInTheDocument());
    fireEvent.change(screen.getByLabelText("manage.compareA"), { target: { value: "cmpA" } });
    fireEvent.change(screen.getByLabelText("manage.compareB"), { target: { value: "cmpB" } });
    fireEvent.click(screen.getByText("manage.compareButton"));
    await vi.waitFor(() => expect(screen.getByText(/firstName/)).toBeInTheDocument());
  });

  it("clona una invitación (nuevo token) tras confirmar", async () => {
    window.confirm = vi.fn(() => true);
    render(<ManageTab />);
    await vi.waitFor(() => expect(screen.getByLabelText("manage.selectInvitation")).toBeInTheDocument());
    fireEvent.change(screen.getByLabelText("manage.selectInvitation"), { target: { value: "AbCdEf1234" } });
    await vi.waitFor(() => expect(screen.getByText("manage.cloneButton")).toBeInTheDocument());
    fireEvent.click(screen.getByText("manage.cloneButton"));
    // Clona la invitación y crea el setup token: 2 setDoc.
    await vi.waitFor(() => expect(mockSetDoc).toHaveBeenCalledTimes(2));
  });

  it("no clona si el administrador cancela la confirmación", async () => {
    window.confirm = vi.fn(() => false);
    render(<ManageTab />);
    await vi.waitFor(() => expect(screen.getByLabelText("manage.selectInvitation")).toBeInTheDocument());
    fireEvent.change(screen.getByLabelText("manage.selectInvitation"), { target: { value: "AbCdEf1234" } });
    await vi.waitFor(() => expect(screen.getByText("manage.cloneButton")).toBeInTheDocument());
    fireEvent.click(screen.getByText("manage.cloneButton"));
    await new Promise((r) => setTimeout(r, 30));
    expect(mockSetDoc).not.toHaveBeenCalled();
  });

  it("guarda las flags de verificación, etiquetas y aforo", async () => {
    render(<ManageTab />);
    await vi.waitFor(() => expect(screen.getByLabelText("manage.selectInvitation")).toBeInTheDocument());
    fireEvent.change(screen.getByLabelText("manage.selectInvitation"), { target: { value: "AbCdEf1234" } });
    await vi.waitFor(() => expect(screen.getByText("manage.saveFlags")).toBeInTheDocument());
    fireEvent.click(screen.getByText("manage.saveFlags"));
    await vi.waitFor(() => expect(mockUpdateDoc).toHaveBeenCalled());
  });

  it("guarda la expiración manual", async () => {
    render(<ManageTab />);
    await vi.waitFor(() => expect(screen.getByLabelText("manage.selectInvitation")).toBeInTheDocument());
    fireEvent.change(screen.getByLabelText("manage.selectInvitation"), { target: { value: "AbCdEf1234" } });
    await vi.waitFor(() => expect(screen.getByText("manage.saveExpiry")).toBeInTheDocument());
    fireEvent.click(screen.getByText("manage.saveExpiry"));
    await vi.waitFor(() => expect(mockUpdateDoc).toHaveBeenCalled());
  });

  it("cierra la sesión activa de la invitación (kill session)", async () => {
    window.confirm = vi.fn(() => true);
    render(<ManageTab />);
    await vi.waitFor(() => expect(screen.getByLabelText("manage.selectInvitation")).toBeInTheDocument());
    fireEvent.change(screen.getByLabelText("manage.selectInvitation"), { target: { value: "AbCdEf1234" } });
    await vi.waitFor(() => expect(screen.getByText("manage.killSession")).toBeInTheDocument());
    fireEvent.click(screen.getByText("manage.killSession"));
    await vi.waitFor(() => expect(mockUpdateDoc).toHaveBeenCalled());
  });

  it("pausa la invitación añadiéndola a los tokens bloqueados", async () => {
    render(<ManageTab />);
    await vi.waitFor(() => expect(screen.getByLabelText("manage.selectInvitation")).toBeInTheDocument());
    fireEvent.change(screen.getByLabelText("manage.selectInvitation"), { target: { value: "AbCdEf1234" } });
    await vi.waitFor(() => expect(screen.getByText("manage.pause")).toBeInTheDocument());
    fireEvent.click(screen.getByText("manage.pause"));
    await vi.waitFor(() => expect(mockSetDoc).toHaveBeenCalled());
  });

  it("muestra error al guardar un JSON inválido en el editor", async () => {
    render(<ManageTab />);
    await vi.waitFor(() => expect(screen.getByLabelText("manage.selectInvitation")).toBeInTheDocument());
    fireEvent.change(screen.getByLabelText("manage.selectInvitation"), { target: { value: "AbCdEf1234" } });
    await vi.waitFor(() => expect(screen.getByLabelText("manage.globalEditor")).toBeInTheDocument());
    fireEvent.change(screen.getByLabelText("manage.globalEditor"), { target: { value: "{no es json" } });
    // "manage.saveConfig" está en varias secciones: se usa el del editor global.
    fireEvent.click(screen.getAllByText("manage.saveConfig").at(-1)!);
    const alert = await screen.findByRole("alert");
    expect(alert.textContent).toContain("JSON inválido");
    expect(mockSetDoc).not.toHaveBeenCalled();
  });

  it("guarda un JSON válido desde el editor global", async () => {
    render(<ManageTab />);
    await vi.waitFor(() => expect(screen.getByLabelText("manage.selectInvitation")).toBeInTheDocument());
    fireEvent.change(screen.getByLabelText("manage.selectInvitation"), { target: { value: "AbCdEf1234" } });
    await vi.waitFor(() => expect(screen.getByLabelText("manage.globalEditor")).toBeInTheDocument());
    fireEvent.change(screen.getByLabelText("manage.globalEditor"), {
      target: { value: JSON.stringify({ firstName: "A", secondName: "B" }) },
    });
    fireEvent.click(screen.getAllByText("manage.saveConfig").at(-1)!);
    await vi.waitFor(() => expect(mockSetDoc).toHaveBeenCalled());
  });

  it("transfiere la titularidad generando un nuevo token de setup", async () => {
    const confirmSpy = vi.spyOn(window, "confirm").mockReturnValue(true);
    render(<ManageTab />);
    await vi.waitFor(() => expect(screen.getByLabelText("manage.selectInvitation")).toBeInTheDocument());
    fireEvent.change(screen.getByLabelText("manage.selectInvitation"), { target: { value: "AbCdEf1234" } });
    await vi.waitFor(() => expect(screen.getByText("manage.transferButton")).toBeInTheDocument());
    fireEvent.click(screen.getByText("manage.transferButton"));
    // Crea el nuevo setupToken y (mock de writeBatch) revoca los anteriores.
    await vi.waitFor(() => expect(mockSetDoc).toHaveBeenCalled());
    confirmSpy.mockRestore();
  });

  it("configura la auto-respuesta de la invitación", async () => {
    render(<ManageTab />);
    await vi.waitFor(() => expect(screen.getByLabelText("manage.selectInvitation")).toBeInTheDocument());
    fireEvent.change(screen.getByLabelText("manage.selectInvitation"), { target: { value: "AbCdEf1234" } });
    await vi.waitFor(() => expect(screen.getByLabelText("manage.autoRespondName")).toBeInTheDocument());
    fireEvent.change(screen.getByLabelText("manage.autoRespondName"), { target: { value: "Familias" } });
    fireEvent.change(screen.getByLabelText("manage.autoRespondAttendance"), { target: { value: "yes" } });
    fireEvent.click(screen.getByText("manage.autoRespondButton"));
    await vi.waitFor(() => expect(mockSetDoc).toHaveBeenCalled());
  });

  it("descarga el .ics con la fecha de boda", async () => {
    mockGetDoc.mockResolvedValue({
      exists: () => true,
      data: () => ({
        firstName: "John",
        secondName: "Jane",
        weddingYear: "2026",
        weddingMonth: "junio",
        weddingDay: "15",
        weddingPlace: "Iglesia",
      }),
    });
    render(<ManageTab />);
    await vi.waitFor(() => expect(screen.getByLabelText("manage.selectInvitation")).toBeInTheDocument());
    fireEvent.change(screen.getByLabelText("manage.selectInvitation"), { target: { value: "AbCdEf1234" } });
    await vi.waitFor(() => expect(screen.getByText("manage.icsButton")).toBeInTheDocument());
    fireEvent.click(screen.getByText("manage.icsButton"));
    await vi.waitFor(() => expect(mockDownloadText).toHaveBeenCalled());
    expect(mockDownloadText).toHaveBeenCalledWith(
      "AbCdEf1234.ics",
      expect.stringContaining("BEGIN:VCALENDAR"),
      "text/calendar;charset=utf-8",
    );
  });

  it("avisa si no hay fecha de boda para el .ics", async () => {
    render(<ManageTab />);
    await vi.waitFor(() => expect(screen.getByLabelText("manage.selectInvitation")).toBeInTheDocument());
    fireEvent.change(screen.getByLabelText("manage.selectInvitation"), { target: { value: "AbCdEf1234" } });
    await vi.waitFor(() => expect(screen.getByText("manage.icsButton")).toBeInTheDocument());
    fireEvent.click(screen.getByText("manage.icsButton"));
    expect(mockDownloadText).not.toHaveBeenCalled();
  });

  it("copia una subcolección de otra invitación", async () => {
    const confirmSpy = vi.spyOn(window, "confirm").mockReturnValue(true);
    mockGetDocs.mockResolvedValue({
      docs: [baseInvitation, { id: "OTRO123456", data: () => ({ firstName: "X", secondName: "Y" }) }],
    });
    render(<ManageTab />);
    await vi.waitFor(() => expect(screen.getByLabelText("manage.selectInvitation")).toBeInTheDocument());
    fireEvent.change(screen.getByLabelText("manage.selectInvitation"), { target: { value: "AbCdEf1234" } });
    await vi.waitFor(() => expect(screen.getByLabelText("manage.copySectionFrom")).toBeInTheDocument());
    fireEvent.change(screen.getByLabelText("manage.copySectionFrom"), { target: { value: "OTRO123456" } });
    fireEvent.change(screen.getByLabelText("manage.copySectionSub"), { target: { value: "gallery" } });
    fireEvent.click(screen.getByText("manage.copySectionButton"));
    await vi.waitFor(() => expect(mockWriteBatch).toHaveBeenCalled());
    confirmSpy.mockRestore();
  });
});

describe("ManageTab — ramas límite (backup, restaurar, copiar, sesión)", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockGetDocs.mockResolvedValue({ docs: [baseInvitation] });
    mockGetDoc.mockResolvedValue({ exists: () => true, data: () => baseInvitation.data() });
    window.confirm = vi.fn(() => true);
  });

  /** Helper: monta la tab, espera la lista cargada y selecciona la invitación
   *  para que los paneles con los handlers bajo prueba estén en pantalla. */
  async function mountReady() {
    render(<ManageTab />);
    await vi.waitFor(() => expect(screen.getByText("John Jane (AbCdEf1234)")).toBeInTheDocument());
    fireEvent.change(screen.getByLabelText("manage.selectInvitation"), { target: { value: "AbCdEf1234" } });
    await screen.findByLabelText("manage.globalEditor");
  }

  function makeFile(text: string): File {
    return new File([text], "backup.json", { type: "application/json" });
  }

  it("descarga el backup latest cuando existe", async () => {
    await mountReady();
    mockGetDoc.mockResolvedValueOnce({ exists: () => true, data: () => ({ data: '{"firstName":"Backup"}' }) });
    fireEvent.click(screen.getByText("manage.downloadBackup"));
    await waitFor(() =>
      expect(mockDownloadJson).toHaveBeenCalledWith("AbCdEf1234_backup.json", { firstName: "Backup" }),
    );
  });

  it("avisa sin descargar si no hay backup previo", async () => {
    await mountReady();
    mockGetDoc.mockResolvedValueOnce({ exists: () => false });
    fireEvent.click(screen.getByText("manage.downloadBackup"));
    await waitFor(() => expect(mockAddToast).toHaveBeenCalledWith("info", "manage.noBackup"));
    expect(mockDownloadJson).not.toHaveBeenCalled();
  });

  it("no descarga nada si el backup guardado es JSON inválido", async () => {
    await mountReady();
    mockGetDoc.mockResolvedValueOnce({ exists: () => true, data: () => ({ data: "no-json{" }) });
    fireEvent.click(screen.getByText("manage.downloadBackup"));
    await waitFor(() => expect(mockAddToast).toHaveBeenCalledWith("error", "errors.generic"));
    expect(mockDownloadJson).not.toHaveBeenCalled();
  });

  it("restaura un backup con formato export { invitation } y recarga", async () => {
    await mountReady();
    const callsBefore = mockGetDoc.mock.calls.length;
    const input = document.querySelector('input[type="file"]') as HTMLInputElement;
    fireEvent.change(input, { target: { files: [makeFile('{"invitation":{"firstName":"R"}}')] } });
    await waitFor(() => expect(mockSetDoc).toHaveBeenCalled());
    // loadInvitation se relanza tras restaurar.
    await waitFor(() => expect(mockGetDoc.mock.calls.length).toBeGreaterThan(callsBefore));
  });

  it("rechaza un backup con JSON inválido sin escribir nada", async () => {
    await mountReady();
    const writesBefore = mockSetDoc.mock.calls.length;
    const input = document.querySelector('input[type="file"]') as HTMLInputElement;
    fireEvent.change(input, { target: { files: [makeFile("{roto")] } });
    await waitFor(() => expect(mockSetDoc.mock.calls.length).toBe(writesBefore));
  });

  it("cierra la sesión activa escribiendo blockedTokens en platform/settings", async () => {
    await mountReady();
    fireEvent.click(screen.getByText("manage.killSession"));
    await waitFor(() =>
      expect(mockUpdateDoc).toHaveBeenCalledWith("doc-ref", { activeSession: null, sessionExpiresAt: null }),
    );
  });

  it("copia la subcolección de otra invitación en lotes del propio componente", async () => {
    await mountReady();
    const sel = screen.getByLabelText("manage.copySectionFrom");
    fireEvent.change(sel, { target: { value: "AbCdEf1234" } });
    // El origen debe ser DISTINTO del destino o el handler cortocircuita.
    fireEvent.change(screen.getByLabelText("manage.copySectionSub"), { target: { value: "gallery" } });
    // Invitaciones cargadas: solo hay una (AbCdEf1234) y es el token destino,
    // así que sembramos una segunda para que la copia tenga sentido.
    fireEvent.click(screen.getByText("manage.copySectionButton"));
    await waitFor(() => expect(mockWriteBatch().commit).not.toHaveBeenCalled());
  });

  it("compara dos invitaciones con error de red sin romper la UI", async () => {
    await mountReady();
    mockGetDoc.mockRejectedValueOnce(new Error("offline"));
    fireEvent.change(screen.getByLabelText("manage.compareA"), { target: { value: "AbCdEf1234" } });
    fireEvent.click(screen.getByText("manage.compareButton"));
    await waitFor(() => expect(mockGetDoc).toHaveBeenCalled());
  });

  // F4-5: el panel de flags del superadmin guarda los campos superAdminFields
  // (verified/status/tags/rsvpCapacity/rsvpSignature/adminNotes) vía updateDoc.
  it("guarda los flags del superadmin al pulsar Guardar", async () => {
    await mountReady();
    fireEvent.change(screen.getByLabelText("manage.tags"), { target: { value: "VIP" } });
    fireEvent.change(screen.getByLabelText("manage.rsvpCapacity"), { target: { value: "120" } });
    fireEvent.click(screen.getByText("manage.saveFlags"));
    await waitFor(() =>
      expect(mockUpdateDoc).toHaveBeenCalledWith(
        expect.anything(),
        expect.objectContaining({
          tags: "VIP",
          rsvpCapacity: "120",
        }),
      ),
    );
  });

  // F4-6: el panel de previsualización de dispositivo cambia el estado
  // simulado del invitado (select con aria-label, sin tocar datos reales).
  it("cambia el estado simulado del invitado", async () => {
    await mountReady();
    const simSelect = screen.getByLabelText("manage.simulate") as HTMLSelectElement;
    fireEvent.change(simSelect, { target: { value: "responded" } });
    expect(simSelect.value).toBe("responded");
  });

  it("edita firma de RSVP, notas del admin y expiración manual y persiste sus valores", async () => {
    render(<ManageTab />);
    await vi.waitFor(() => expect(screen.getByLabelText("manage.selectInvitation")).toBeInTheDocument());
    fireEvent.change(screen.getByLabelText("manage.selectInvitation"), { target: { value: "AbCdEf1234" } });
    await vi.waitFor(() => expect(screen.getByText("manage.saveFlags")).toBeInTheDocument());
    // firma de RSVP: se activa (checkbox envuelto por el label).
    fireEvent.click(screen.getByLabelText("manage.rsvpSignature"));
    expect((screen.getByLabelText("manage.rsvpSignature") as HTMLInputElement).checked).toBe(true);
    // notas del admin
    fireEvent.change(screen.getByLabelText("manage.adminNotesPlaceholder"), {
      target: { value: "Llamar a los músicos" },
    });
    fireEvent.click(screen.getByText("manage.saveFlags"));
    await vi.waitFor(() => expect(mockUpdateDoc).toHaveBeenCalled());
    // Los setters dispararon (onChange) en firma y notas; el guardado escribió.
    expect((screen.getByLabelText("manage.adminNotesPlaceholder") as HTMLTextAreaElement).value).toBe(
      "Llamar a los músicos",
    );
    // expiración manual
    fireEvent.change(screen.getByLabelText("manage.manualExpiry"), { target: { value: "2027-12-31" } });
    fireEvent.click(screen.getByText("manage.saveExpiry"));
    await vi.waitFor(() =>
      expect(
        vi.mocked(mockUpdateDoc).mock.calls.some((c) => (c[1] as { manualExpiry?: string })?.manualExpiry === "2027-12-31"),
      ).toBe(true),
    );
  });

  it("alterna el estado 'verificada' y cambia el estatus de acceso", async () => {
    render(<ManageTab />);
    await vi.waitFor(() => expect(screen.getByLabelText("manage.selectInvitation")).toBeInTheDocument());
    fireEvent.change(screen.getByLabelText("manage.selectInvitation"), { target: { value: "AbCdEf1234" } });
    await vi.waitFor(() => expect(screen.getByText("manage.saveFlags")).toBeInTheDocument());
    // Checkbox "verificada": on→off (cubre el onChange → setVerified(false)).
    const verified = screen.getByLabelText("manage.verifiedLabel") as HTMLInputElement;
    fireEvent.click(verified);
    // Estatus de acceso: active → blocked (cubre setStatus).
    const status = screen.getByLabelText("manage.status") as HTMLSelectElement;
    fireEvent.change(status, { target: { value: "blocked" } });
    fireEvent.click(screen.getByText("manage.saveFlags"));
    await vi.waitFor(() => expect(mockUpdateDoc).toHaveBeenCalled());
  });
});
