/**
 * AdminPage.jsx
 * ─────────────────────────────────────────────────────────────
 * Página de administración de la invitación de boda.
 *
 * Contiene pestañas para:
 * - Panel: Estadísticas, acciones rápidas, exportar PDF.
 * - Invitación: Formulario de edición de la configuración.
 * - Asistencia: Lista de RSVPs con filtros y búsqueda.
 * - Compartir: Enlace de invitación, WhatsApp, QR.
 * - Acceso: Gestión de tokens y sesiones.
 * - Soporte: Información de ayuda y contacto.
 *
 * Protegida: redirige a /setup si no hay configuración guardada
 * o a la invitación pública si no hay sesión de admin activa.
 *
 * @module AdminPage
 */

import { lazy, Suspense, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Navigate, useParams } from "react-router";
import { useTranslation } from "react-i18next";
import { useConfig, useAuth, useRsvpContext, useFormData, useUIMessages } from "../contexts";
import { normalizeConfig } from "../lib/normalize-config";
import { MONTH_VALUE_TO_NUMBER } from "../lib/constants";
import { useToast } from "../hooks/useToast";
import { formatDate } from "../lib/section-utils";
import { escHtml } from "../lib/utils";
import { formatMenuLabel } from "../lib/menu-utils";
import { useTabs } from "../hooks/useTabs";
import "../styles/admin.css";
import "../styles/public-shell.css";

// ─── Tabs de AdminPage (carga diferida) ────────────────────────────
const PanelTab = lazy(() => import("./admin/PanelTab"));
const AttendanceTab = lazy(() => import("./admin/AttendanceTab"));
const InvitationTab = lazy(() => import("./admin/InvitationTab"));
const AccessTab = lazy(() => import("./admin/AccessTab"));
const ShareTab = lazy(() => import("./admin/ShareTab"));
const SupportTab = lazy(() => import("./admin/SupportTab"));
const ToolsTab = lazy(() => import("./admin/ToolsTab"));
const DistribucionTab = lazy(() => import("./admin/DistribucionTab"));

/**
 * Mapa de claves de pestaña a IDs de traducción.
 */
const TAB_KEY_MAP = {
  panel: "panel",
  invitacion: "invitation",
  asistencia: "attendance",
  compartir: "share",
  herramientas: "herramientas",
  distribucion: "distribucion",
  acceso: "access",
  soporte: "support",
};

/**
 * Definición de las pestañas disponibles en el panel de admin.
 */
const TABS = [
  { key: "panel" },
  { key: "invitacion" },
  { key: "asistencia" },
  { key: "compartir" },
  { key: "herramientas" },
  { key: "distribucion" },
  { key: "acceso" },
  { key: "soporte" },
] as const;

/**
 * Página principal de administración de la boda.
 *
 * @returns {JSX.Element} Panel de administración con pestañas.
 */
export default function AdminPage() {
  const { t, i18n } = useTranslation();
  const { inviteToken } = useParams();

  // ─── Estados del contexto global (hooks granulares) ─────
  const {
    hasStoredConfig,
    isConfigLoading,
    configLoadError,
    config,
    handleDeleteInvitation,
    reloadConfig,
    visitCount,
  } = useConfig();
  // formData vive en su contexto separado (v2.185): esta página necesita el
  // borrador EN VIVO para el aviso beforeunload, pero el resto de consumidores
  // de useConfig() ya no re-renderizan por cada tecla del editor.
  const { formData } = useFormData();
  const {
    isAdminTokenLoggedIn,
    isRestoringSession,
    sessionExpired,
    clearSessionExpired,
    setupToken,
    authMessage,
    authMessageType,
    handleAdminLogout,
    handleResetTokenFromAdmin,
  } = useAuth();
  const { rsvpEntries, handleClearRsvpEntries, handleDeleteRsvpEntries, retryLoadRsvp } = useRsvpContext();
  const { adminMessage, adminMessageType, setAdminMessage, setAdminMessageType } = useUIMessages();

  // Avisa antes de salir si hay cambios sin guardar en la invitación.
  // El listener se registra UNA sola vez (se leen formData/config por ref):
  // con deps [formData, config] el efecto hacía add/remove listener en cada
  // tecla del editor.
  const formDataRef = useRef(formData);
  formDataRef.current = formData;
  const configRef = useRef(config);
  configRef.current = config;
  useEffect(() => {
    const onBeforeUnload = (e: BeforeUnloadEvent) => {
      try {
        // Se comparan los estados NORMALIZADOS: el autosave persiste con trim,
        // así que un espacio final ("Ana ") ya guardado no debe disparar el
        // aviso de "cambios sin guardar".
        const norm = (v: typeof formDataRef.current) => JSON.stringify(normalizeConfig(v));
        if (norm(formDataRef.current) !== norm(configRef.current)) {
          e.preventDefault();
          e.returnValue = "";
        }
      } catch {
        /* comparación no disponible */
      }
    };
    window.addEventListener("beforeunload", onBeforeUnload);
    return () => window.removeEventListener("beforeunload", onBeforeUnload);
  }, []);

  const { addToast } = useToast();

  // ─── Muestra mensajes de auth como toasts ──────────────
  useEffect(() => {
    if (authMessage) {
      addToast(authMessageType === "success" ? "success" : "error", authMessage);
    }
  }, [authMessage, authMessageType, addToast]);

  useEffect(() => {
    if (adminMessage) {
      addToast(adminMessageType === "error" ? "error" : "success", adminMessage);
    }
  }, [adminMessage, adminMessageType, addToast]);

  // ─── Estados locales de UI ─────────────────────────────
  // Pestaña activa sincronizada con la URL (?tab=...) en AMBOS sentidos
  // (el botón atrás del navegador también cambia de pestaña).
  const TAB_KEYS = [
    "panel",
    "invitacion",
    "asistencia",
    "compartir",
    "herramientas",
    "distribucion",
    "acceso",
    "soporte",
  ] as const;
  const { activeTab, select: handleSetTab, tabPanelRef } = useTabs(TAB_KEYS, "panel");
  const [searchQuery, setSearchQuery] = useState("");
  const [attendanceFilter, setAttendanceFilter] = useState("all");

  // Al cambiar de pestaña se vuelve arriba (comportamiento del panel admin).
  // El scroll vive en el contenedor fijo `.app-scene`, no en `window`: sin
  // esto, tras hacer scroll en una tabla larga, cambiar de pestaña dejaba el
  // panel en la misma posición.
  useEffect(() => {
    const scene = document.querySelector<HTMLElement>(".app-scene");
    if (scene) scene.scrollTo({ top: 0, behavior: "smooth" });
  }, [activeTab]);

  /**
   * Roving tabindex + flechas (ARIA tabs): mueve el foco entre pestañas
   * con ←/→/Home/End y activa la pestaña destino.
   */
  const handleTabKeyDown = useCallback(
    (e: React.KeyboardEvent<HTMLButtonElement>, key: string) => {
      const index = TABS.findIndex((t) => t.key === key);
      let nextIndex = -1;
      if (e.key === "ArrowRight") nextIndex = (index + 1) % TABS.length;
      else if (e.key === "ArrowLeft") nextIndex = (index - 1 + TABS.length) % TABS.length;
      else if (e.key === "Home") nextIndex = 0;
      else if (e.key === "End") nextIndex = TABS.length - 1;
      if (nextIndex >= 0) {
        e.preventDefault();
        const next = TABS[nextIndex]!;
        handleSetTab(next.key);
        document.getElementById("tab-" + next.key)?.focus();
      }
    },
    [handleSetTab],
  );

  /**
   * Filtra las entradas RSVP según el filtro de asistencia y la búsqueda.
   * Se recalcula cuando cambian las entradas, el filtro o la búsqueda.
   */
  const filteredEntries = useMemo(() => {
    let result = rsvpEntries;
    if (attendanceFilter === "yes") result = result.filter((e: { attendance: string }) => e.attendance === "yes");
    if (attendanceFilter === "no") result = result.filter((e: { attendance: string }) => e.attendance === "no");
    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase();
      const nameMatched = result.filter((e: { guestName: string }) => e.guestName.toLowerCase().includes(q));
      const matchedNames = new Set(nameMatched.map((e: { guestName: string }) => e.guestName.toLowerCase()));
      result = result.filter(
        (e: { guestName: string; mainGuestName?: string }) =>
          matchedNames.has(e.guestName.toLowerCase()) ||
          (e.mainGuestName && matchedNames.has(e.mainGuestName.toLowerCase())),
      );
    }
    return result;
  }, [rsvpEntries, attendanceFilter, searchQuery]);

  /** Callback memoizado para cambiar de pestaña (usado por PanelTab). */
  const setActiveTabAndFilter = useCallback(
    (tab: string) => {
      handleSetTab(tab as (typeof TAB_KEYS)[number]);
    },
    [handleSetTab],
  );

  /** Callback memoizado para cambiar el filtro de asistencia. */
  const setAttendanceFilterValue = useCallback((filter: string) => {
    setAttendanceFilter(filter);
  }, []);

  /** Nombre de la pareja formateado para mostrar en el panel. */
  const coupleName = `${config.firstName} & ${config.secondName}`;

  /**
   * Genera y abre un PDF imprimible con la lista de asistentes.
   * Crea un HTML con estilos de impresión y abre la ventana de impresión.
   */
  const exportPdf = useCallback(() => {
    // Sin respuestas filtradas no se imprime una lista vacía.
    if (!filteredEntries || filteredEntries.length === 0) {
      addToast("info", t("attendance.noResults"));
      return;
    }
    // El PDF respeta la búsqueda y el filtro de asistencia (antes imprimía
    // siempre la lista completa). Se imprimen las mismas columnas que la
    // tabla (sin acciones): nombre, acompaña a, asistencia, menú, dieta,
    // niños, intolerancias, transporte, consentimientos y fecha.
    const rows = filteredEntries
      .map((e) => {
        const niños = e.attendance === "yes" && Number(e.childrenCount) > 0 ? String(e.childrenCount) : "";
        const niñosDiet = [
          ...(Array.isArray(e.childrenAllergies) ? e.childrenAllergies : []),
          (e.childrenAllergiesOther || "").trim(),
        ]
          .filter(Boolean)
          .join(", ");
        const consentimientos = e.healthConsent ? t("attendance.consentHealth") : "";
        // Etiqueta de transporte igual que la tabla: si no hay modo es "—",
        // si es propio va la etiqueta, y si hay salida se añade la hora.
        const tipoTransporte = e.transportMode
          ? t(e.transportMode === "taxi" ? "transport.typeTaxi" : "transport.typeBus")
          : "";
        const transporte =
          e.attendance !== "yes" || (!e.transportMode && !e.transportChoice && !e.transportTime)
            ? "—"
            : !e.transportMode || e.transportMode === "own"
              ? t("attendance.transportOwnCar")
              : e.transportTime
                ? `${tipoTransporte} (${e.transportTime})`
                : tipoTransporte;
        return `<tr><td>${escHtml(e.guestName || "")}</td><td>${escHtml(
          e.mainGuestName || "",
        )}</td><td>${e.attendance === "yes" ? t("panel.attends") : t("panel.notAttends")}</td><td>${escHtml(
          e.mealChoice ? formatMenuLabel(e.mealChoice, t) : "",
        )}</td><td>${escHtml(e.dietaryInfo || "")}</td><td>${niños}</td><td>${escHtml(
          niñosDiet,
        )}</td><td>${escHtml(transporte)}</td><td>${escHtml(consentimientos)}</td><td>${escHtml(
          formatDate(e.submittedAt),
        )}</td></tr>`;
      })
      .join("");
    const tc = filteredEntries.filter((e: { attendance: string }) => e.attendance === "yes").length;
    const td = filteredEntries.filter((e: { attendance: string }) => e.attendance === "no").length;
    // HTML completo con estilos para impresión
    const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>${t("admin.pdfTitle", { name: escHtml(coupleName) })}</title><style>
      @page{margin:2cm}body{font-family:system-ui,sans-serif;font-size:12px;color:#222;padding:2rem}h1{font-size:18px;margin-bottom:4px}table{width:100%;border-collapse:collapse;margin-top:8px}th,td{border:1px solid #d4d0c8;padding:6px 8px}tr:nth-child(even){background:#faf8f5}.stats{display:flex;gap:1rem;margin:12px 0;font-size:13px}.stat{background:#f5f3ef;padding:8px 14px;border-radius:8px}@media print{body{padding:0}}
    </style></head><body>
    <h1>${t("admin.pdfTitle", { name: escHtml(coupleName) })}</h1>
    <p style="color:#666;font-size:13px">${new Date().toLocaleDateString(i18n.language, { day: "numeric", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit" })}</p>
    <div class="stats"><div class="stat">${tc} ${t("admin.pdfConfirmed")}</div><div class="stat">${td} ${t("admin.pdfNotAttending")}</div><div class="stat">${filteredEntries.length} ${t("admin.pdfResponses")}</div></div>
    <table><thead><tr><th>${t("admin.pdfTableName")}</th><th>${t("attendance.tableAccompanies")}</th><th>${t("admin.pdfTableAttendance")}</th><th>${t("attendance.tableMenu")}</th><th>${t("attendance.tableDiet")}</th><th>${t("attendance.tableChildren")}</th><th>${t("attendance.tableChildrenDiet")}</th><th>${t("attendance.tableTransport")}</th><th>${t("attendance.tableConsents")}</th><th>${t("attendance.tableDate")}</th></tr></thead><tbody>${rows}</tbody></table>
    <p style="margin-top:12px;color:#888;font-size:11px">${t("support.appTitle")}</p>
    </body></html>`;
    const blob = new Blob([html], { type: "text/html;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const w = window.open(url, "_blank");
    if (w) {
      // Abre el diálogo de impresión tras un pequeño retraso
      setTimeout(() => {
        w.focus();
        w.print();
        URL.revokeObjectURL(url);
      }, 500);
    }
  }, [filteredEntries, coupleName, t, i18n.language, addToast]);

  // ─── Cálculo de estadísticas de asistencia ─────────────
  // Memoizado: antes se recalculaban (2 filtros + 3 reduces sobre toda la
  // lista de RSVPs) en CADA render — con cientos de respuestas y renders
  // frecuentes (teclas del editor, snapshots en vivo, toasts) era trabajo
  // O(n) × N renders. Un solo recorrido en el memo.
  const {
    confirmedResponses,
    declinedResponses,
    totalGuests,
    confirmedPeople,
    declinedPeople,
  } = useMemo(() => {
    let confirmedResponses = 0;
    let declinedResponses = 0;
    let totalGuests = 0;
    let confirmedPeople = 0;
    let declinedPeople = 0;
    for (const r of rsvpEntries) {
      const attendance = (r as { attendance?: string }).attendance;
      const people = Number((r as { companions?: number }).companions) || 1;
      totalGuests += people;
      if (attendance === "yes") {
        confirmedResponses += 1;
        confirmedPeople += people;
      } else if (attendance === "no") {
        declinedResponses += 1;
        declinedPeople += people;
      }
    }
    return { confirmedResponses, declinedResponses, totalGuests, confirmedPeople, declinedPeople };
  }, [rsvpEntries]);
  const expectedGuestsTotal = Math.min(Math.max(Number(config.expectedGuests) || 0, 0), 1000);

  // Timestamp de la boda (ms) para el dashboard predictivo; null sin fecha
  // válida (se valida el rollover para no proyectar sobre una fecha errónea).
  const weddingTimestamp = useMemo(() => {
    const day = Number(config.weddingDay);
    const month = MONTH_VALUE_TO_NUMBER[config.weddingMonth as keyof typeof MONTH_VALUE_TO_NUMBER];
    const year = Number(config.weddingYear);
    if (!day || !month || !year || !Number.isFinite(day) || !Number.isFinite(year)) return null;
    // Hora "0" (medianoche) es válida y no debe tratarse como vacía (|| la
    // convertía en mediodía).
    const hour = config.weddingHour && config.weddingHour !== "" ? Number(config.weddingHour) : 12;
    const minute = config.weddingMinute && config.weddingMinute !== "" ? Number(config.weddingMinute) : 0;
    const d = new Date(year, month - 1, day, hour, minute);
    if (d.getFullYear() !== year || d.getMonth() !== month - 1 || d.getDate() !== day) return null;
    return d.getTime();
  }, [config.weddingDay, config.weddingMonth, config.weddingYear, config.weddingHour, config.weddingMinute]);

  /** Props agrupadas para PanelTab (reduce prop drilling). */
  const panelConfig = useMemo(
    () => ({
      inviteToken: inviteToken!,
      confirmedResponses,
      declinedResponses,
      totalGuests,
      confirmedPeople,
      declinedPeople,
      expectedGuests: expectedGuestsTotal,
      rsvpEntries,
      setActiveTab: setActiveTabAndFilter,
      setAttendanceFilter: setAttendanceFilterValue,
      exportPdf,
      formatDate: formatDate as (date: unknown) => string,
      onRestore: reloadConfig,
      visitCount,
      weddingTimestamp,
      exportData: config,
    }),
    [
      inviteToken,
      confirmedResponses,
      declinedResponses,
      totalGuests,
      confirmedPeople,
      declinedPeople,
      expectedGuestsTotal,
      rsvpEntries,
      setActiveTabAndFilter,
      setAttendanceFilterValue,
      exportPdf,
      reloadConfig,
      config,
      visitCount,
      weddingTimestamp,
    ],
  );

  /** Props agrupadas para AttendanceTab. */
  const attendanceConfig = useMemo(
    () => ({
      searchQuery,
      setSearchQuery,
      attendanceFilter,
      setAttendanceFilter: setAttendanceFilterValue,
      filteredEntries,
      exportPdf,
      rsvpEntries,
      handleClearRsvpEntries,
      handleDeleteRsvpEntries,
      formatDate,
      transportDepartures: config.transportDepartures,
      // El modal de edición ofrece los platos solo si el menú está activo en la invitación.
      menuEnabled: config.menuEnabled === "true",
      rsvpCapacity: typeof config.rsvpCapacity === "string" ? config.rsvpCapacity : "",
      // Invitaciones físicas: el admin puede añadir/editar respuestas a mano.
      inviteToken: inviteToken || "",
      onDataChanged: retryLoadRsvp,
    }),
    [
      searchQuery,
      setSearchQuery,
      attendanceFilter,
      setAttendanceFilterValue,
      filteredEntries,
      exportPdf,
      rsvpEntries,
      handleClearRsvpEntries,
      handleDeleteRsvpEntries,
      retryLoadRsvp,
      config.transportDepartures,
      config.menuEnabled,
      config.rsvpCapacity,
      inviteToken,
    ],
  );

  // ─── Estados de carga ──────────────────────────────────
  if (isConfigLoading) {
    return (
      <div className="setup-layout setup-layout--full">
        <section
          className="setup-card setup-card--full allow-select"
          aria-label={t("setup.loadingTitle")}
          style={{ borderRadius: "1rem" }}
        >
          <header className="setup-header">
            <div>
              <p className="setup-eyebrow">{t("setup.configTitle")}</p>
              <h1 className="setup-title">{t("setup.loadingTitle")}</h1>
              <p className="setup-subtitle">{t("admin.loadingConfig")}</p>
            </div>
          </header>
        </section>
      </div>
    );
  }

  // ─── Error de carga ────────────────────────────────────
  if (configLoadError) {
    return (
      <div className="setup-layout setup-layout--full">
        <section
          className="setup-card setup-card--full allow-select"
          aria-label={t("common.error")}
          style={{ borderRadius: "1rem" }}
        >
          <header className="setup-header">
            <div>
              <p className="setup-eyebrow">{t("common.error")}</p>
              <h1 className="setup-title">{t("admin.errorLoadingConfig")}</h1>
              <p className="setup-subtitle">{configLoadError}</p>
            </div>
          </header>
          <div className="setup-actions">
            <button className="setup-button" type="button" onClick={() => window.location.reload()}>
              {t("common.retry")}
            </button>
          </div>
        </section>
      </div>
    );
  }

  // ─── Redirección si no hay configuración guardada ──────
  if (!hasStoredConfig) {
    return <Navigate to={`/${inviteToken}/setup`} replace />;
  }

  // ─── Esperar a que se restaure la sesión antes de decidir ──
  if (isRestoringSession) {
    // Spinner: una página en blanco durante el getDoc de la sesión era un
    // blank screen real de 0.3-1 s.
    return <div className="page-loading" role="status" aria-label={t("common.loading")} />;
  }

  // ─── Redirección si no hay sesión de admin activa ──────
  if (!isAdminTokenLoggedIn) {
    // Si la sesión expiró (no es un primer acceso), avisar en la vista
    // pública con un mensaje breve en lugar de redirigir en silencio.
    if (sessionExpired) {
      // El toast se lanza tras el redirect (AuthContext limpia authMessage al
      // cambiar de ruta).
      setTimeout(() => {
        setAdminMessage(t("auth.sessionExpired"));
        setAdminMessageType("error");
      }, 0);
      clearSessionExpired();
    }
    return <Navigate to={`/${inviteToken}`} replace />;
  }

  return (
    <div className="setup-layout setup-layout--full">
      {/* ── Contenedor de títulos y navegación ── */}
      <section
        className="setup-card setup-card--title allow-select"
        aria-label={t("admin.privateArea")}
        style={{ borderRadius: "1rem" }}
      >
        <header className="setup-header">
          <div>
            <p className="setup-eyebrow">{t("admin.privateArea")}</p>
            <h1 className="setup-title">{coupleName}</h1>
            <p className="setup-subtitle">{t("admin.manageInvitation")}</p>
          </div>
        </header>

        {/* ── Navegación por pestañas ── */}
        <nav className="admin-tabs" role="tablist" aria-label={t("admin.sectionsLabel")}>
          {TABS.map((tab) => (
            <button
              key={tab.key}
              id={"tab-" + tab.key}
              role="tab"
              aria-selected={activeTab === tab.key}
              aria-controls={"tabpanel-" + tab.key}
              tabIndex={activeTab === tab.key ? 0 : -1}
              className={`admin-tab ${activeTab === tab.key ? "admin-tab--active" : ""}`}
              onClick={() => handleSetTab(tab.key)}
              onKeyDown={(e) => handleTabKeyDown(e, tab.key)}
            >
              {t(`admin.tabs.${TAB_KEY_MAP[tab.key]}`)}
            </button>
          ))}
        </nav>
      </section>

      {/* ── Contenedor de secciones (contenido de la pestaña activa) ── */}
      <section
        className="setup-card setup-card--content allow-select"
        aria-label={t("admin.privateArea")}
        style={{ borderRadius: "1rem" }}
      >
        <Suspense fallback={<div className="page-loading" style={{ minHeight: "10rem", margin: "1rem" }} />}>
          <div
            className="setup-form"
            role="tabpanel"
            id={"tabpanel-" + activeTab}
            aria-labelledby={"tab-" + activeTab}
            ref={tabPanelRef}
            tabIndex={-1}
          >
            {/* Pestaña: Panel de control */}
            {activeTab === "panel" && <PanelTab config={panelConfig} />}

            {/* Pestaña: Editar invitación */}
            {activeTab === "invitacion" && <InvitationTab />}

            {/* Pestaña: Lista de asistencia */}
            {activeTab === "asistencia" && <AttendanceTab {...attendanceConfig} />}

            {/* Pestaña: Compartir invitación */}
            {activeTab === "compartir" && <ShareTab inviteToken={inviteToken || ""} addToast={addToast} />}
            {activeTab === "herramientas" && (
              <ToolsTab
                inviteToken={inviteToken || ""}
                inviteUrl={`${window.location.origin}/${inviteToken}`}
                weddingDate={{
                  year: config.weddingYear,
                  month: config.weddingMonth,
                  day: config.weddingDay,
                  hour: config.weddingHour,
                  minute: config.weddingMinute,
                }}
                weddingPlace={config.weddingPlace}
                coupleName={coupleName}
                expectedGuests={config.expectedGuests}
                onExpectedGuestsSaved={reloadConfig}
              />
            )}

            {/* Pestaña: Distribución (mapa de mesas y zonas) */}
            {activeTab === "distribucion" && (
              <DistribucionTab
                inviteToken={inviteToken || ""}
                background={config.backgroundImage}
                cornerDecoration={config.cornerDecoration}
              />
            )}

            {/* Pestaña: Gestión de acceso */}
            {activeTab === "acceso" && (
              <AccessTab
                setupToken={setupToken}
                handleResetTokenFromAdmin={handleResetTokenFromAdmin}
                handleAdminLogout={handleAdminLogout}
                handleDeleteInvitation={handleDeleteInvitation}
              />
            )}

            {/* Pestaña: Soporte */}
            {activeTab === "soporte" && <SupportTab />}
          </div>
        </Suspense>
      </section>
    </div>
  );
}
