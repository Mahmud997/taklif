import { memo } from "react";
import TransportPicker from "./TransportPicker";
import { AllergiesChips } from "./MenuAndAllergies";
import type { RsvpFormData } from "../../../hooks/useRsvp";
import type { Translate } from "./derive";

interface CompanionCardProps {
  index: number;
  form: RsvpFormData;
  /** Escribe cualquier campo indexado del formulario (companionNames[i], …). */
  onField: (field: string, value: unknown) => void;
  onRemove: (index: number) => void;
  /** Cambio de modo del acompañante i: el orquestador rellena salida/hora/lugar. */
  onModeChange: (index: number, mode: string) => void;
  /** Cambio de salida concreta del acompañante i. */
  onDepartureChange: (index: number, choiceIndex: string) => void;
  modes: { value: string; label: string }[];
  departures: { type?: "bus" | "taxi"; time: string; url: string }[];
  menuOptions: { key: string; label: string; desc: string }[];
  /** Abre el modal del menú de ESTE acompañante (con índice). */
  onOpenMenu: (index: number, option: { key: string; label: string; desc: string }) => void;
  hasTransportChoices: boolean;
  hasStructuredMenu: boolean;
  frozen: boolean;
  t: Translate;
}

/**
 * Tarjeta de acompañante: nombre, transporte, menú, alergias y flag ¿niño?.
 * Toda escritura va por onField con la clave indexada que useRsvp ya sabe
 * interpretar (p. ej. "companionNames[0]"), así el estado sigue viviendo en
 * un único objeto rsvpForm.
 */
const CompanionCard = memo(function CompanionCard({
  index,
  form,
  onField,
  onRemove,
  onModeChange,
  onDepartureChange,
  modes,
  departures,
  menuOptions,
  onOpenMenu,
  hasTransportChoices,
  hasStructuredMenu,
  frozen,
  t,
}: CompanionCardProps) {
  const i = index;

  return (
    <section className="rv2-card" aria-label={t("rsvp.companionHeading", { number: i + 1 })}>
      <header className="rv2-card__head">
        <h3 className="rv2-card__title">{t("rsvp.companionHeading", { number: i + 1 })}</h3>
        {/* ✕ específico: elimina ESTE acompañante preservando los demás. */}
        <button
          type="button"
          className="rv2-x"
          aria-label={t("common.remove")}
          onClick={() => onRemove(i)}
          disabled={frozen}
        >
          ✕
        </button>
      </header>

      {/* Nombre */}
      <label className="setup-label rv2-sublabel" htmlFor={`companion-name-${i}`}>
        {t("rsvp.nameLabel")} *
      </label>
      <input
        id={`companion-name-${i}`}
        className="setup-input"
        type="text"
        value={form.companionNames[i] || ""}
        onChange={(e) => onField(`companionNames[${i}]`, e.target.value.slice(0, 120))}
        placeholder={t("rsvp.attendeeNamePlaceholder")}
        required
        disabled={frozen}
        maxLength={120}
      />

      {hasTransportChoices ? (
        <TransportPicker
          group={i}
          compact
          mode={form.companionTransportModes?.[i] || "own"}
          choice={form.companionTransportChoices?.[i] || ""}
          modes={modes}
          departures={departures}
          frozen={frozen}
          t={t}
          onModeChange={(mode) => onModeChange(i, mode)}
          onDepartureChange={(choiceIdx) => onDepartureChange(i, choiceIdx)}
        />
      ) : null}

      {hasStructuredMenu && menuOptions.length > 0 ? (
        <div className="rv2-menubtns rv2-menubtns--compact">
          {menuOptions.map((m) => {
            const active = (form.companionMenus[i] || "") === m.key;
            return (
              <button
                key={m.key}
                type="button"
                className={"rv2-menu-btn" + (active ? " rv2-menu-btn--active" : "")}
                aria-pressed={active}
                disabled={frozen}
                onClick={() => onOpenMenu(i, m)}
              >
                <span>{m.label}</span>
                {active ? <span className="rv2-menu-btn__check">✓</span> : null}
              </button>
            );
          })}
        </div>
      ) : null}

      <AllergiesChips
        idSuffix={`-${i}`}
        compact
        selected={form.companionAllergies[i] || []}
        other={form.companionAllergiesOther?.[i] || ""}
        onToggle={(a) => {
          const current = form.companionAllergies[i] || [];
          const updated = current.includes(a) ? current.filter((x) => x !== a) : [...current, a];
          onField(`companionAllergies[${i}]`, updated);
        }}
        onOtherChange={(v) => {
          const current = [...(form.companionAllergiesOther || [])];
          current[i] = v;
          onField("companionAllergiesOther", current);
        }}
        frozen={frozen}
        t={t}
      />
    </section>
  );
});

export default CompanionCard;
