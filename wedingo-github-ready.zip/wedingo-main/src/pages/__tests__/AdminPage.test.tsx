import { Suspense } from "react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";

vi.mock("react-i18next", () => ({
  useTranslation: () => ({ t: (key: string) => key, i18n: { language: "en" } }),
  initReactI18next: { type: "3rdParty", init: () => {} },
}));

let mockSearch = "";
vi.mock("react-router", () => ({
  useParams: () => ({ inviteToken: "test-token" }),
  useLocation: () => ({ pathname: "/test-token/admin", search: mockSearch }),
  // useTabs sincroniza la pestaña con la URL vía useSearchParams: el mock
  // refleja los cambios en mockSearch (como haría el router real).
  useSearchParams: () => {
    const params = new URLSearchParams(mockSearch.replace(/^\?/, ""));
    const set = (next: unknown) => {
      if (next instanceof URLSearchParams) {
        mockSearch = next.toString() ? `?${next.toString()}` : "";
      } else if (next && typeof next === "object") {
        const p = new URLSearchParams();
        for (const [k, v] of Object.entries(next as Record<string, string>)) {
          if (v) p.set(k, v);
          else p.delete(k);
        }
        mockSearch = p.toString() ? `?${p.toString()}` : "";
      } else {
        mockSearch = "";
      }
    };
    return [params, set];
  },
  Navigate: ({ to }: { to: string }) => <div>Redirect to {to}</div>,
}));

const mockUseApp = vi.fn();
vi.mock("../../contexts", () => ({
  useConfigActions: () => ({
    updateFormField: vi.fn(),
    handleDayChange: vi.fn(),
    handleTimeChange: vi.fn(),
    handleTimeBlur: vi.fn(),
    handleYearChange: vi.fn(),
    maxAllowedYear: 2099,
    inviteToken: "",
    hasStoredConfig: false,
  }),
  useConfig: (...args: unknown[]) => mockUseApp(...args),
  // formData vive en su contexto separado (v2.185).
  useFormData: () => ({ formData: mockUseApp().formData, updateFormField: vi.fn() }),
  useAuth: (...args: unknown[]) => mockUseApp(...args),
  useRsvpContext: (...args: unknown[]) => mockUseApp(...args),
  useAppUI: () => ({
    ...mockUseApp(),
    setAdminMessage: mockSetAdminMessage,
    setAdminMessageType: mockSetAdminMessageType,
  }),

  useUIMessages: () => ({
    ...mockUseApp(),
    setAdminMessage: mockSetAdminMessage,
    setAdminMessageType: mockSetAdminMessageType,
  }),
}));

const mockSetAdminMessage = vi.fn();
const mockSetAdminMessageType = vi.fn();

const mockAddToast = vi.fn();
vi.mock("../../hooks/useToast", () => ({
  useToast: () => ({ addToast: mockAddToast }),
}));

vi.mock("../../lib/constants", () => ({
  STORY_SECTION_ORDER: ["hero", "details", "info", "story", "gifts", "accommodation", "gallery", "rsvp"],
  THEME_VALUES: new Set(["golden", "silver", "rose"]),
  MONTH_VALUE_TO_NUMBER: {
    enero: 1,
    febrero: 2,
    marzo: 3,
    abril: 4,
    mayo: 5,
    junio: 6,
    julio: 7,
    agosto: 8,
    septiembre: 9,
    octubre: 10,
    noviembre: 11,
    diciembre: 12,
  },
}));

vi.mock("../admin/PanelTab", () => ({
  default: ({ config }: { config: Record<string, unknown> }) => (
    <div data-testid="panel-tab">
      <button
        data-testid="export-pdf-btn"
        onClick={() => {
          const fn = config.exportPdf as () => void;
          if (fn) fn();
        }}
      >
        Export
      </button>
      <button
        data-testid="set-active-tab-btn"
        onClick={() => {
          const fn = config.setActiveTab as (t: string) => void;
          if (fn) fn("invitacion");
        }}
      >
        Set Tab
      </button>
    </div>
  ),
}));

vi.mock("../admin/InvitationTab", () => ({
  default: () => <div data-testid="invitation-tab" />,
}));

vi.mock("../admin/AttendanceTab", () => ({
  default: (props: Record<string, unknown>) => (
    <div data-testid="attendance-tab">
      <button
        data-testid="set-attendance-filter-btn"
        onClick={() => {
          const fn = props.setAttendanceFilter as (f: string) => void;
          if (fn) fn("yes");
        }}
      >
        Set Filter
      </button>
      <button
        data-testid="set-search-query-btn"
        onClick={() => {
          const fn = props.setSearchQuery as (q: string) => void;
          if (fn) fn("test");
        }}
      >
        Set Search
      </button>
    </div>
  ),
}));

vi.mock("../admin/AccessTab", () => ({
  default: () => <div data-testid="access-tab" />,
}));

vi.mock("../admin/ShareTab", () => ({
  default: () => <div data-testid="share-tab" />,
}));

vi.mock("../admin/SupportTab", () => ({
  default: () => <div data-testid="support-tab" />,
}));

import AdminPage from "../AdminPage";

const baseMock = {
  config: { theme: "golden", firstName: "John", secondName: "Jane" },
  formData: {},
  isConfigLoading: false,
  configLoadError: "",
  hasStoredConfig: true,
  isAdminTokenLoggedIn: true,
  inviteToken: "test-token",
  updateFormField: vi.fn(),
  handleSaveSetup: vi.fn(),
  maxAllowedYear: 2099,
  previewBackgrounds: [],
  isPreviewLoading: false,
  formattedDate: "",
  formattedTime: "",
  calendarLink: null,
  handleDayChange: vi.fn(),
  handleHourChange: vi.fn(),
  handleMinuteChange: vi.fn(),
  handleMinuteBlur: vi.fn(),
  handleYearChange: vi.fn(),
  handleCoordinateChange: vi.fn(),
  handleDeleteInvitation: vi.fn(),
  setHasStoredConfig: vi.fn(),
  registerOnFirstSave: vi.fn(),
  setupToken: "",
  isTokenVerified: true,
  adminLoginUsername: "",
  rsvpEntries: [],
  rsvpForm: { attendees: [] },
  rsvpMessage: "",
  isRsvpSubmitting: false,
  hasSubmitted: false,
  alreadySubmittedEntry: null,
  updateRsvpField: vi.fn(),
  handleRsvpSubmit: vi.fn(),
  handleDeleteRsvp: vi.fn(),
  DIETARY_OPTIONS: [],
  computeAge: vi.fn(),
  setSaveError: vi.fn(),
  setSaveMessage: vi.fn(),
  adminMessage: "",
  adminMessageType: "success",
  setAdminMessage: vi.fn(),
  setAdminMessageType: vi.fn(),
  setLegalModal: vi.fn(),
  saveMessage: "",
  saveError: "",
  visitCount: 0,
  handleClearRsvpEntries: vi.fn(),
  handleAdminLogout: vi.fn(),
  handleResetTokenFromAdmin: vi.fn(),
  reloadConfig: vi.fn(),
};

describe("AdminPage", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    // Reset de la URL simulada: useTabs sincroniza la pestaña con mockSearch
    // y un test que cambie de pestaña la deja modificada para el siguiente.
    mockSearch = "";
    mockUseApp.mockReturnValue(baseMock);
  });

  it("shows loading state", () => {
    mockUseApp.mockReturnValue({ ...baseMock, isConfigLoading: true });

    render(<AdminPage />);
    expect(screen.getByText("admin.loadingConfig")).toBeDefined();
  });

  it("has loading aria-label", () => {
    mockUseApp.mockReturnValue({ ...baseMock, isConfigLoading: true });

    render(<AdminPage />);
    expect(screen.getByLabelText("setup.loadingTitle")).toBeDefined();
  });

  it("shows error state with retry button", () => {
    mockUseApp.mockReturnValue({ ...baseMock, configLoadError: "Failed to load" });

    render(<AdminPage />);
    expect(screen.getByText("admin.errorLoadingConfig")).toBeDefined();
    expect(screen.getByText("Failed to load")).toBeDefined();
    expect(screen.getByText("common.retry")).toBeDefined();
  });

  it("redirects when no stored config", () => {
    mockUseApp.mockReturnValue({ ...baseMock, hasStoredConfig: false });

    render(<AdminPage />);
    expect(screen.getByText(/Redirect to.*setup/)).toBeDefined();
  });

  it("redirects when not admin token logged in", () => {
    mockUseApp.mockReturnValue({ ...baseMock, isAdminTokenLoggedIn: false });

    render(<AdminPage />);
    expect(screen.getByText(/Redirect to.*test-token/)).toBeDefined();
  });

  it("shows a session-expired message when redirecting after expiry", async () => {
    mockUseApp.mockReturnValue({
      ...baseMock,
      isAdminTokenLoggedIn: false,
      sessionExpired: true,
      clearSessionExpired: vi.fn(),
    });

    render(<AdminPage />);
    expect(screen.getByText(/Redirect to.*test-token/)).toBeDefined();
    // El aviso se lanza con un timeout para sobrevivir al redirect.
    await vi.waitFor(() => {
      expect(mockSetAdminMessage).toHaveBeenCalledWith("auth.sessionExpired");
    });
    expect(mockSetAdminMessageType).toHaveBeenCalledWith("error");
  });

  it("renders panel tab by default when all conditions met", async () => {
    render(
      <Suspense fallback={null}>
        <AdminPage />
      </Suspense>,
    );
    expect(await screen.findByTestId("panel-tab")).toBeDefined();
    expect(screen.getByText("John & Jane")).toBeDefined();
    expect(screen.getByText("admin.manageInvitation")).toBeDefined();
  });

  it("renders all tab buttons", async () => {
    render(
      <Suspense fallback={null}>
        <AdminPage />
      </Suspense>,
    );
    await screen.findByTestId("panel-tab");
    const tabKeys = ["panel", "invitation", "attendance", "share", "access", "support"];
    tabKeys.forEach((key) => {
      expect(screen.getByText(`admin.tabs.${key}`)).toBeDefined();
    });
  });

  it("navigates tabs with the arrow keys (roving tabindex)", async () => {
    render(
      <Suspense fallback={null}>
        <AdminPage />
      </Suspense>,
    );
    await screen.findByTestId("panel-tab");
    const active = document.querySelector('button[role="tab"][aria-selected="true"]');
    fireEvent.keyDown(active!, { key: "ArrowRight" });
    const next = document.querySelector('button[role="tab"][aria-selected="true"]');
    expect(next).not.toBe(active);
  });

  it("shows toast when adminMessage is set", () => {
    mockUseApp.mockReturnValue({ ...baseMock, adminMessage: "Action completed", adminMessageType: "success" });

    render(<AdminPage />);
    expect(mockAddToast).toHaveBeenCalledWith("success", "Action completed");
  });

  it("shows error toast when adminMessageType is error", () => {
    mockUseApp.mockReturnValue({ ...baseMock, adminMessage: "Something failed", adminMessageType: "error" });

    render(<AdminPage />);
    expect(mockAddToast).toHaveBeenCalledWith("error", "Something failed");
  });

  it("switches to invitation tab", async () => {
    render(
      <Suspense fallback={null}>
        <AdminPage />
      </Suspense>,
    );
    await screen.findByTestId("panel-tab");
    fireEvent.click(screen.getByText("admin.tabs.invitation"));
    expect(await screen.findByTestId("invitation-tab")).toBeDefined();
  });

  it("switches to attendance tab", async () => {
    render(
      <Suspense fallback={null}>
        <AdminPage />
      </Suspense>,
    );
    await screen.findByTestId("panel-tab");
    fireEvent.click(screen.getByText("admin.tabs.attendance"));
    expect(await screen.findByTestId("attendance-tab")).toBeDefined();
  });

  it("switches to share tab", async () => {
    render(
      <Suspense fallback={null}>
        <AdminPage />
      </Suspense>,
    );
    await screen.findByTestId("panel-tab");
    fireEvent.click(screen.getByText("admin.tabs.share"));
    expect(await screen.findByTestId("share-tab")).toBeDefined();
  });

  it("switches to access tab", async () => {
    render(
      <Suspense fallback={null}>
        <AdminPage />
      </Suspense>,
    );
    await screen.findByTestId("panel-tab");
    fireEvent.click(screen.getByText("admin.tabs.access"));
    expect(await screen.findByTestId("access-tab")).toBeDefined();
  });

  it("switches to support tab", async () => {
    render(
      <Suspense fallback={null}>
        <AdminPage />
      </Suspense>,
    );
    await screen.findByTestId("panel-tab");
    fireEvent.click(screen.getByText("admin.tabs.support"));
    expect(await screen.findByTestId("support-tab")).toBeDefined();
  });

  it("renders invitation tab via URL param", async () => {
    mockSearch = "?tab=invitacion";

    render(
      <Suspense fallback={null}>
        <AdminPage />
      </Suspense>,
    );
    expect(await screen.findByTestId("invitation-tab")).toBeDefined();

    mockSearch = "";
  });

  it("shows success toast when authMessage is set", () => {
    mockUseApp.mockReturnValue({ ...baseMock, authMessage: "Config saved", authMessageType: "success" });

    render(<AdminPage />);
    expect(mockAddToast).toHaveBeenCalledWith("success", "Config saved");
  });

  it("shows error toast when authMessageType is error", () => {
    mockUseApp.mockReturnValue({ ...baseMock, authMessage: "Config error", authMessageType: "error" });

    render(<AdminPage />);
    expect(mockAddToast).toHaveBeenCalledWith("error", "Config error");
  });

  it("updates URL when switching tabs via handleSetTab", async () => {
    const replaceStateSpy = vi.spyOn(window.history, "replaceState");

    render(
      <Suspense fallback={null}>
        <AdminPage />
      </Suspense>,
    );
    await screen.findByTestId("panel-tab");
    fireEvent.click(screen.getByText("admin.tabs.invitation"));
    await screen.findByTestId("invitation-tab");
    // useTabs sincroniza la URL vía setSearchParams (mock que actualiza mockSearch).
    expect(replaceStateSpy).not.toHaveBeenCalled();
    expect(mockSearch).toContain("tab=invitacion");

    replaceStateSpy.mockRestore();
  });

  it("computes filteredEntries with attendance filter", () => {
    mockUseApp.mockReturnValue({
      ...baseMock,
      rsvpEntries: [
        { guestName: "Alice", attendance: "yes", companions: 2 },
        { guestName: "Bob", attendance: "no" },
        { guestName: "Charlie", attendance: "yes", companions: 1 },
      ],
    });

    render(
      <Suspense fallback={null}>
        <AdminPage />
      </Suspense>,
    );
    expect(screen.getByText("admin.tabs.attendance")).toBeDefined();
  });

  it("renders couple name in header", async () => {
    render(
      <Suspense fallback={null}>
        <AdminPage />
      </Suspense>,
    );
    expect(await screen.findByText("John & Jane")).toBeDefined();
  });

  it("renders retry button in error state with click handler", () => {
    mockUseApp.mockReturnValue({ ...baseMock, configLoadError: "Failed to load" });

    render(<AdminPage />);
    const btn = screen.getByText("common.retry");
    expect(btn).toBeDefined();
    expect(btn.getAttribute("type")).toBe("button");
  });

  it("calls window.location.reload when retry button is clicked", () => {
    const reloadFn = vi.fn();
    const origLocation = window.location;
    delete (window as any).location;
    (window as any).location = { reload: reloadFn };

    mockUseApp.mockReturnValue({ ...baseMock, configLoadError: "Failed to load" });

    render(<AdminPage />);
    fireEvent.click(screen.getByText("common.retry"));
    expect(reloadFn).toHaveBeenCalled();

    (window as any).location = origLocation;
  });

  it("computes totalGuests from rsvpEntries", () => {
    mockUseApp.mockReturnValue({
      ...baseMock,
      rsvpEntries: [
        { guestName: "Alice", attendance: "yes", companions: 2 },
        { guestName: "Bob", attendance: "no" },
        { guestName: "Charlie", attendance: "yes", companions: 1 },
      ],
    });

    render(
      <Suspense fallback={null}>
        <AdminPage />
      </Suspense>,
    );
    expect(screen.getByText("John & Jane")).toBeDefined();
  });

  it("sets activeTab via setActiveTabAndFilter callback", async () => {
    render(
      <Suspense fallback={null}>
        <AdminPage />
      </Suspense>,
    );
    await screen.findByTestId("panel-tab");
    fireEvent.click(screen.getByText("admin.tabs.invitation"));
    expect(await screen.findByTestId("invitation-tab")).toBeDefined();
  });

  it("sets attendanceFilter via setAttendanceFilterValue callback", async () => {
    render(
      <Suspense fallback={null}>
        <AdminPage />
      </Suspense>,
    );
    await screen.findByTestId("panel-tab");
    expect(screen.getByText("John & Jane")).toBeDefined();
  });

  it("filters rsvp entries by attendance filter", () => {
    mockUseApp.mockReturnValue({
      ...baseMock,
      rsvpEntries: [
        { guestName: "Alice", attendance: "yes", companions: 2 },
        { guestName: "Bob", attendance: "no" },
        { guestName: "Charlie", attendance: "yes", companions: 1 },
      ],
    });

    render(
      <Suspense fallback={null}>
        <AdminPage />
      </Suspense>,
    );
  });

  it("computes confirmed and declined responses from rsvpEntries", () => {
    mockUseApp.mockReturnValue({
      ...baseMock,
      rsvpEntries: [
        { guestName: "Alice", attendance: "yes", companions: 2 },
        { guestName: "Bob", attendance: "no" },
        { guestName: "Charlie", attendance: "yes", companions: 3 },
      ],
    });

    render(
      <Suspense fallback={null}>
        <AdminPage />
      </Suspense>,
    );
  });

  it("restores default tab when panel tab is selected via handleSetTab", async () => {
    const replaceStateSpy = vi.spyOn(window.history, "replaceState");

    mockSearch = "?tab=invitacion";
    render(
      <Suspense fallback={null}>
        <AdminPage />
      </Suspense>,
    );
    await screen.findByTestId("invitation-tab");

    fireEvent.click(screen.getByText("admin.tabs.panel"));
    await screen.findByTestId("panel-tab");

    // Seleccionar la pestaña por defecto limpia el parámetro ?tab de la URL.
    expect(replaceStateSpy).not.toHaveBeenCalled();
    expect(mockSearch).not.toContain("tab=");
    replaceStateSpy.mockRestore();
    mockSearch = "";
  });

  it("computes totalGuests correctly with companions", () => {
    mockUseApp.mockReturnValue({
      ...baseMock,
      rsvpEntries: [
        { guestName: "Alice", attendance: "yes", companions: 2 },
        { guestName: "Bob", attendance: "no" },
      ],
    });

    render(
      <Suspense fallback={null}>
        <AdminPage />
      </Suspense>,
    );
  });

  it("filters by search query in filteredEntries", () => {
    mockUseApp.mockReturnValue({
      ...baseMock,
      rsvpEntries: [
        { guestName: "Alice", attendance: "yes", companions: 0 },
        { guestName: "Bob", attendance: "no" },
        { guestName: "Charlie", attendance: "yes", companions: 1 },
      ],
      searchQuery: "ali",
    });

    render(
      <Suspense fallback={null}>
        <AdminPage />
      </Suspense>,
    );
  });

  it("handles exportPdf with RSVP data", async () => {
    const mockFocus = vi.fn();
    const mockWindowOpen = vi.fn(() => ({ focus: mockFocus }));
    vi.spyOn(window, "open").mockImplementation(mockWindowOpen as unknown as typeof window.open);
    const createObjectURL = vi.fn(() => "blob:test");
    vi.spyOn(URL, "createObjectURL").mockImplementation(createObjectURL);
    vi.spyOn(URL, "revokeObjectURL").mockImplementation(() => {});

    mockUseApp.mockReturnValue({
      ...baseMock,
      rsvpEntries: [
        { guestName: "Alice", attendance: "yes", companions: 2, dietaryInfo: "Veg" },
        { guestName: "Bob", attendance: "no", companions: 0, dietaryInfo: "" },
      ],
    });

    render(
      <Suspense fallback={null}>
        <AdminPage />
      </Suspense>,
    );
    await screen.findByTestId("panel-tab");
    fireEvent.click(screen.getByTestId("export-pdf-btn"));
    expect(mockWindowOpen).toHaveBeenCalled();
    expect(createObjectURL).toHaveBeenCalled();
  });

  it("filters rsvp entries with attendance filter 'no'", () => {
    mockUseApp.mockReturnValue({
      ...baseMock,
      rsvpEntries: [
        { guestName: "Alice", attendance: "yes", companions: 2 },
        { guestName: "Bob", attendance: "no" },
        { guestName: "Charlie", attendance: "yes", companions: 1 },
      ],
      attendanceFilter: "no",
    });

    render(
      <Suspense fallback={null}>
        <AdminPage />
      </Suspense>,
    );
  });

  it("shows a loading spinner while restoring the session", () => {
    mockUseApp.mockReturnValue({ ...baseMock, isRestoringSession: true });
    const { container } = render(
      <Suspense fallback={null}>
        <AdminPage />
      </Suspense>,
    );
    // Ya no hay pantalla en blanco: se muestra el indicador de carga.
    expect(container.querySelector(".page-loading")).toBeDefined();
  });

  it("calls setActiveTabAndFilter from PanelTab", async () => {
    render(
      <Suspense fallback={null}>
        <AdminPage />
      </Suspense>,
    );
    await screen.findByTestId("panel-tab");
    fireEvent.click(screen.getByTestId("set-active-tab-btn"));
    await screen.findByTestId("invitation-tab");
  });

  it("calls setAttendanceFilter from AttendanceTab", async () => {
    render(
      <Suspense fallback={null}>
        <AdminPage />
      </Suspense>,
    );
    await screen.findByTestId("panel-tab");
    fireEvent.click(screen.getByText("admin.tabs.attendance"));
    await screen.findByTestId("attendance-tab");
    fireEvent.click(screen.getByTestId("set-attendance-filter-btn"));
  });

  it("calls setSearchQuery from AttendanceTab", async () => {
    render(
      <Suspense fallback={null}>
        <AdminPage />
      </Suspense>,
    );
    await screen.findByTestId("panel-tab");
    fireEvent.click(screen.getByText("admin.tabs.attendance"));
    await screen.findByTestId("attendance-tab");
    fireEvent.click(screen.getByTestId("set-search-query-btn"));
  });

  it("handles exportPdf when window.open returns null", async () => {
    vi.spyOn(window, "open").mockReturnValue(null);
    const createObjectURL = vi.fn(() => "blob:test");
    vi.spyOn(URL, "createObjectURL").mockImplementation(createObjectURL);

    mockUseApp.mockReturnValue({
      ...baseMock,
      rsvpEntries: [{ guestName: "Alice", attendance: "yes", companions: 2, dietaryInfo: "Veg" }],
    });

    render(
      <Suspense fallback={null}>
        <AdminPage />
      </Suspense>,
    );
    await screen.findByTestId("panel-tab");
    fireEvent.click(screen.getByTestId("export-pdf-btn"));
    expect(createObjectURL).toHaveBeenCalled();
  });

  it("handles exportPdf sin respuestas filtradas (toast sin imprimir)", async () => {
    const openSpy = vi.spyOn(window, "open");
    const createObjectURL = vi.spyOn(URL, "createObjectURL");
    mockUseApp.mockReturnValue({ ...baseMock, rsvpEntries: [] });
    render(
      <Suspense fallback={null}>
        <AdminPage />
      </Suspense>,
    );
    await screen.findByTestId("panel-tab");
    fireEvent.click(screen.getByTestId("export-pdf-btn"));
    expect(mockAddToast).toHaveBeenCalledWith("info", "attendance.noResults");
    expect(createObjectURL).not.toHaveBeenCalled();
    expect(openSpy).not.toHaveBeenCalled();
  });

  it("filters by attendance filter 'no' in filteredEntries", () => {
    mockUseApp.mockReturnValue({
      ...baseMock,
      rsvpEntries: [
        { guestName: "Alice", attendance: "yes", companions: 2 },
        { guestName: "Bob", attendance: "no" },
      ],
      attendanceFilter: "no",
    });

    render(
      <Suspense fallback={null}>
        <AdminPage />
      </Suspense>,
    );
    expect(screen.getByText("admin.tabs.share")).toBeDefined();
  });

  it("renders share tab with inviteToken fallback", async () => {
    render(
      <Suspense fallback={null}>
        <AdminPage />
      </Suspense>,
    );
    await screen.findByTestId("panel-tab");
    fireEvent.click(screen.getByText("admin.tabs.share"));
    expect(await screen.findByTestId("share-tab")).toBeDefined();
  });

  it("medianeras del memo de estadísticas: asistencia no-yes/no y companions 0/ausentes", () => {
    // attendance "maybe" cae en el else del memo; companions 0/undefined usan
    // el default 1. Sin crash y el header se renderiza.
    mockUseApp.mockReturnValue({
      ...baseMock,
      rsvpEntries: [
        { guestName: "Ana", attendance: "maybe", companions: "0" },
        { guestName: "Luis", attendance: "yes" },
      ],
    });
    render(
      <Suspense fallback={null}>
        <AdminPage />
      </Suspense>,
    );
    expect(screen.getByText("John & Jane")).toBeDefined();
  });

  it("timestamp de la boda: fecha inválida no rompe y medianoche (hora 0) es válida", () => {
    const cfg = { ...baseMock.config, weddingDay: "31", weddingMonth: "febrero", weddingYear: "2025", weddingHour: "18" };
    mockUseApp.mockReturnValue({ ...baseMock, config: cfg });
    render(
      <Suspense fallback={null}>
        <AdminPage />
      </Suspense>,
    );
    // Rollover ("31 de febrero") → weddingTimestamp null; la página sigue viva.
    expect(screen.getAllByText("John & Jane").length).toBeGreaterThan(0);
    // Hora "0" (medianoche) no se trata como vacía: se renderiza OK.
    mockUseApp.mockReturnValue({
      ...baseMock,
      config: {
        ...baseMock.config,
        weddingDay: "15",
        weddingMonth: "junio",
        weddingYear: "2026",
        weddingHour: "0",
        weddingMinute: "0",
      },
    });
    render(
      <Suspense fallback={null}>
        <AdminPage />
      </Suspense>,
    );
    expect(screen.getAllByText("John & Jane").length).toBeGreaterThan(0);
  });

  it("acota expectedGuests a [0, 1000] sin romper el dashboard", () => {
    mockUseApp.mockReturnValue({ ...baseMock, config: { ...baseMock.config, expectedGuests: "5000" } });
    render(
      <Suspense fallback={null}>
        <AdminPage />
      </Suspense>,
    );
    expect(screen.getByText("John & Jane")).toBeDefined();
  });
});
