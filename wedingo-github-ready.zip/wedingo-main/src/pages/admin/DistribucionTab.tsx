/**
 * DistribucionTab — Distribución del recinto por SECCIONES (diferencial).
 *
 * El admin crea SECCIONES (p. ej. "Salón principal", "Jardín"); cada sección
 * tiene su PROPIO mapa con mesas con forma que se arrastran, redimensionan y
 * rotan. Las mesas y sus posiciones se GUARDAN en Firestore (subcolección
 * `sections/{sectionId}/tables`). Solo se pueden asignar a las mesas invitados
 * que hayan CONFIRMADO su asistencia (attendance === "yes").
 *
 * Las secciones se muestran como un menú superior sobre la previsualización, y
 * el mapa ocupa todo el espacio disponible.
 */
import { memo, useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  getDocs,
  collection,
  doc,
  addDoc,
  updateDoc,
  deleteDoc,
  arrayUnion,
  arrayRemove,
  writeBatch,
} from "firebase/firestore";
import { db } from "../../lib/firebase";
import { useTranslation } from "react-i18next";
import { useToast } from "../../hooks/useToast";
import { useConfirm } from "../../contexts/ConfirmContext";
import { useRsvpContext } from "../../contexts";
import { TableCanvas, type CanvasTable } from "./table-canvas";
import type { TableShape, ShapeTable as ShapeTableShared } from "../../lib/table-geometry";
import { clampPercent, buildLabelsHtml, assignGuestsToTables } from "./distribucion-helpers";

// Tipos IMPORTADOS de table-geometry (v2.186): aquí estaban redefinidos
// Shape/ShapeTable idénticos y divergían de la vista pública. `Section`
// (solo id+nombre) sigue siendo local: aquí las secciones se cargan sin
// mesas (se cargan por separado).
type Shape = TableShape;
type ShapeTable = ShapeTableShared;
/** Zona del plano en el editor (sin mesas: se cargan aparte). */
interface Section {
  id: string;
  name: string;
}

const SHAPES: Array<{ key: Shape; label: string }> = [
  // Solo círculo y cuadrado: las mesas rectangulares/ovaladas dieron fallos
  // y se retiraron. El tipo Shape conserva rect/oval para leer mesas antiguas.
  { key: "circle", label: "Círculo" },
  { key: "square", label: "Cuadrado" },
];

const DistribucionTab = memo(function DistribucionTab({
  inviteToken,
  background,
  cornerDecoration,
  theme,
}: {
  inviteToken: string;
  /** Imagen de fondo personalizada (data-URL ya hidratada) para las etiquetas. */
  background?: string | undefined;
  /** Decoración de esquinas personalizada (data-URL) para las etiquetas. */
  cornerDecoration?: string | undefined;
  /** Tema de la invitación (p. ej. "golden") para sus colores en las etiquetas. */
  theme?: string | undefined;
}) {
  const { t } = useTranslation();
  const { addToast } = useToast();
  const { confirm } = useConfirm();
  const [sections, setSections] = useState<Section[]>([]);
  const [activeSectionId, setActiveSectionId] = useState("");
  const [tables, setTables] = useState<ShapeTable[]>([]);
  const [selectedId, setSelectedId] = useState("");
  const [newSectionName, setNewSectionName] = useState("");
  const [newShape, setNewShape] = useState<Shape>("circle");
  // Invitados CONFIRMADOS (attendance yes) disponibles para asignar.
  const mapRef = useRef<HTMLDivElement | null>(null);
  const dragRef = useRef<{ id: string; moved: boolean } | null>(null);

  const sectionsRef = useCallback(() => collection(db, "invitations", inviteToken, "sections"), [inviteToken]);
  const tablesRef = useCallback(
    (sectionId: string) => collection(db, "invitations", inviteToken, "sections", sectionId, "tables"),
    [inviteToken],
  );

  // ── Carga de secciones ──
  const loadSections = useCallback(async () => {
    try {
      const snap = await getDocs(sectionsRef());
      const list = snap.docs.map((d) => ({ id: d.id, name: String(d.data().name || "") }));
      setSections(list);
      if (list.length > 0 && !list.some((s) => s.id === activeSectionId)) {
        setActiveSectionId(list[0]!.id);
      }
    } catch {
      /* datos no disponibles */
    }
  }, [sectionsRef, activeSectionId]);

  // Confirmados derivados del contexto RSVP compartido (v2.185): antes esta
  // pestaña re-leía TODA la colección de respuestas por su cuenta; ahora usa
  // los mismos datos que ya mantiene useRsvp con su onSnapshot en vivo.
  const { rsvpEntries } = useRsvpContext();
  const confirmedGuests = useMemo(() => {
    const names = new Set<string>();
    for (const entry of rsvpEntries) {
      if (entry.attendance === "yes") names.add(String(entry.guestName || "").trim());
    }
    return [...names].filter(Boolean).map((name) => ({ name, assigned: false }));
  }, [rsvpEntries]);

  useEffect(() => {
    void loadSections();
  }, [loadSections]);

  // ── Carga de mesas de la sección activa ──
  const loadTables = useCallback(async () => {
    if (!activeSectionId) return;
    try {
      const snap = await getDocs(tablesRef(activeSectionId));
      setTables(
        snap.docs.map((d) => ({
          id: d.id,
          name: String(d.data().name || ""),
          shape: String(d.data().shape || "circle") as Shape,
          x: Number(d.data().x) || 0,
          y: Number(d.data().y) || 0,
          w: Number(d.data().w) || 14,
          h: Number(d.data().h) || 8,
          rotation: Number(d.data().rotation) || 0,
          seats: Number(d.data().seats) || 0,
          guests: Array.isArray(d.data().guests) ? (d.data().guests as string[]) : [],
        })),
      );
      setSelectedId("");
    } catch {
      /* datos no disponibles */
    }
  }, [activeSectionId, tablesRef]);

  useEffect(() => {
    void loadTables();
  }, [loadTables]);

  // Mantiene la marca "asignado" de los confirmados según las mesas actuales.
  const assignedNames = useMemo(() => new Set(tables.flatMap((tb) => tb.guests)), [tables]);

  // ── Secciones ──
  const addSection = useCallback(async () => {
    const name = newSectionName.trim();
    if (!name) return;
    try {
      const ref = await addDoc(sectionsRef(), { name: name.slice(0, 80), createdAt: new Date().toISOString() });
      setSections((prev) => [...prev, { id: ref.id, name: name.slice(0, 80) }]);
      setActiveSectionId(ref.id);
      setNewSectionName("");
      addToast("success", t("distribucion.sectionAdded"));
    } catch {
      addToast("error", t("errors.generic"));
    }
  }, [newSectionName, sectionsRef, addToast, t]);

  const deleteSection = useCallback(
    async (id: string) => {
      if (!(await confirm({ message: t("distribucion.deleteSectionConfirm"), danger: true }))) return;
      try {
        const tbSnap = await getDocs(tablesRef(id));
        for (let i = 0; i < tbSnap.docs.length; i += 400) {
          const batch = await import("firebase/firestore").then((m) => m.writeBatch(db));
          tbSnap.docs.slice(i, i + 400).forEach((d) => batch.delete(d.ref));
          await batch.commit();
        }
        await deleteDoc(doc(sectionsRef(), id));
        const next = sections.filter((s) => s.id !== id);
        setSections(next);
        if (activeSectionId === id) setActiveSectionId(next[0]?.id || "");
      } catch {
        addToast("error", t("errors.generic"));
      }
    },
    [sectionsRef, tablesRef, sections, activeSectionId, addToast, t, confirm],
  );

  // ── Mesas de la sección activa ──
  const addTable = useCallback(async () => {
    if (!activeSectionId) return;
    // Tamaño por defecto en PÍXELES: en círculo/cuadrado ancho=alto siempre.
    const defaultSize = (shape: Shape): { w: number; h: number } => {
      switch (shape) {
        case "circle":
        case "square":
          return { w: 90, h: 90 };
        case "oval":
          return { w: 140, h: 90 };
        default:
          return { w: 130, h: 80 };
      }
    };
    const size = defaultSize(newShape);
    try {
      const ref = await addDoc(tablesRef(activeSectionId), {
        name: t("distribucion.defaultTable"),
        shape: newShape,
        x: 50,
        y: 50,
        w: size.w,
        h: size.h,
        rotation: 0,
        seats: 8,
        guests: [],
        createdAt: new Date().toISOString(),
      });
      setTables((prev) => [
        ...prev,
        {
          id: ref.id,
          name: t("distribucion.defaultTable"),
          shape: newShape,
          x: 50,
          y: 50,
          w: size.w,
          h: size.h,
          rotation: 0,
          seats: 8,
          guests: [],
        },
      ]);
      setSelectedId(ref.id);
    } catch {
      addToast("error", t("errors.generic"));
    }
  }, [activeSectionId, newShape, tablesRef, addToast, t]);

  const deleteTable = useCallback(
    async (id: string) => {
      if (!activeSectionId) return;
      try {
        await deleteDoc(doc(tablesRef(activeSectionId), id));
        setTables((prev) => prev.filter((tb) => tb.id !== id));
        if (selectedId === id) setSelectedId("");
      } catch {
        addToast("error", t("errors.generic"));
      }
    },
    [activeSectionId, tablesRef, selectedId, addToast, t],
  );

  const patchTable = useCallback((id: string, patch: Partial<ShapeTable>) => {
    setTables((prev) => prev.map((tb) => (tb.id === id ? { ...tb, ...patch } : tb)));
  }, []);

  const persistTable = useCallback(
    async (id: string, patch: Partial<ShapeTable>) => {
      if (!activeSectionId) return;
      try {
        await updateDoc(doc(tablesRef(activeSectionId), id), patch);
      } catch {
        addToast("error", t("errors.generic"));
      }
    },
    [activeSectionId, tablesRef, addToast, t],
  );

  // Solo se asignan invitados CONFIRMADOS y que no estén ya en otra mesa.
  const assignGuest = useCallback(
    async (id: string, name: string) => {
      if (!activeSectionId || !name) return;
      if (assignedNames.has(name)) return;
      const tb = tables.find((x) => x.id === id);
      if (!tb || tb.guests.length >= tb.seats) {
        addToast("error", t("distribucion.tableFull"));
        return;
      }
      patchTable(id, { guests: [...tb.guests, name] });
      try {
        await updateDoc(doc(tablesRef(activeSectionId), id), { guests: arrayUnion(name) });
      } catch {
        addToast("error", t("errors.generic"));
      }
    },
    [activeSectionId, tables, assignedNames, patchTable, tablesRef, addToast, t],
  );

  const removeGuest = useCallback(
    async (id: string, name: string) => {
      if (!activeSectionId) return;
      patchTable(id, { guests: (tables.find((x) => x.id === id)?.guests || []).filter((g) => g !== name) });
      try {
        await updateDoc(doc(tablesRef(activeSectionId), id), { guests: arrayRemove(name) });
      } catch {
        addToast("error", t("errors.generic"));
      }
    },
    [activeSectionId, tables, patchTable, tablesRef, addToast, t],
  );

  // ── Auto-asignación de invitados a las mesas (F9) ──
  // Reparte los confirmados sin mesa entre las mesas con hueco de forma
  // EQUILIBRADA (round-robin): evita llenar una mesa entera y dejar el resto
  // vacías. Persistencia en un único batch atómico.
  // CASOS CATASTRÓFICOS: sin candidatos o sin huecos → aviso informativo sin
  // cambios; un batch fallido (red) → toast de error y el estado local NO se
  // actualiza (se evita la divergencia con Firestore).
  const autoAssign = useCallback(async () => {
    if (!activeSectionId) return;
    const candidates = confirmedGuests.filter((g) => !assignedNames.has(g.name));
    if (candidates.length === 0) {
      addToast("info", t("distribucion.autoAssignNone"));
      return;
    }
    const slots = tables
      .map((tb) => ({ id: tb.id, slots: Math.max(0, tb.seats - (tb.guests?.length || 0)) }))
      .filter((t) => t.slots > 0)
      .sort((a, b) => b.slots - a.slots);
    if (slots.length === 0) {
      addToast("info", t("distribucion.tableFull"));
      return;
    }
    const byTable = assignGuestsToTables(
      candidates.map((g) => g.name),
      slots,
    );
    if (Object.keys(byTable).length === 0) {
      addToast("info", t("distribucion.tableFull"));
      return;
    }
    const batch = writeBatch(db);
    let assigned = 0;
    for (const [tid, names] of Object.entries(byTable)) {
      batch.update(doc(tablesRef(activeSectionId), tid), { guests: arrayUnion(...names) });
      patchTable(tid, { guests: [...(tables.find((x) => x.id === tid)?.guests || []), ...names] });
      assigned += names.length;
    }
    try {
      await batch.commit();
      addToast("success", t("distribucion.autoAssignDone", { count: assigned }));
    } catch {
      addToast("error", t("errors.generic"));
    }
  }, [activeSectionId, confirmedGuests, assignedNames, tables, tablesRef, patchTable, addToast, t]);

  // ── Arrastre de mesas ──
  const onPointerDown = useCallback((e: React.PointerEvent, id: string) => {
    e.preventDefault();
    const map = mapRef.current;
    if (!map) return;
    dragRef.current = { id, moved: false };
    (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
    setSelectedId(id);
  }, []);

  const onPointerMove = useCallback(
    (e: React.PointerEvent) => {
      const drag = dragRef.current;
      const map = mapRef.current;
      if (!drag || !map) return;
      const rect = map.getBoundingClientRect();
      const x = Math.min(100, Math.max(0, ((e.clientX - rect.left) / rect.width) * 100));
      const y = Math.min(100, Math.max(0, ((e.clientY - rect.top) / rect.height) * 100));
      drag.moved = true;
      patchTable(drag.id, { x, y });
    },
    [patchTable],
  );

  const onPointerUp = useCallback(() => {
    const drag = dragRef.current;
    if (drag && drag.moved) {
      const tb = tables.find((x) => x.id === drag.id);
      if (tb) void persistTable(drag.id, { x: tb.x, y: tb.y });
    }
    dragRef.current = null;
  }, [tables, persistTable]);

  // Accesibilidad teclado (WCAG 2.1.1): las mesas eran solo arrastrables con
  // puntero. Ahora, con la mesa enfocada, las flechas la mueven en pasos de
  // ~2,5% (Shift = paso fino de 0,5%) y se persiste el cambio, igual que el drag.
  const moveSelectedByKey = useCallback(
    (e: React.KeyboardEvent, id: string) => {
      const tb = tables.find((x) => x.id === id);
      if (!tb) return;
      const step = e.shiftKey ? 0.5 : 2.5;
      const verticalKeys = ["ArrowUp", "ArrowDown"];
      const horizontalKeys = ["ArrowLeft", "ArrowRight"];
      if (!verticalKeys.includes(e.key) && !horizontalKeys.includes(e.key)) return;
      e.preventDefault();
      setSelectedId(id);
      const next: { x?: number; y?: number } = {};
      if (e.key === "ArrowUp") next.y = clampPercent(tb.y - step);
      if (e.key === "ArrowDown") next.y = clampPercent(tb.y + step);
      if (e.key === "ArrowLeft") next.x = clampPercent(tb.x - step);
      if (e.key === "ArrowRight") next.x = clampPercent(tb.x + step);
      patchTable(id, next);
      void persistTable(id, next);
    },
    [tables, patchTable, persistTable],
  );

  // ── Servicio de impresión de etiquetas por mesa (A4 vertical, una por página) ──
  const printLabels = useCallback(() => {
    const withGuests = tables.filter((tb) => tb.guests.length > 0);
    if (withGuests.length === 0) {
      addToast("info", t("distribucion.printNoGuests"));
      return;
    }
    // La generación del HTML de las etiquetas es lógica pura: vive en el
    // helper `buildLabelsHtml` para poder cubrirla con tests unitarios.
    const html = buildLabelsHtml(
      tables,
      { theme, background: background || "", cornerDecoration: cornerDecoration || "" },
      t,
    );
    const win = window.open("", "_blank");
    if (!win) {
      addToast("error", t("errors.generic"));
      return;
    }
    win.document.write(html);
    win.document.close();
    win.focus();
    // Espera a que las imágenes (fondo y esquinas) estén DECODIFICADAS antes
    // de imprimir: img.complete se cumple antes de decodificar y un fondo aún
    // sin decodificar salía negro en el papel.
    const waitForImages = async () => {
      try {
        await Promise.all(Array.from(win.document.images).map((img) => img.decode().catch(() => {})));
      } catch {}
      await new Promise((r) => setTimeout(r, 200));
      win.print();
    };
    void waitForImages();
  }, [tables, background, cornerDecoration, theme, addToast, t]);

  // ── Exportación XLSX (Excel/LibreOffice) de las mesas e invitados asignados ──
  const exportTablesXlsx = useCallback(async () => {
    // Sin mesas en la sección activa no hay nada que exportar.
    if ((tables || []).length === 0) {
      addToast("info", t("distribucion.noTables"));
      return;
    }
    const { exportToXlsx } = await import("../../lib/excel-utils");
    const { buildTablesSheet } = await import("../../lib/excel-builders");
    const sheet = buildTablesSheet(sections, activeSectionId, tables, t);
    exportToXlsx(
      `mesas_${(sections.find((s) => s.id === activeSectionId)?.name || "seccion").replace(/[^\p{L}\p{N}_-]/gu, "_").slice(0, 40)}`,
      [sheet],
    );
    addToast("success", t("tools.exportOk", { count: sheet.rows.length }));
  }, [sections, activeSectionId, tables, t, addToast]);

  const selected = tables.find((tb) => tb.id === selectedId);
  const availableGuests = confirmedGuests.filter((g) => !assignedNames.has(g.name));

  return (
    <div className="admin-flex--col" style={{ gap: "0.75rem", height: "100%", minHeight: 0 }}>
      {/* ── Controles de mesas (sección activa) ── */}
      {activeSectionId ? (
        <>
          {/* ── Selector de secciones activas (con borrar sección) ── */}
          <div className="admin-toolbar" style={{ flexWrap: "wrap", gap: "0.4rem", alignItems: "center" }}>
            <label className="setup-label" style={{ margin: 0 }}>
              {t("distribucion.section")}
              <select
                className="setup-input"
                value={activeSectionId}
                onChange={(e) => setActiveSectionId(e.target.value)}
                aria-label={t("distribucion.section")}
                style={{ marginLeft: "0.4rem" }}
              >
                {sections.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </label>
            <label className="setup-label" style={{ margin: 0 }}>
              {t("distribucion.sectionPlaceholder")}
              <input
                className="setup-input"
                value={newSectionName}
                maxLength={60}
                onChange={(e) => setNewSectionName(e.target.value)}
                style={{ marginLeft: "0.4rem" }}
              />
            </label>
            <button
              type="button"
              className="setup-button setup-button--compact"
              onClick={() => void addSection()}
            >
              {t("distribucion.addSection")}
            </button>
            <button
              type="button"
              className="setup-button setup-button--ghost--compact"
              onClick={() => void deleteSection(activeSectionId)}
            >
              {t("distribucion.deleteSection")}
            </button>
          </div>

          {/* ── Controles de mesas (sección activa) ── */}
          <div className="admin-toolbar" style={{ flexWrap: "wrap", gap: "0.4rem" }}>
            <button type="button" className="setup-button setup-button--compact" onClick={() => void addTable()}>
              {t("distribucion.addTable")}
            </button>
            <button type="button" className="setup-button setup-button--compact" onClick={() => void autoAssign()}>
              {t("distribucion.autoAssign")}
            </button>
            <button type="button" className="setup-button setup-button--compact" onClick={() => void printLabels()}>
              {t("distribucion.printLabels")}
            </button>
            <button type="button" className="setup-button setup-button--compact" onClick={() => void exportTablesXlsx()}>
              {t("distribucion.exportTables")}
            </button>
            <div className="admin-filter" style={{ display: "inline-flex", gap: "0.4rem", alignItems: "center" }}>
              <label className="setup-label" style={{ margin: 0 }}>
                {t("distribucion.shape")}
              </label>
              <select
                className="setup-input"
                value={newShape}
                onChange={(e) => setNewShape(e.target.value as Shape)}
                aria-label={t("distribucion.shape")}
              >
                {SHAPES.map((s) => (
                  <option key={s.key} value={s.key}>
                    {t(`distribucion.shape_${s.key}`)}
                  </option>
                ))}
              </select>
            </div>
          </div>

        <TableCanvas
          ref={mapRef}
          tables={tables as CanvasTable[]}
          selectedId={selectedId}
          onPointerDown={onPointerDown}
          onPointerMove={onPointerMove}
          onPointerUp={onPointerUp}
          onDeleteTable={(id) => void deleteTable(id)}
          onMoveSelectedByKey={moveSelectedByKey}
          emptyMapLabel={t("distribucion.emptyMap")}
          t={t}
        />
        </>
      ) : (
        <div className="setup-background-panel" style={{ textAlign: "center", padding: "2rem" }}>
          <p className="setup-help">{t("distribucion.createSectionFirst")}</p>
          <div style={{ display: "flex", gap: "0.5rem", justifyContent: "center", alignItems: "flex-end" }}>
            <label
              style={{ fontSize: "0.75rem", display: "block", textAlign: "left" }}
              htmlFor="distribucion.newSection"
            >
              {t("distribucion.sectionPlaceholder")}
              <input
                id="distribucion.newSection"
                className="setup-input"
                value={newSectionName}
                maxLength={60}
                onChange={(e) => setNewSectionName(e.target.value)}
              />
            </label>
            <button type="button" className="setup-button setup-button--compact" onClick={() => void addSection()}>
              {t("distribucion.addSection")}
            </button>
          </div>
        </div>
      )}

      {/* ── Panel de la mesa seleccionada ── */}
      {selected ? (
        <div className="setup-background-panel">
          <p className="setup-label">
            {t("distribucion.selectedTable")}: {selected.name}
          </p>
          <div
            className="admin-grid"
            style={{ gridTemplateColumns: "repeat(auto-fit, minmax(140px, 1fr))", gap: "0.5rem" }}
          >
            <label className="setup-label" style={{ margin: 0 }}>
              {t("distribucion.name")}
              <input
                className="setup-input"
                value={selected.name}
                maxLength={80}
                onChange={(e) => {
                  patchTable(selected.id, { name: e.target.value });
                  void persistTable(selected.id, { name: e.target.value });
                }}
              />
            </label>
            <label className="setup-label" style={{ margin: 0 }}>
              {t("distribucion.shape")}
              <select
                className="setup-input"
                value={selected.shape}
                onChange={(e) => {
                  const shape = e.target.value as Shape;
                  patchTable(selected.id, { shape });
                  void persistTable(selected.id, { shape });
                }}
              >
                {SHAPES.map((s) => (
                  <option key={s.key} value={s.key}>
                    {t(`distribucion.shape_${s.key}`)}
                  </option>
                ))}
              </select>
            </label>
            <label className="setup-label" style={{ margin: 0 }}>
              {t("distribucion.seats")}
              <input
                className="setup-input"
                type="number"
                min={0}
                max={100}
                value={selected.seats}
                onChange={(e) => {
                  const seats = Math.min(100, Math.max(0, Number(e.target.value) || 0));
                  patchTable(selected.id, { seats });
                  void persistTable(selected.id, { seats });
                }}
              />
            </label>
            {selected.shape === "circle" || selected.shape === "square" ? (
              <label className="setup-label" style={{ margin: 0 }}>
                {t("distribucion.sizePx")}
                <input
                  className="setup-input"
                  type="number"
                  min={20}
                  max={500}
                  value={selected.w}
                  onChange={(e) => {
                    const v = Math.min(500, Math.max(20, Number(e.target.value) || 90));
                    // Círculo y cuadrado: ancho y alto SIEMPRE iguales.
                    patchTable(selected.id, { w: v, h: v });
                    void persistTable(selected.id, { w: v, h: v });
                  }}
                />
              </label>
            ) : (
              <>
                <label className="setup-label" style={{ margin: 0 }}>
                  {t("distribucion.widthPx")}
                  <input
                    className="setup-input"
                    type="number"
                    min={20}
                    max={500}
                    value={selected.w}
                    onChange={(e) => {
                      const w = Math.min(500, Math.max(20, Number(e.target.value) || 90));
                      patchTable(selected.id, { w });
                      void persistTable(selected.id, { w });
                    }}
                  />
                </label>
                <label className="setup-label" style={{ margin: 0 }}>
                  {t("distribucion.heightPx")}
                  <input
                    className="setup-input"
                    type="number"
                    min={20}
                    max={500}
                    value={selected.h}
                    onChange={(e) => {
                      const h = Math.min(500, Math.max(20, Number(e.target.value) || 60));
                      patchTable(selected.id, { h });
                      void persistTable(selected.id, { h });
                    }}
                  />
                </label>
              </>
            )}
            <label className="setup-label" style={{ margin: 0 }}>
              {t("distribucion.rotation")}
              <input
                className="setup-input"
                type="number"
                min={-180}
                max={180}
                value={selected.rotation}
                onChange={(e) => {
                  const rotation = Math.min(180, Math.max(-180, Number(e.target.value) || 0));
                  patchTable(selected.id, { rotation });
                  void persistTable(selected.id, { rotation });
                }}
              />
            </label>
            <label className="setup-label" style={{ margin: 0 }}>
              {t("distribucion.positionX")}
              <input
                className="setup-input"
                type="number"
                min={0}
                max={100}
                step={0.5}
                value={selected.x}
                onChange={(e) => {
                  const x = clampPercent(Number(e.target.value) || 0);
                  patchTable(selected.id, { x });
                  void persistTable(selected.id, { x });
                }}
              />
            </label>
            <label className="setup-label" style={{ margin: 0 }}>
              {t("distribucion.positionY")}
              <input
                className="setup-input"
                type="number"
                min={0}
                max={100}
                step={0.5}
                value={selected.y}
                onChange={(e) => {
                  const y = clampPercent(Number(e.target.value) || 0);
                  patchTable(selected.id, { y });
                  void persistTable(selected.id, { y });
                }}
              />
            </label>
          </div>

          {/* Invitados asignados (solo confirmados) */}
          <div style={{ marginTop: "0.6rem" }}>
            <p className="setup-label" style={{ fontSize: "0.85rem" }}>
              {t("distribucion.guests")}
            </p>
            {selected.guests.length > 0 ? (
              <div style={{ display: "flex", flexWrap: "wrap", gap: "0.3rem" }}>
                {selected.guests.map((g, i) => (
                  <span
                    key={i}
                    style={{
                      display: "inline-flex",
                      alignItems: "center",
                      gap: "0.3rem",
                      fontSize: "0.78rem",
                      border: "1px solid var(--setup-border)",
                      borderRadius: "999px",
                      padding: "0.15rem 0.5rem",
                      color: "var(--setup-subtitle)",
                    }}
                  >
                    {g}
                    <button
                      type="button"
                      aria-label={t("distribucion.removeGuest")}
                      onClick={() => void removeGuest(selected.id, g)}
                      style={{
                        background: "none",
                        border: 0,
                        cursor: "pointer",
                        color: "#ef4444",
                        fontSize: "0.85rem",
                      }}
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>
            ) : (
              <p className="setup-help" style={{ margin: "0.2rem 0 0" }}>
                {t("distribucion.noGuestsAssigned")}
              </p>
            )}
            <select
              className="setup-input"
              value=""
              onChange={(e) => {
                if (e.target.value) void assignGuest(selected.id, e.target.value);
              }}
              style={{ marginTop: "0.4rem", maxWidth: "16rem" }}
              aria-label={t("distribucion.assignPlaceholder")}
            >
              <option value="">{t("distribucion.assignPlaceholder")}</option>
              {availableGuests.map((g) => (
                <option key={g.name} value={g.name}>
                  {g.name}
                </option>
              ))}
            </select>
            <p className="setup-help" style={{ margin: "0.3rem 0 0" }}>
              {t("distribucion.assignHint")}
            </p>
          </div>

          <button
            type="button"
            className="setup-button setup-button--danger setup-button--compact"
            style={{ marginTop: "0.6rem" }}
            onClick={() => void deleteTable(selected.id)}
          >
            {t("distribucion.deleteTable")}
          </button>
        </div>
      ) : null}
    </div>
  );
});

export default DistribucionTab;
