import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";

const stableT = (key: string) => key;
vi.mock("react-i18next", () => ({
  useTranslation: () => ({ t: stableT, i18n: { language: "es" } }),
}));

const mockGetDocs = vi.fn();
const mockAddDoc = vi.fn();
vi.mock("firebase/firestore", () => ({
  getDocs: (...args: unknown[]) => mockGetDocs(...args),
  addDoc: (...args: unknown[]) => mockAddDoc(...args),
  updateDoc: vi.fn(() => Promise.resolve()),
  deleteDoc: vi.fn(() => Promise.resolve()),
  writeBatch: vi.fn(() => ({
    delete: vi.fn(),
    update: vi.fn(),
    commit: vi.fn(() => Promise.resolve()),
  })),
  collection: (...args: unknown[]) => (args.length >= 6 ? "tables-ref" : "sections-ref"),
  doc: vi.fn(() => "doc-ref"),
  arrayUnion: (...v: unknown[]) => v,
  arrayRemove: (v: unknown) => v,
}));

vi.mock("../../../lib/firebase", () => ({
  db: "db-mock",
  rsvpByInviteRef: vi.fn(() => "rsvp-ref"),
}));
const mockAddToast = vi.fn();
vi.mock("../../../hooks/useToast", () => ({
  useToast: () => ({ addToast: mockAddToast }),
}));
const mockExportToXlsx = vi.fn();
vi.mock("../../../lib/excel-utils", () => ({
  exportToXlsx: (...a: unknown[]) => mockExportToXlsx(...a),
}));
vi.mock("../../../lib/excel-builders", () => ({
  buildTablesSheet: vi.fn(() => ({ name: "Mesas", headers: [], rows: [] })),
}));

// Confirmados del contexto RSVP compartido (v2.185): DistribucionTab ya no
// lee la colección por su cuenta; consume el onSnapshot en vivo de useRsvp.
const mockRsvpEntries = vi.hoisted(() => [] as Array<Record<string, unknown>>);
vi.mock("../../../contexts", () => ({
  useRsvpContext: () => ({ rsvpEntries: mockRsvpEntries }),
}));

import DistribucionTab from "../DistribucionTab";
import { writeBatch, updateDoc } from "firebase/firestore";

// Waits ampliados: imports dinámicos y timers reales superan los defaults bajo carga.
vi.setConfig({ testTimeout: 20000 });

describe("DistribucionTab", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    // Confirmados por defecto (Ana/Pepe sí, Luis no) para el contexto RSVP.
    mockRsvpEntries.splice(
      0,
      mockRsvpEntries.length,
      { id: "e1", guestName: "Ana", attendance: "yes", companions: 1 },
      { id: "e2", guestName: "Luis", attendance: "no", companions: 1 },
      { id: "e3", guestName: "Pepe", attendance: "yes", companions: 1 },
    );
    mockGetDocs.mockImplementation((ref: unknown) => {
      if (ref === "sections-ref") {
        return Promise.resolve({ docs: [{ id: "s1", data: () => ({ name: "Salón" }) }] });
      }
      // mesas de la sección activa
      return Promise.resolve({
        docs: [
          {
            id: "t1",
            data: () => ({
              name: "Mesa 1",
              shape: "circle",
              x: 50,
              y: 50,
              w: 12,
              h: 12,
              rotation: 0,
              seats: 8,
              guests: [],
            }),
          },
        ],
      });
    });
  });

  it("renders sections menu and shaped tables", async () => {
    render(<DistribucionTab inviteToken="tok" />);
    await screen.findByText("Salón");
    expect((await screen.findAllByText("Mesa 1")).length).toBeGreaterThan(0);
  });

  it("adds a table", async () => {
    mockAddDoc.mockResolvedValue({ id: "new1" });
    render(<DistribucionTab inviteToken="tok" />);
    await screen.findByText("Salón");
    fireEvent.click(screen.getByText("distribucion.addTable"));
    expect(mockAddDoc).toHaveBeenCalled();
  });

  it("auto-assigns confirmed guests to tables with free seats", async () => {
    // Se captura el batch creado (writeBatch) para inspeccionar sus updates.
    const batchSpies: Array<{ update: ReturnType<typeof vi.fn>; commit: ReturnType<typeof vi.fn> }> = [];
    vi.mocked(writeBatch).mockImplementation(() => {
      const b = { update: vi.fn(), delete: vi.fn(), set: vi.fn(), commit: vi.fn(() => Promise.resolve()) };
      batchSpies.push(b);
      return b;
    });
    render(<DistribucionTab inviteToken="tok" />);
    await screen.findByText("Salón");
    await screen.findByText("Mesa 1");
    // Espera a que los confirmados estén cargados antes de asignar.
    fireEvent.pointerDown(await screen.findByText("Mesa 1"), { clientX: 0, clientY: 0 });
    const select = (await screen.findByLabelText("distribucion.assignPlaceholder")) as HTMLSelectElement;
    await vi.waitFor(() => expect(Array.from(select.options).some((o) => o.textContent === "Pepe")).toBe(true));
    fireEvent.click(screen.getByText("distribucion.autoAssign"));
    await vi.waitFor(() => expect(batchSpies.length).toBeGreaterThan(0));
    // Ana y Pepe (confirmados) se asignan a la mesa con hueco; Luis no.
    const allGuests = batchSpies.flatMap((b) =>
      b.update.mock.calls.map((c) => c[1] as { guests?: unknown[] }).flatMap((x) => (x?.guests ?? []) as unknown[]),
    );
    expect(allGuests.length).toBeGreaterThan(0);
    expect(allGuests).toContain("Ana");
    expect(allGuests).toContain("Pepe");
    expect(allGuests).not.toContain("Luis");
    expect(mockAddToast).toHaveBeenCalledWith("success", expect.stringContaining("distribucion.autoAssignDone"));
  });

  it("only lists confirmed guests in the assign dropdown", async () => {
    render(<DistribucionTab inviteToken="tok" />);
    await screen.findByText("Salón");
    const mesa1 = await screen.findByText("Mesa 1");
    // selecciona la mesa
    fireEvent.pointerDown(mesa1, { clientX: 0, clientY: 0 });
    // el select de asignación solo incluye confirmados (Ana y Pepe, no Luis)
    const select = screen.getByLabelText("distribucion.assignPlaceholder") as HTMLSelectElement;
    const options = Array.from(select.options).map((o) => o.textContent);
    expect(options).toContain("Ana");
    expect(options).toContain("Pepe");
    expect(options).not.toContain("Luis");
  });

  it("asigna un invitado confirmado a la mesa", async () => {
    const { updateDoc } = await import("firebase/firestore");
    render(<DistribucionTab inviteToken="tok" />);
    await screen.findByText("Salón");
    const mesa1 = await screen.findByText("Mesa 1");
    fireEvent.pointerDown(mesa1, { clientX: 0, clientY: 0 });
    const select = screen.getByLabelText("distribucion.assignPlaceholder") as HTMLSelectElement;
    fireEvent.change(select, { target: { value: "Ana" } });
    await vi.waitFor(() => expect(updateDoc).toHaveBeenCalled());
    // arrayUnion (variádico) devuelve el array de nombres como hace Firestore.
    expect(updateDoc).toHaveBeenCalledWith(expect.anything(), expect.objectContaining({ guests: ["Ana"] }));
  });

  it("avisa cuando la mesa está llena", async () => {
    mockAddToast.mockClear();
    // Mesa con 1 plaza y 1 invitado ya asignado.
    mockRsvpEntries.splice(
      0,
      mockRsvpEntries.length,
      { id: "e1", guestName: "Ana", attendance: "yes" },
      { id: "e2", guestName: "Pepe", attendance: "yes" },
    );
    mockGetDocs.mockImplementation((ref: unknown) => {
      if (ref === "rsvp-ref") return Promise.resolve({ docs: [] });
      if (ref === "sections-ref") return Promise.resolve({ docs: [{ id: "s1", data: () => ({ name: "Salón" }) }] });
      return Promise.resolve({
        docs: [
          {
            id: "t1",
            data: () => ({
              name: "Mesa 1",
              shape: "circle",
              x: 50,
              y: 50,
              w: 90,
              h: 90,
              rotation: 0,
              seats: 1,
              guests: ["Ana"],
            }),
          },
        ],
      });
    });
    render(<DistribucionTab inviteToken="tok" />);
    await screen.findByText("Salón");
    const mesa1 = await screen.findByText("Mesa 1");
    fireEvent.pointerDown(mesa1, { clientX: 0, clientY: 0 });
    const select = screen.getByLabelText("distribucion.assignPlaceholder") as HTMLSelectElement;
    fireEvent.change(select, { target: { value: "Pepe" } });
    await vi.waitFor(() => expect(mockAddToast).toHaveBeenCalledWith("error", "distribucion.tableFull"));
  });

  it("quita un invitado asignado de la mesa", async () => {
    const { updateDoc } = await import("firebase/firestore");
    mockRsvpEntries.splice(
      0,
      mockRsvpEntries.length,
      { id: "e1", guestName: "Ana", attendance: "yes" },
    );
    mockGetDocs.mockImplementation((ref: unknown) => {
      if (ref === "rsvp-ref") return Promise.resolve({ docs: [] });
      if (ref === "sections-ref") return Promise.resolve({ docs: [{ id: "s1", data: () => ({ name: "Salón" }) }] });
      return Promise.resolve({
        docs: [
          {
            id: "t1",
            data: () => ({
              name: "Mesa 1",
              shape: "circle",
              x: 50,
              y: 50,
              w: 90,
              h: 90,
              rotation: 0,
              seats: 8,
              guests: ["Ana"],
            }),
          },
        ],
      });
    });
    render(<DistribucionTab inviteToken="tok" />);
    await screen.findByText("Salón");
    const mesa1 = await screen.findByText("Mesa 1");
    fireEvent.pointerDown(mesa1, { clientX: 0, clientY: 0 });
    fireEvent.click(screen.getByLabelText("distribucion.removeGuest"));
    await vi.waitFor(() => expect(updateDoc).toHaveBeenCalled());
    expect(updateDoc).toHaveBeenCalledWith(expect.anything(), expect.objectContaining({ guests: "Ana" }));
  });

  it("renderiza una mesa legada con forma rect en el mapa", async () => {
    // Formas legacy (rect/oval) que siguen leyéndose para no romper datos viejos.
    mockRsvpEntries.splice(0, mockRsvpEntries.length);
    mockGetDocs.mockImplementation((ref: unknown) => {
      if (ref === "rsvp-ref") return Promise.resolve({ docs: [] });
      if (ref === "sections-ref") return Promise.resolve({ docs: [{ id: "s1", data: () => ({ name: "Salón" }) }] });
      return Promise.resolve({
        docs: [
          {
            id: "t1",
            data: () => ({
              name: "Mesa Rect",
              shape: "rect",
              x: 50,
              y: 50,
              w: 130,
              h: 80,
              rotation: 0,
              seats: 8,
              guests: [],
            }),
          },
        ],
      });
    });
    render(<DistribucionTab inviteToken="tok" />);
    expect(await screen.findByText("Mesa Rect")).toBeInTheDocument();
  });

  it("locks width and height to the same value on circle/square", async () => {
    const { updateDoc } = await import("firebase/firestore");
    render(<DistribucionTab inviteToken="tok" />);
    await screen.findByText("Salón");
    const mesa1 = await screen.findByText("Mesa 1");
    fireEvent.pointerDown(mesa1, { clientX: 0, clientY: 0 });
    // La mesa del mock es círculo (w:12,h:12) → un único control de tamaño.
    const size = screen.getByLabelText("distribucion.sizePx") as HTMLInputElement;
    fireEvent.change(size, { target: { value: "120" } });
    expect(updateDoc as ReturnType<typeof vi.fn>).toHaveBeenCalledWith(
      expect.anything(),
      expect.objectContaining({ w: 120, h: 120 }),
    );
  });

  it("deletes a table from the map", async () => {
    const { deleteDoc } = await import("firebase/firestore");
    render(<DistribucionTab inviteToken="tok" />);
    await screen.findByText("Salón");
    const mesa1 = await screen.findByText("Mesa 1");
    fireEvent.pointerDown(mesa1, { clientX: 0, clientY: 0 });
    // Aparece la "✕" de borrado sobre la mesa seleccionada.
    fireEvent.click(screen.getByLabelText("distribucion.deleteTable"));
    expect(deleteDoc).toHaveBeenCalled();
  });

  it("prints one place card per guest with table name and custom style", async () => {
    // Una mesa con un invitado asignado.
    mockRsvpEntries.splice(0, mockRsvpEntries.length);
    mockGetDocs.mockImplementation((ref: unknown) => {
      if (ref === "rsvp-ref") return Promise.resolve({ docs: [] });
      if (ref === "sections-ref") return Promise.resolve({ docs: [{ id: "s1", data: () => ({ name: "Salón" }) }] });
      return Promise.resolve({
        docs: [
          {
            id: "t1",
            data: () => ({
              name: "Mesa 1",
              shape: "circle",
              x: 50,
              y: 50,
              w: 90,
              h: 90,
              rotation: 0,
              seats: 8,
              guests: ["Ana García"],
            }),
          },
        ],
      });
    });
    let html = "";
    const fakeWin = {
      document: {
        write: (s: string) => {
          html += s;
        },
        close: () => {},
      },
      focus: () => {},
      print: () => {},
    };
    vi.stubGlobal(
      "open",
      vi.fn(() => fakeWin),
    );
    render(
      <DistribucionTab
        inviteToken="tok"
        background="data:image/png;base64,BG"
        cornerDecoration="data:image/png;base64,CORNER"
      />,
    );
    await screen.findByText("Salón");
    await screen.findByText("Mesa 1");
    fireEvent.click(screen.getByText("distribucion.printLabels"));
    expect(html).toContain("Ana García");
    expect(html).toContain("Mesa 1");
    expect(html).toContain("data:image/png;base64,BG");
    expect(html).toContain("data:image/png;base64,CORNER");
    expect(html).toContain("lbl-page");
    // Mensajes de agradecimiento y disfrute en líneas separadas, y tarjeta vertical.
    expect(html).toContain("distribucion.labelThanks");
    expect(html).toContain("distribucion.labelEnjoy");
    expect(html).toContain("aspect-ratio:2/3");
    vi.unstubAllGlobals();
  });

  it("exporta las mesas e invitados asignados a Excel", async () => {
    mockGetDocs.mockImplementation((ref: unknown) => {
      if (ref === "rsvp-ref") return Promise.resolve({ docs: [] });
      if (ref === "sections-ref") return Promise.resolve({ docs: [{ id: "s1", data: () => ({ name: "Salón" }) }] });
      return Promise.resolve({
        docs: [
          {
            id: "t1",
            data: () => ({
              name: "Mesa 1",
              shape: "circle",
              x: 50,
              y: 50,
              w: 90,
              h: 90,
              rotation: 0,
              seats: 8,
              guests: ["Ana García"],
            }),
          },
        ],
      });
    });
    render(<DistribucionTab inviteToken="tok" />);
    await screen.findByText("Salón");
    await screen.findByText("Mesa 1");
    fireEvent.click(screen.getByText("distribucion.exportTables"));
    await vi.waitFor(() => expect(mockExportToXlsx).toHaveBeenCalled(), { timeout: 15000 });
  });

  it("elimina la sección activa", async () => {
    window.confirm = vi.fn(() => true);
    const { deleteDoc } = await import("firebase/firestore");
    render(<DistribucionTab inviteToken="tok" />);
    await screen.findByText("Salón");
    fireEvent.click(screen.getByText("distribucion.deleteSection"));
    await vi.waitFor(() => expect(deleteDoc).toHaveBeenCalled());
  });

  it("añade una sección nueva y la activa", async () => {
    mockAddDoc.mockResolvedValue({ id: "s9" });
    render(<DistribucionTab inviteToken="tok" />);
    await screen.findByText("Salón");
    fireEvent.change(screen.getByLabelText("distribucion.sectionPlaceholder"), { target: { value: "Jardín" } });
    fireEvent.click(screen.getByText("distribucion.addSection"));
    await vi.waitFor(() => expect(mockAddDoc).toHaveBeenCalled());
    expect(mockAddDoc).toHaveBeenCalledWith(expect.anything(), expect.objectContaining({ name: "Jardín" }));
  });

  it("cambia a otra sección y carga sus mesas", async () => {
    mockGetDocs.mockImplementation((ref: unknown) => {
      if (ref === "rsvp-ref") return Promise.resolve({ docs: [] });
      if (ref === "sections-ref")
        return Promise.resolve({
          docs: [
            { id: "s1", data: () => ({ name: "Salón" }) },
            { id: "s2", data: () => ({ name: "Jardín" }) },
          ],
        });
      // Mesas de la sección activa (cambian según activeSectionId; el mock
      // devuelve la mesa de "Jardín" cuando se cambia).
      return Promise.resolve({
        docs: [
          {
            id: "t2",
            data: () => ({
              name: "Mesa Jardín",
              shape: "circle",
              x: 50,
              y: 50,
              w: 90,
              h: 90,
              rotation: 0,
              seats: 6,
              guests: [],
            }),
          },
        ],
      });
    });
    render(<DistribucionTab inviteToken="tok" />);
    await screen.findByText("Salón");
    fireEvent.click(screen.getByText("Jardín"));
    // La sección activa cambia y se muestran sus mesas.
    await vi.waitFor(() => expect(screen.getByText("Mesa Jardín")).toBeInTheDocument());
  });

  it("arrastra una mesa y persiste su nueva posición", async () => {
    const { updateDoc } = await import("firebase/firestore");
    // El mapa usa getBoundingClientRect: se mockea con un rect fijo de 100x100.
    vi.spyOn(HTMLElement.prototype, "getBoundingClientRect").mockReturnValue({
      width: 100,
      height: 100,
      left: 0,
      top: 0,
      right: 100,
      bottom: 100,
      x: 0,
      y: 0,
      toJSON: () => ({}),
    } as DOMRect);
    render(<DistribucionTab inviteToken="tok" />);
    await screen.findByText("Salón");
    const mesa = await screen.findByText("Mesa 1");
    fireEvent.pointerDown(mesa, { pointerId: 1, clientX: 50, clientY: 50 });
    // Arrastra hasta (80, 20) → persistTable → updateDoc.
    const map = document.querySelector(".distribucion-map") as HTMLElement;
    fireEvent.pointerMove(map, { pointerId: 1, clientX: 80, clientY: 20 });
    fireEvent.pointerUp(map, { pointerId: 1 });
    await vi.waitFor(() => expect(updateDoc).toHaveBeenCalled());
    vi.restoreAllMocks();
  });

  describe("DistribucionTab — ramas límite (teclado, etiquetas, export)", () => {
    // Limpieza por test: updateDoc es un mock de módulo compartido y acumularía
    // llamadas entre tests volviendo no deterministas el assert "no llamado".
    beforeEach(() => {
      vi.mocked(updateDoc).mockClear();
    });
    /** Monta la tab con la mesa por defecto y devuelve su elemento accesible. */
    async function mountWithTable(guests: string[] = []) {
      mockRsvpEntries.splice(
        0,
        mockRsvpEntries.length,
        { id: "e1", guestName: "Ana", attendance: "yes" },
      );
      mockGetDocs.mockImplementation((ref: unknown) => {
        if (ref === "rsvp-ref") return Promise.resolve({ docs: [] });
        if (ref === "sections-ref") return Promise.resolve({ docs: [{ id: "s1", data: () => ({ name: "Salón" }) }] });
        return Promise.resolve({
          docs: [
            {
              id: "t1",
              data: () => ({
                name: "Mesa 1",
                shape: "circle",
                x: 50,
                y: 50,
                w: 12,
                h: 12,
                rotation: 0,
                seats: 8,
                guests,
              }),
            },
          ],
        });
      });
      render(<DistribucionTab inviteToken="tok" />);
      await screen.findByText("Salón");
      // Las mesas se cargan en un efecto aparte (depende de activeSectionId),
      // un commit después de las secciones: esperar la mesa evita carreras
      // en runners lentos (CI node 22) donde getByRole llegaba antes.
      await screen.findByRole("button", { name: "distribucion.tableAccessible" });
    }

    it("mueve la mesa con flechas (paso normal) y persiste", async () => {
      await mountWithTable();
      const tb = screen.getByRole("button", { name: "distribucion.tableAccessible" });
      fireEvent.keyDown(tb, { key: "ArrowUp" });
      await waitFor(() => expect(vi.mocked(updateDoc)).toHaveBeenCalled(), { timeout: 15000 });
    });

    it("ignora teclas que no sean flechas", async () => {
      await mountWithTable();
      const writes = vi.mocked(updateDoc).mock.calls.length;
      fireEvent.keyDown(screen.getByRole("button", { name: "distribucion.tableAccessible" }), { key: "k" });
      expect(vi.mocked(updateDoc).mock.calls.length).toBe(writes);
    });

    it("avisa al imprimir etiquetas si ninguna mesa tiene invitados", async () => {
      await mountWithTable([]);
      fireEvent.click(screen.getByText("distribucion.printLabels"));
      await waitFor(() => expect(mockAddToast).toHaveBeenCalledWith("info", "distribucion.printNoGuests"));
    });

    it("imprime etiquetas con invitados vía ventana emergente", async () => {
      await mountWithTable(["Ana"]);
      const printSpy = vi.fn();
      const winStub = { document: { write: vi.fn(), close: vi.fn(), images: [] }, focus: vi.fn(), print: printSpy };
      const openSpy = vi.spyOn(window, "open").mockReturnValue(winStub as unknown as Window);
      fireEvent.click(screen.getByText("distribucion.printLabels"));
      await waitFor(() => expect(printSpy).toHaveBeenCalled(), { timeout: 15000 });
      const html = winStub.document.write.mock.calls[0]![0] as string;
      expect(html).toContain("Ana");
      openSpy.mockRestore();
    });

    it("exporta XLSX cuando hay mesas en la sección activa", async () => {
      await mountWithTable();
      fireEvent.click(screen.getByText("distribucion.exportTables"));
      // El export usa import() dinámico de excel-utils: 1s default se queda corto.
      await waitFor(() => expect(mockExportToXlsx).toHaveBeenCalled(), { timeout: 15000 });
    });

    it("avisa si no hay mesas que exportar", async () => {
      mockRsvpEntries.splice(0, mockRsvpEntries.length);
      mockGetDocs.mockImplementation((ref: unknown) => {
        if (ref === "rsvp-ref") return Promise.resolve({ docs: [] });
        if (ref === "sections-ref") return Promise.resolve({ docs: [{ id: "s1", data: () => ({ name: "Salón" }) }] });
        return Promise.resolve({ docs: [] });
      });
      render(<DistribucionTab inviteToken="tok" />);
      await screen.findByText("Salón");
      fireEvent.click(screen.getByText("distribucion.exportTables"));
      await waitFor(() => expect(mockAddToast).toHaveBeenCalledWith("info", "distribucion.noTables"));
    });

    it("edita las propiedades numéricas de la mesa (panel de propiedades)", async () => {
      const { updateDoc: updateDocReal } = await import("firebase/firestore");
      vi.mocked(updateDocReal).mockClear();
      await mountWithTable();
      // Selecciona la mesa (círculo por defecto) → panel de propiedades.
      const mesa1 = await screen.findByText("Mesa 1");
      fireEvent.pointerDown(mesa1, { clientX: 0, clientY: 0 });
      await waitFor(() => expect(screen.queryByLabelText("distribucion.assignPlaceholder")).not.toBeNull());
      // Tamaño (círculo/cuadrado: ancho=alto), capacidad, rotación, posición.
      fireEvent.change(screen.getByLabelText("distribucion.sizePx"), { target: { value: "320" } });
      fireEvent.change(screen.getByLabelText("distribucion.seats"), { target: { value: "10" } });
      fireEvent.change(screen.getByLabelText("distribucion.rotation"), { target: { value: "45" } });
      fireEvent.change(screen.getByLabelText("distribucion.positionX"), { target: { value: "60" } });
      fireEvent.change(screen.getByLabelText("distribucion.positionY"), { target: { value: "30" } });
      // Se acotan los valores fuera de rango (500, 180, 100) y se persisten.
      fireEvent.change(screen.getByLabelText("distribucion.sizePx"), { target: { value: "999" } });
      expect(updateDocReal).toHaveBeenCalled();
      const updates = vi.mocked(updateDocReal).mock.calls.map((c) => c[1] as unknown as Record<string, unknown>);
      // Cada campo se persiste en su propia llamada; los valores fuera de rango
      // se acotan (tamaño 999 → 500).
      expect(updates).toContainEqual(expect.objectContaining({ w: 320, h: 320 }));
      expect(updates).toContainEqual(expect.objectContaining({ seats: 10 }));
      expect(updates).toContainEqual(expect.objectContaining({ rotation: 45 }));
      expect(updates).toContainEqual(expect.objectContaining({ x: 60 }));
      expect(updates).toContainEqual(expect.objectContaining({ y: 30 }));
      expect(updates).toContainEqual(expect.objectContaining({ w: 500, h: 500 }));
    });
  });

  it("cambia la forma a rectángulo (sizePx→w/h px) y borra la mesa", async () => {
    const { updateDoc: u, deleteDoc: del } = await import("firebase/firestore");
    vi.mocked(u).mockClear();
    vi.mocked(del).mockClear();
    mockRsvpEntries.splice(0, mockRsvpEntries.length, { id: "e1", guestName: "Ana", attendance: "yes" });
    mockGetDocs.mockImplementation((ref: unknown) => {
      if (ref === "rsvp-ref") return Promise.resolve({ docs: [] });
      if (ref === "sections-ref") return Promise.resolve({ docs: [{ id: "s1", data: () => ({ name: "Salón" }) }] });
      return Promise.resolve({
        docs: [{ id: "t1", data: () => ({ name: "Mesa 1", shape: "rect", x: 50, y: 50, w: 90, h: 90, rotation: 0, seats: 8, guests: [] }) }],
      });
    });
    render(<DistribucionTab inviteToken="tok" />);
    await screen.findByText("Salón");
    fireEvent.pointerDown(await screen.findByText("Mesa 1"), { clientX: 0, clientY: 0 });
    await waitFor(() => expect(screen.queryByLabelText("distribucion.assignPlaceholder")).not.toBeNull());
    // Mesa rect (legacy): existen los inputs de ancho/alto por separado.
    fireEvent.change(screen.getByLabelText("distribucion.widthPx"), { target: { value: "300" } });
    fireEvent.change(screen.getByLabelText("distribucion.heightPx"), { target: { value: "200" } });
    expect(vi.mocked(u)).toHaveBeenCalled();
    const updates = vi.mocked(u).mock.calls.map((c) => c[1] as unknown as Record<string, unknown>);
    expect(updates).toContainEqual(expect.objectContaining({ w: 300 }));
    expect(updates).toContainEqual(expect.objectContaining({ h: 200 }));
    // Borra la mesa: deleteDoc se llama y la tarjeta desaparece.
    fireEvent.click(screen.getByText("distribucion.deleteTable"));
    await waitFor(() => expect(vi.mocked(del)).toHaveBeenCalled());
  });

  it("el borrado de mesa fallido muestra error sin romper", async () => {
    const { deleteDoc: del } = await import("firebase/firestore");
    vi.mocked(del).mockRejectedValueOnce(new Error("boom"));
    mockRsvpEntries.splice(0, mockRsvpEntries.length, { id: "e1", guestName: "Ana", attendance: "yes" });
    mockGetDocs.mockImplementation((ref: unknown) => {
      if (ref === "rsvp-ref") return Promise.resolve({ docs: [] });
      if (ref === "sections-ref") return Promise.resolve({ docs: [{ id: "s1", data: () => ({ name: "Salón" }) }] });
      return Promise.resolve({
        docs: [{ id: "t1", data: () => ({ name: "Mesa 1", shape: "circle", x: 50, y: 50, w: 90, h: 90, rotation: 0, seats: 8, guests: [] }) }],
      });
    });
    render(<DistribucionTab inviteToken="tok" />);
    await screen.findByText("Salón");
    fireEvent.pointerDown(await screen.findByText("Mesa 1"), { clientX: 0, clientY: 0 });
    await waitFor(() => expect(screen.getByText("distribucion.deleteTable")).toBeInTheDocument());
    fireEvent.click(screen.getByText("distribucion.deleteTable"));
    await waitFor(() => expect(mockAddToast).toHaveBeenCalledWith("error", "errors.generic"));
  });

  it("cambia la forma nueva desde la barra y la aplica al añadir una mesa", async () => {
    mockAddDoc.mockResolvedValue({ id: "new2" });
    render(<DistribucionTab inviteToken="tok" />);
    await screen.findByText("Salón");
    // Sin mesa seleccionada solo existe el selector de forma de la barra.
    const sel = screen.getByLabelText("distribucion.shape") as HTMLSelectElement;
    fireEvent.change(sel, { target: { value: "square" } });
    fireEvent.click(screen.getByText("distribucion.addTable"));
    await vi.waitFor(() => expect(mockAddDoc).toHaveBeenCalled());
    expect(mockAddDoc).toHaveBeenCalledWith(expect.anything(), expect.objectContaining({ shape: "square" }));
  });

  it("edita el nombre y la forma de la mesa desde el panel de la seleccionada", async () => {
    const { updateDoc: u } = await import("firebase/firestore");
    render(<DistribucionTab inviteToken="tok" />);
    await screen.findByText("Salón");
    fireEvent.pointerDown(await screen.findByText("Mesa 1"), { clientX: 0, clientY: 0 });
    const nameInput = await screen.findByLabelText("distribucion.name");
    fireEvent.change(nameInput, { target: { value: "Mesa VIP" } });
    const shapeSelects = screen.getAllByLabelText("distribucion.shape");
    // El primero en el DOM es el del panel de la seleccionada (persiste);
    // el segundo es el de la barra (solo define la forma de mesas nuevas).
    fireEvent.change(shapeSelects[0]!, { target: { value: "square" } });
    await vi.waitFor(() => expect(vi.mocked(u)).toHaveBeenCalled());
    const updates = vi.mocked(u).mock.calls.map((c) => c[1] as unknown as Record<string, unknown>);
    expect(updates).toContainEqual(expect.objectContaining({ name: "Mesa VIP" }));
    expect(updates).toContainEqual(expect.objectContaining({ shape: "square" }));
  });
});
