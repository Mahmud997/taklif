import { memo, useCallback, useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { doc, writeBatch, serverTimestamp } from "firebase/firestore";
import { db } from "../../lib/firebase";
import Pagination from "../../components/Pagination";
import EmptyState from "../../components/EmptyState";
import { useToast } from "../../hooks/useToast";
import { useColumnSort, type SortableColumn } from "../../lib/useColumnSort";
import { SortableTh } from "../../components/SortableTh";
import { withWriteRetry } from "../../lib/async-utils";
import { encrypt } from "../../lib/crypto-utils";
import { parseDietaryInfo } from "../../lib/rsvp-utils";
import { parseTransportDepartures } from "../../lib/transport-utils";
import { type Departure } from "../sections/rsvp/derive";
import { getDietaryItems, getChildrenDietary, formatMenuLabel, normalizeManualName, buildManualMainPayload, buildManualCompanionPayload } from "./attendance-core";
import { AttendanceEditModal } from "./AttendanceEditModal";
import type { EditingState, EditingCompanion } from "./attendance-edit-types";

interface RsvpEntry {
  id: string;
  rsvpType?: "main" | "companion";
  guestName: string;
  attendance: string;
  companions: number;
  dietaryInfo: string;
  attendees?: { name: string; menu: string; allergies: string[] }[];
  mealChoice?: string;
  guestNames?: string;
  submittedAt: string;
  mainGuestName?: string;
  companionDocIds?: string[];
  healthConsent?: boolean;
  transportChoice?: string;
  transportMode?: string;
  transportTime?: string;
  companionTransportChoices?: string[];
  companionTransportModes?: string[];
  mainGuestDocId?: string;
  /// Datos de acompañantes (arrays paralelos que guarda el doc principal).
  companionNames?: string[];
  companionMenus?: string[];
  companionAllergies?: string[][];
  companionAllergiesOther?: string[];
  /// Niños declarados por el invitado principal (contador + alergias de grupo).
  childrenCount?: number;
  childrenAllergies?: string[];
  childrenAllergiesOther?: string;
}

interface AttendanceTabProps {
  searchQuery: string;
  setSearchQuery: (value: string) => void;
  attendanceFilter: string;
  setAttendanceFilter: (filter: string) => void;
  filteredEntries: RsvpEntry[];
  exportPdf: () => void;
  rsvpEntries: RsvpEntry[];
  handleClearRsvpEntries: () => void;
  handleDeleteRsvpEntries: (ids: string[]) => void;
  formatDate: (date: string) => string;
  transportDepartures?: string;
  /** Token de la invitación (para añadir/editar respuestas manuales,
   *  p. ej. invitaciones físicas a personas sin dispositivo). */
  inviteToken?: string;
  /** Se invoca tras añadir/editar manualmente para recargar la lista. */
  onDataChanged?: () => void;
  /** Si la invitación tiene menú (menuEnabled === true) el modal de edición
   *  ofrece la selección de plato (carne/pescado/vegano). */
  menuEnabled?: boolean;
  /** Límite de plazas configurado (informativo: el canal ya no bloquea el RSVP). */
  rsvpCapacity?: string;
}

const PAGE_SIZES = [10, 25, 50, 100];

/** Icono de lápiz (editar). SVG inline: sin dependencias ni emojis. */
function IconEdit() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M12 20h9" />
      <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z" />
    </svg>
  );
}

/** Icono de papelera (eliminar). SVG inline: sin dependencias ni emojis. */
function IconTrash() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M3 6h18" />
      <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6" />
      <path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
      <line x1="10" y1="11" x2="10" y2="17" />
      <line x1="14" y1="11" x2="14" y2="17" />
    </svg>
  );
}

/**
 * Fila memoizada de la tabla de asistencia (v2.187): antes TODAS las filas
 * paginadas se re-renderizaban e recalculaban sus etiquetas (menú, dietas,
 * transporte) en cada interacción (checkbox, cambio de página, edición).
 * Con props estables (misma entrada, mismo estado, callbacks memoizados),
 * solo cambia la fila afectada.
 */
const AttendanceRow = memo(function AttendanceRow({
  entry,
  isSelected,
  inviteToken,
  onToggle,
  onEdit,
  onDelete,
  resolveTransportLabel,
  formatDate: formatDateFn,
}: {
  entry: RsvpEntry;
  isSelected: boolean;
  inviteToken: string | undefined;
  onToggle: (id: string) => void;
  onEdit: (entry: RsvpEntry) => void;
  onDelete: (ids: string[]) => void;
  resolveTransportLabel: (mode: string, choice: string, time: string) => string;
  formatDate: (submittedAt: string) => string;
}) {
  const { t } = useTranslation();
  const isCompanion = entry.rsvpType === "companion";
  const attending = entry.attendance === "yes";
  const menuLines = entry.attendees?.length
    ? entry.attendees
        .map((a) => (a.menu ? `${a.name}: ${formatMenuLabel(a.menu || "", t)}` : null))
        .filter((x): x is string => x !== null)
    : formatMenuLabel(entry.mealChoice || "", t)
      ? [formatMenuLabel(entry.mealChoice || "", t)!]
      : [];
  const dietLines = entry.attendees?.length
    ? entry.attendees
        .filter((a) => a.allergies?.length)
        .map((a) => `${a.name}: ${a.allergies.join(", ")}`)
    : attending
      ? getDietaryItems(entry.dietaryInfo || "")
      : [];
  const crossed = !attending ? { textDecoration: "line-through", opacity: 0.4 } : {};
  const transportLabel = resolveTransportLabel(
    entry.transportMode || "",
    entry.transportChoice || "",
    entry.transportTime || "",
  );
  const consentBadges: string[] = [];
  if (entry.healthConsent) consentBadges.push(t("attendance.consentHealth"));

  return (
    <tr>
      <td>
        <div style={{ display: "flex", alignItems: "center", gap: "0.3rem", justifyContent: "center" }}>
          <input
            type="checkbox"
            checked={isSelected}
            onChange={() => onToggle(entry.id)}
            aria-label={t("attendance.selectEntry", { name: entry.guestName })}
          />
          {inviteToken ? (
            <>
              <button
                type="button"
                className="setup-button setup-button--ghost setup-button--compact"
                style={{ padding: "0.2rem 0.45rem", display: "inline-flex", alignItems: "center" }}
                onClick={() => onEdit(entry)}
                aria-label={`${t("attendance.editManual")}: ${entry.guestName}`}
                title={t("attendance.editManual")}
              >
                <IconEdit />
              </button>
              <button
                type="button"
                className="setup-button setup-button--ghost setup-button--compact"
                style={{ padding: "0.2rem 0.45rem", display: "inline-flex", alignItems: "center", color: "var(--danger, #c0392b)" }}
                onClick={() => onDelete([entry.id])}
                aria-label={`${t("attendance.deleteEntry")}: ${entry.guestName}`}
                title={t("attendance.deleteEntry")}
              >
                <IconTrash />
              </button>
            </>
          ) : null}
        </div>
      </td>
      <td className="admin-table__name" style={{ fontWeight: isCompanion ? 400 : 600 }}>
        {entry.guestName}
      </td>
      <td style={{ fontSize: "0.78rem", color: "var(--setup-muted)" }}>
        {isCompanion && entry.mainGuestName ? entry.mainGuestName : "—"}
      </td>
      <td>
        <span className={`admin-badge admin-badge--${entry.attendance}`}>
          {attending ? t("attendance.attendingValue") : t("attendance.notAttendingValue")}
        </span>
      </td>
      <td>
        <div style={crossed}>
          {attending ? (
            <div style={{ display: "flex", flexDirection: "column", gap: "0.15rem" }}>
              {menuLines.length > 0 ? (
                menuLines.map((line, i) => (
                  <span key={i} style={{ fontSize: "0.78rem" }}>
                    {line}
                  </span>
                ))
              ) : (
                <span style={{ fontSize: "0.78rem" }}>—</span>
              )}
            </div>
          ) : (
            <span style={{ fontSize: "0.78rem" }}>—</span>
          )}
        </div>
      </td>
      <td>
        <div style={crossed}>
          {attending && dietLines.length > 0 ? (
            <div style={{ display: "flex", flexDirection: "column", gap: "0.15rem" }}>
              {dietLines.map((line, i) => (
                <span key={i} style={{ fontSize: "0.78rem" }}>
                  {line}
                </span>
              ))}
            </div>
          ) : (
            <span style={{ fontSize: "0.78rem" }}>—</span>
          )}
        </div>
      </td>
      <td>
        <div style={crossed}>
          <span style={{ fontSize: "0.78rem" }}>
            {attending && Number(entry.childrenCount) > 0 ? String(entry.childrenCount) : "—"}
          </span>
        </div>
      </td>
      <td>
        <div style={crossed}>
          {attending && getChildrenDietary(entry).length > 0 ? (
            <span style={{ fontSize: "0.78rem" }}>{getChildrenDietary(entry).join(", ")}</span>
          ) : (
            <span style={{ fontSize: "0.78rem" }}>—</span>
          )}
        </div>
      </td>
      <td>
        <div style={crossed}>
          <span style={{ fontSize: "0.78rem" }}>{attending ? transportLabel : "—"}</span>
        </div>
      </td>
      <td>
        <div style={crossed}>
          {attending && consentBadges.length > 0 ? (
            <div style={{ display: "flex", flexDirection: "column", gap: "0.15rem" }}>
              {consentBadges.map((b, i) => (
                <span key={i} style={{ fontSize: "0.72rem", color: "var(--setup-accent)" }}>
                  {b}
                </span>
              ))}
            </div>
          ) : (
            <span style={{ fontSize: "0.78rem" }}>—</span>
          )}
        </div>
      </td>
      <td className="admin-table__date" style={{ whiteSpace: "nowrap", fontSize: "0.78rem" }}>
        {formatDateFn(entry.submittedAt)}
      </td>
    </tr>
  );
});

const AttendanceTab = memo(function AttendanceTab(props: AttendanceTabProps) {
  const {
    searchQuery,
    setSearchQuery,
    attendanceFilter,
    setAttendanceFilter,
    filteredEntries,
    exportPdf,
    rsvpEntries,
    handleClearRsvpEntries,
    handleDeleteRsvpEntries,
    formatDate,
    transportDepartures,
    inviteToken,
    onDataChanged,
    menuEnabled,
    rsvpCapacity,
  } = props;
  const { t } = useTranslation();
  const { addToast } = useToast();
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(25);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  // ── Añadir/editar respuesta manualmente (invitaciones físicas) ──
  // El estado de edición incluye TODOS los datos modificables del invitado
  // (menú, alergias, transporte y acompañantes) para poder corregir cualquier
  // campo, también de respuestas enviadas por los propios invitados.
  const [editing, setEditing] = useState<EditingState | null>(null);
  const [savingManual, setSavingManual] = useState(false);

  /** Lista de salidas de transporte (se parsea de la config de la invitación). */
  const departuresList: Departure[] = useMemo(() => {
    try {
      return parseTransportDepartures(transportDepartures || "");
    } catch {
      return [];
    }
  }, [transportDepartures]);

  const openEdit = useCallback((entry: RsvpEntry) => {
    const parsed = parseDietaryInfo(entry.dietaryInfo || "", !!entry.mealChoice);
    // Acompañantes: el hook de RSVP reconstruye los arrays paralelos del main
    // desde los docs de acompañantes, así que aquí se leen tal cual.
    const companions: EditingCompanion[] = (entry.companionNames ?? []).map((name: string, i: number) => {
      const rawAl: unknown = entry.companionAllergies?.[i] ?? "";
      const selection = Array.isArray(rawAl)
        ? rawAl.filter((x): x is string => typeof x === "string")
        : parseDietaryInfo(String(rawAl), false).dietarySelection;
      return {
        docId: entry.companionDocIds?.[i],
        name: name ?? "",
        menu: entry.companionMenus?.[i] ?? "",
        allergies: selection,
        other: entry.companionAllergiesOther?.[i] ?? "",
      };
    });
    setEditing({
      id: entry.id,
      companionDocIds: entry.companionDocIds ?? [],
      name: entry.guestName || "",
      attendance: entry.attendance === "yes" ? "yes" : "no",
      notes: entry.dietaryInfo || "",
      mealChoice: entry.mealChoice || "",
      allergySelection: parsed.dietarySelection,
      allergyOther: parsed.dietaryOther || "",
      transportMode: entry.transportMode || "own",
      transportChoice: entry.transportChoice || "",
      companions,
    });
  }, []);

  const openAdd = useCallback(() => {
    setEditing({
      companionDocIds: [],
      name: "",
      attendance: "yes",
      notes: "",
      mealChoice: "",
      allergySelection: [],
      allergyOther: "",
      transportMode: "own",
      transportChoice: "",
      companions: [],
    });
  }, []);

  /** CRUD del estado del modal sobre la lista de acompañantes. */
  const addCompanion = useCallback(() => {
    setEditing((prev) =>
      prev ? { ...prev, companions: [...prev.companions, { name: "", menu: "", allergies: [], other: "" }] } : prev,
    );
  }, []);
  const removeCompanionAt = useCallback((index: number) => {
    setEditing((prev) =>
      prev ? { ...prev, companions: prev.companions.filter((_, i) => i !== index) } : prev,
    );
  }, []);
  const patchCompanion = useCallback((index: number, patch: Partial<EditingCompanion>) => {
    setEditing((prev) =>
      prev
        ? { ...prev, companions: prev.companions.map((c, i) => (i === index ? { ...c, ...patch } : c)) }
        : prev,
    );
  }, []);
  const toggleCompanionAllergy = useCallback((index: number, allergy: string) => {
    setEditing((prev) =>
      prev
        ? {
            ...prev,
            companions: prev.companions.map((c, i) =>
              i === index
                ? { ...c, allergies: c.allergies.includes(allergy) ? c.allergies.filter((a) => a !== allergy) : [...c.allergies, allergy] }
                : c,
            ),
          }
        : prev,
    );
  }, []);

  /** Guarda la respuesta manual: crea si no tiene id, actualiza si lo tiene.
   *  CASOS CATASTRÓFICOS: sin token o sin nombre → no hace nada; fallo de red
   *  → toast de error sin corromper el estado. */
  const saveManual = useCallback(async () => {
    if (!editing || !inviteToken) return;
    const name = editing.name.trim();
    if (!name) {
      addToast("error", t("attendance.manualNameRequired"));
      return;
    }
    setSavingManual(true);
    try {
      const now = serverTimestamp();
      const isUpdate = Boolean(editing.id);
      // Id determinista para nuevos mains (misma convención que antes).
      const norm = normalizeManualName(name);
      const mainId = editing.id ?? `main_manual_${norm || "invitado"}_${crypto.randomUUID()}`;
      const attending = editing.attendance === "yes";
      const complements = editing.companions.filter((c) => c.name.trim());
      // Esquema que cumple la regla create/update de rsvpResponses/.../responses
      // (whitelist de campos; todos los usados están permitidos).
      const payload = await buildManualMainPayload(
        {
          name,
          attendance: editing.attendance,
          mealChoice: editing.mealChoice,
          allergySelection: editing.allergySelection,
          allergyOther: editing.allergyOther,
          transportMode: editing.transportMode,
          transportChoice: editing.transportChoice,
          companions: complements.map((c) => ({ name: c.name, menu: c.menu, allergies: c.allergies, other: c.other })),
        },
        inviteToken,
        now,
        encrypt,
      );
      const batch = writeBatch(db);
      if (isUpdate) {
        batch.update(doc(db, "rsvpResponses", inviteToken, "responses", editing.id!), payload);
      } else {
        batch.set(doc(db, "rsvpResponses", inviteToken, "responses", mainId), payload);
        // El contador del grupo debe existir e incrementarse para que la regla
        // create (exists + count < 500) valide.
        await withWriteRetry(async () => {
          const { getDoc } = await import("firebase/firestore");
          const counterRef = doc(db, "rsvpResponses", inviteToken);
          const snap = await getDoc(counterRef);
          if (!snap.exists()) batch.set(counterRef, { count: 1 });
          else batch.update(counterRef, { count: snap.data()!.count + 1 });
        });
      }
      // Acompañantes: cada uno se guarda en su doc (con menú y alergias) igual
      // que hace el flujo público, enlazado al main. Los niños ya no son
      // compañeros individuales: se declaran con contador en el principal.
      if (attending && complements.length) {
        for (const c of complements) {
          const compId = c.docId ?? `comp_manual_${norm || "invitado"}_${crypto.randomUUID()}`;
          const compPayload = await buildManualCompanionPayload(
            { name: c.name, allergies: c.allergies, other: c.other },
            inviteToken,
            now,
            mainId,
            name.slice(0, 120),
            encrypt,
          );
          if (c.docId) batch.update(doc(db, "rsvpResponses", inviteToken, "responses", compId), compPayload);
          else batch.set(doc(db, "rsvpResponses", inviteToken, "responses", compId), compPayload);
        }
      }
      // Borra los docs de acompañantes que ya no están en la lista: evita
      // filas huérfanas en la tabla (la sesión de admin lo permite).
      const keptDocIds = new Set(complements.map((c) => c.docId).filter((d): d is string => Boolean(d)));
      for (const oldId of editing.companionDocIds) {
        if (!keptDocIds.has(oldId)) batch.delete(doc(db, "rsvpResponses", inviteToken, "responses", oldId));
      }
      await withWriteRetry(() => batch.commit());
      addToast("success", t(isUpdate ? "attendance.manualUpdated" : "attendance.manualAdded"));
      setEditing(null);
      if (onDataChanged) onDataChanged();
    } catch (err) {
      const code = err && typeof err === "object" && "code" in err ? String((err as { code?: unknown }).code) : "";
      addToast(
        "error",
        code === "permission-denied" ? t("attendance.manualLimitReached") : t("attendance.manualError"),
      );
    } finally {
      setSavingManual(false);
    }
  }, [editing, inviteToken, onDataChanged, addToast, t]);

  /** Descarga un Excel con todas las respuestas RSVP (filtradas o no). */
  const handleExportExcel = useCallback(async () => {
    // No se exporta si no hay respuestas: se avisa y se evita un fichero vacío.
    if ((filteredEntries || []).length === 0) {
      addToast("info", t("attendance.noResults"));
      return;
    }
    try {
      const { buildRSVPSheet, buildMenuSheet } = await import("../../lib/excel-builders");
      const { exportToXlsx } = await import("../../lib/excel-utils");
      exportToXlsx(`asistencia_${new Date().toISOString().slice(0, 10)}`, [
        buildRSVPSheet(filteredEntries || [], t),
        buildMenuSheet(filteredEntries || [], t),
      ]);
    } catch {
      addToast("error", t("attendance.exportExcelError"));
    }
  }, [filteredEntries, t, addToast]);

  // v2.185: se reutiliza departuresList (parseo único de la config); antes el
  // JSON.parse se hacía DOS veces por render (departures + departuresList).
  const departures = useMemo(() => departuresList, [departuresList]);

  // Nombres únicos para el select de búsqueda, memoizados con un Set (O(n)
  // en vez del O(n²) de findIndex por render anterior: con 500 respuestas
  // eran ~250k comparaciones en cada renderización del tab).
  const uniqueGuestNames = useMemo(() => {
    const seen = new Set<string>();
    const out: RsvpEntry[] = [];
    for (const e of rsvpEntries || []) {
      const n = e.guestName || "";
      const key = n.toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      out.push(e);
    }
    return out;
  }, [rsvpEntries]);

  const resolveTransportLabel = useCallback(
    (mode: string, choice: string, storedTime: string) => {
      if (!mode && !choice && !storedTime) return "—";
      if (!mode || mode === "own") return t("attendance.transportOwnCar");
      const typeLabel = t(mode === "taxi" ? "transport.typeTaxi" : "transport.typeBus");
      if (storedTime) return `${typeLabel} (${storedTime})`;
      const idx = Number.parseInt(choice, 10);
      const dep = departures[idx] as { time?: string } | undefined;
      if (dep && dep.time) return `${typeLabel} (${dep.time})`;
      return typeLabel;
    },
    [departures, t],
  );

  const filterEntries = filteredEntries || [];

  // Ordenación por columnas de la tabla de asistencias (checkbox no). Cada
  // columna extrae su valor comparable (texto, número, fecha o booleano).
  const sortColumns = useMemo<SortableColumn<RsvpEntry>[]>(
    () => [
      { key: "name", type: "string", getValue: (e: RsvpEntry) => e.guestName },
      {
        key: "accompanies",
        type: "string",
        getValue: (e: RsvpEntry) => (e.rsvpType === "companion" ? e.mainGuestName || "" : ""),
      },
      { key: "attendance", type: "string", getValue: (e: RsvpEntry) => e.attendance },
      {
        key: "menu",
        type: "string",
        getValue: (e: RsvpEntry) => {
          if (e.attendees?.length) {
            return e.attendees
              .map((a) => (a.menu ? `${a.name}: ${formatMenuLabel(a.menu, t)}` : ""))
              .filter(Boolean)
              .join(", ");
          }
          return formatMenuLabel(e.mealChoice || "", t) || "";
        },
      },
      {
        key: "diet",
        type: "string",
        getValue: (e: RsvpEntry) => {
          if (e.attendees?.length) {
            return e.attendees
              .filter((a) => a.allergies?.length)
              .map((a) => `${a.name}: ${a.allergies.join(", ")}`)
              .join(", ");
          }
          return e.attendance === "yes" ? getDietaryItems(e.dietaryInfo || "").join(", ") : "";
        },
      },
      {
        key: "transport",
        type: "string",
        getValue: (e: RsvpEntry) =>
          e.attendance === "yes"
            ? resolveTransportLabel(e.transportMode || "", e.transportChoice || "", e.transportTime || "")
            : "",
      },
      { key: "children", type: "number", getValue: (e: RsvpEntry) => Number(e.childrenCount) || 0 },
      {
        key: "childrenDiet",
        type: "string",
        getValue: (e: RsvpEntry) => getChildrenDietary(e).join(", "),
      },
      {
        key: "consents",
        type: "boolean",
        getValue: (e: RsvpEntry) => Boolean(e.healthConsent),
      },
      { key: "submittedAt", type: "date", getValue: (e: RsvpEntry) => e.submittedAt },
    ],
    [t, resolveTransportLabel],
  );
  const { sorted: sortedFilterEntries, toggleSort, getIndicator } = useColumnSort(filterEntries, sortColumns);

  const totalPages = Math.max(1, Math.ceil(sortedFilterEntries.length / pageSize));
  const safePage = Math.min(page, totalPages - 1);
  const paginated = sortedFilterEntries.slice(safePage * pageSize, (safePage + 1) * pageSize);

  useEffect(() => {
    setPage(0);
  }, [searchQuery, attendanceFilter]);

  const stats = useMemo(() => {
    const entries = rsvpEntries || [];
    const mainEntries = entries.filter((e) => e.rsvpType !== "companion");
    const yes = mainEntries.filter((e: RsvpEntry) => e.attendance === "yes").length;
    const no = mainEntries.filter((e: RsvpEntry) => e.attendance === "no").length;
    const totalCompanions = entries.filter((e: RsvpEntry) => e.rsvpType === "companion").length;
    const withDietary = entries.filter((e: RsvpEntry) => e.attendance === "yes" && e.dietaryInfo?.trim()).length;
    // Niños confirmados: contador del nuevo modelo (childrenCount en el doc
    // del invitado principal, declarado en el RSVP).
    const declaredChildren = mainEntries
      .filter((e: RsvpEntry) => e.attendance === "yes")
      .reduce((acc: number, e: RsvpEntry) => acc + (Number(e.childrenCount) || 0), 0);
    const children = declaredChildren;
    return { yes, no, totalCompanions, withDietary, children };
  }, [rsvpEntries]);

  const toggleAll = () => {
    if (selectedIds.size === paginated.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(paginated.map((e) => e.id)));
    }
  };

  // useCallback (v2.187): las filas memoizadas (AttendanceRow) reciben este
  // handler como prop; sin memo cambiaría en cada render y rompería el memo.
  const toggleOne = useCallback((id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  const handleBatchDelete = () => {
    const mainIds = [...selectedIds].filter((id) => {
      const entry = rsvpEntries.find((e) => e.id === id);
      return entry?.rsvpType !== "companion";
    });
    const allToDelete = new Set(selectedIds);
    // Also delete companions linked to selected main entries
    for (const mid of mainIds) {
      const main = rsvpEntries.find((e) => e.id === mid);
      if (main?.companionDocIds) {
        for (const cid of main.companionDocIds) {
          allToDelete.add(cid);
        }
      }
    }
    handleDeleteRsvpEntries([...allToDelete]);
    setSelectedIds(new Set());
  };

  return (
    <>
      <div className="admin-filters">
        <label className="sr-only" htmlFor="adminSearchName">
          {t("attendance.searchLabel")}
        </label>
        <select
          id="adminSearchName"
          className="setup-input"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          style={{ maxWidth: "250px", fontSize: "0.85rem" }}
        >
          <option value="">{t("attendance.all")}</option>
          {uniqueGuestNames.map((e: RsvpEntry) => (
            <option key={e.id} value={e.guestName}>
              {e.guestName}
            </option>
          ))}
        </select>
        {/* Filtro de asistencia: el estado existía pero no había UI para
              cambiarlo (feature muerta). */}
        <label className="sr-only" htmlFor="adminAttendanceFilter">
          {t("attendance.filterLabel")}
        </label>
        <select
          id="adminAttendanceFilter"
          className="setup-input"
          value={attendanceFilter}
          onChange={(e) => setAttendanceFilter(e.target.value)}
          style={{ maxWidth: "180px", fontSize: "0.85rem" }}
        >
          <option value="all">{t("attendance.filterAll")}</option>
          <option value="yes">{t("attendance.filterYes")}</option>
          <option value="no">{t("attendance.filterNo")}</option>
        </select>
        {/* Restablece búsqueda y filtro con un solo toque (UX de listas). */}
        {searchQuery || attendanceFilter !== "all" ? (
          <button
            type="button"
            className="setup-button setup-button--ghost setup-button--compact"
            onClick={() => {
              setSearchQuery("");
              setAttendanceFilter("all");
            }}
          >
            {t("attendance.resetFilters")}
          </button>
        ) : null}
      </div>

      <div style={{ display: "flex", gap: "0.75rem", flexWrap: "wrap", marginBottom: "0.75rem" }}>
        <span className="setup-help" style={{ margin: 0, fontSize: "0.8rem" }}>
          {t("attendance.statsLine", {
            yes: stats.yes,
            no: stats.no,
            companions: stats.totalCompanions,
            diet: stats.withDietary,
          })}
        </span>
        {Number(rsvpCapacity) > 0 ? (
          <span className="setup-help" style={{ margin: 0, fontSize: "0.8rem" }}>
            {t("attendance.capacityInfo", { used: stats.yes, capacity: Number(rsvpCapacity) })}
          </span>
        ) : null}
        {/* Estadística de niños confirmados (contador declarado en el RSVP). */}
        <span className="setup-help" style={{ margin: 0, fontSize: "0.8rem" }}>
          {t("attendance.childrenConfirmed", { count: stats.children })}
        </span>
      </div>

      {/* Contador de resultados filtrados (UX: el admin sabe cuántas filas
          coinciden con la búsqueda/filtro actuales, aria-live incluido). */}
      <div aria-live="polite" style={{ marginBottom: "0.5rem" }}>
        <span className="setup-help" style={{ margin: 0, fontSize: "0.78rem" }} data-testid="attendance-results-count">
          {filterEntries.length} {t("attendance.resultsCount", { count: filterEntries.length })}
        </span>
      </div>

      <div aria-live="polite" aria-atomic="true">
        {filterEntries.length > 0 ? (
          <div className="admin-table-wrapper" style={{ overflowX: "auto" }}>
            <table className="admin-table" style={{ fontSize: "0.8rem", minWidth: "800px" }}>
              <caption className="admin-table__caption">{t("attendance.tableTitle")}</caption>
              <thead>
                <tr>
                  <th scope="col" style={{ width: "2rem" }}>
                    <input
                      type="checkbox"
                      onChange={toggleAll}
                      checked={paginated.length > 0 && selectedIds.size === paginated.length}
                      aria-label={t("attendance.selectAll")}
                    />
                  </th>
                  <SortableTh
                    columnKey="name"
                    order={getIndicator("name")}
                    onSort={toggleSort}
                    style={{ minWidth: "100px" }}
                  >
                    {t("attendance.tableName")}
                  </SortableTh>
                  <SortableTh
                    columnKey="accompanies"
                    order={getIndicator("accompanies")}
                    onSort={toggleSort}
                    style={{ minWidth: "120px" }}
                  >
                    {t("attendance.tableAccompanies")}
                  </SortableTh>
                  <SortableTh
                    columnKey="attendance"
                    order={getIndicator("attendance")}
                    onSort={toggleSort}
                    style={{ minWidth: "70px" }}
                  >
                    {t("attendance.tableAttendance")}
                  </SortableTh>
                  <SortableTh
                    columnKey="menu"
                    order={getIndicator("menu")}
                    onSort={toggleSort}
                    style={{ minWidth: "120px" }}
                  >
                    {t("attendance.tableMenu")}
                  </SortableTh>
                  <SortableTh
                    columnKey="diet"
                    order={getIndicator("diet")}
                    onSort={toggleSort}
                    style={{ minWidth: "140px" }}
                  >
                    {t("attendance.tableDiet")}
                  </SortableTh>
                  <SortableTh
                    columnKey="children"
                    order={getIndicator("children")}
                    onSort={toggleSort}
                    style={{ minWidth: "90px" }}
                  >
                    {t("attendance.tableChildren")}
                  </SortableTh>
                  <SortableTh
                    columnKey="childrenDiet"
                    order={getIndicator("childrenDiet")}
                    onSort={toggleSort}
                    style={{ minWidth: "140px" }}
                  >
                    {t("attendance.tableChildrenDiet")}
                  </SortableTh>
                  <SortableTh
                    columnKey="transport"
                    order={getIndicator("transport")}
                    onSort={toggleSort}
                    style={{ minWidth: "120px" }}
                  >
                    {t("attendance.tableTransport")}
                  </SortableTh>
                  <SortableTh
                    columnKey="consents"
                    order={getIndicator("consents")}
                    onSort={toggleSort}
                    style={{ minWidth: "120px" }}
                  >
                    {t("attendance.tableConsents")}
                  </SortableTh>
                  <SortableTh
                    columnKey="submittedAt"
                    order={getIndicator("submittedAt")}
                    onSort={toggleSort}
                    style={{ minWidth: "120px" }}
                  >
                    {t("attendance.tableDate")}
                  </SortableTh>
                </tr>
              </thead>
              <tbody>
                {paginated.map((entry: RsvpEntry) => (
                  <AttendanceRow
                    key={entry.id}
                    entry={entry}
                    isSelected={selectedIds.has(entry.id)}
                    inviteToken={inviteToken}
                    onToggle={toggleOne}
                    onEdit={openEdit}
                    onDelete={handleDeleteRsvpEntries}
                    resolveTransportLabel={resolveTransportLabel}
                    formatDate={formatDate}
                  />
                ))}
              </tbody>
            </table>
            <Pagination
              page={safePage}
              totalPages={totalPages}
              pageSize={pageSize}
              total={filterEntries.length}
              pageSizes={PAGE_SIZES}
              onPageChange={setPage}
              onPageSizeChange={setPageSize}
            />
          </div>
        ) : searchQuery ? (
          <EmptyState title={t("attendance.noResultsFilter")} description={t("attendance.noResultsFilterHint")} />
        ) : (
          <EmptyState title={t("attendance.noResults")} />
        )}
      </div>

      {(rsvpEntries || []).length > 0 && (
        <div
          className="setup-actions"
          style={{ display: "flex", gap: "0.75rem", flexWrap: "wrap", justifyContent: "center", marginTop: "1rem" }}
        >
          {inviteToken ? (
            <button className="setup-button setup-button--compact" type="button" onClick={openAdd}>
              {t("attendance.addManual")}
            </button>
          ) : null}
          <button className="setup-button setup-button--ghost setup-button--compact" type="button" onClick={exportPdf}>
            {t("attendance.exportPdf")}
          </button>
          <button
            className="setup-button setup-button--ghost setup-button--compact"
            type="button"
            onClick={() => void handleExportExcel()}
          >
            {t("attendance.exportExcel")}
          </button>
          <button
            className="setup-button setup-button--ghost setup-button--compact"
            type="button"
            onClick={handleBatchDelete}
            disabled={selectedIds.size === 0}
            style={{
              background: selectedIds.size > 0 ? "#ef4444" : undefined,
              color: selectedIds.size > 0 ? "#fff" : undefined,
            }}
          >
            {t("attendance.deleteSelected", { count: selectedIds.size })}
          </button>
          <button
            className="setup-button setup-button--ghost setup-button--compact"
            type="button"
            onClick={handleClearRsvpEntries}
          >
            {t("attendance.clearAttendance")}
          </button>
        </div>
      )}

      {/* Modal de añadir/editar respuesta manual (invitaciones físicas y
          corrección de respuestas de invitados): todos los datos editables. */}
      {editing ? (
        <AttendanceEditModal
          editing={editing}
          savingManual={savingManual}
          menuEnabled={Boolean(menuEnabled)}
          departuresList={departuresList}
          onClose={() => setEditing(null)}
          onSave={() => void saveManual()}
          onChange={(key, value) => setEditing((prev) => (prev ? { ...prev, [key]: value } : prev))}
          onAddCompanion={addCompanion}
          onRemoveCompanion={removeCompanionAt}
          onPatchCompanion={patchCompanion}
          onToggleCompanionAllergy={toggleCompanionAllergy}
        />
      ) : null}
    </>
  );
});

export default AttendanceTab;
