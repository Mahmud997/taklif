import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";

vi.mock("react-i18next", () => ({
  useTranslation: () => ({ t: (key: string) => key }),
}));

const mockUpdateFormField = vi.fn();
const mockFormData = vi.hoisted(
  () =>
    ({ kidsPolicyEnabled: "true", weddingDressCodeEnabled: "true", accommodationURLEnabled: "true" }) as Record<
      string,
      string | undefined
    >,
);

vi.mock("../../../contexts", () => ({
  useConfigActions: () => ({
    updateFormField: typeof mockUpdateFormField !== "undefined" ? mockUpdateFormField : vi.fn(),
    handleDayChange: vi.fn(),
    handleTimeChange: vi.fn(),
    handleTimeBlur: vi.fn(),
    handleYearChange: vi.fn(),
    maxAllowedYear: 2099,
    inviteToken: "",
    hasStoredConfig: false,
  }),
  useFormField: (field: string) => mockFormData[field] ?? "",
  useFormStore: () => ({ getField: (field: string) => mockFormData[field] ?? "" }),
  useConfig: () => ({
    config: { theme: "golden", menuEnabled: "true" },
    formData: mockFormData,
    updateFormField: mockUpdateFormField,
  }),
}));

import GuestsSectionForm from "../GuestsSectionForm";

function getAllCheckboxes() {
  // Excluye los toggles del patrÃ³n checkboxâ†’input (.setup-toggle): solo las
  // opciones de contenido (kids policy, dress code, menÃº).
  return screen.getAllByRole("checkbox").filter((cb) => !cb.classList.contains("setup-toggle"));
}

describe("GuestsSectionForm", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    Object.keys(mockFormData).forEach((key) => delete mockFormData[key]);
    // Los toggles del patrÃ³n checkboxâ†’input quedan activos por defecto para
    // que los campos opcionales se muestren en los tests.
    mockFormData.kidsPolicyEnabled = "true";
    mockFormData.weddingDressCodeEnabled = "true";
    mockFormData.accommodationURLEnabled = "true";
  });

  it("renders without crashing", () => {
    render(<GuestsSectionForm />);
    expect(screen.getByText("setup.kidsLabel")).toBeDefined();
  });

  it("renders kids policy options", () => {
    render(<GuestsSectionForm />);
    expect(screen.getByText("kidsPolicy.options.playArea")).toBeDefined();
    expect(screen.getByText("kidsPolicy.options.supervised")).toBeDefined();
  });

  it("renders dress code section", () => {
    render(<GuestsSectionForm />);
    expect(screen.getByText("setup.dressCodeLabel")).toBeDefined();
    expect(screen.getByText("setup.dressCodeGala")).toBeDefined();
  });

  it("renders menu section", () => {
    render(<GuestsSectionForm />);
    expect(screen.getByText("setup.menuCelebrationLabel")).toBeDefined();
    expect(screen.getByText("setup.menuEnabledLabel")).toBeDefined();
  });

  it("renders accommodation URL field", () => {
    render(<GuestsSectionForm />);
    expect(screen.getByText("setup.accommodationLabel")).toBeDefined();
    expect(screen.getByPlaceholderText("setup.accommodationUrlPlaceholder")).toBeDefined();
  });

  it("renders accommodation URL hint", () => {
    render(<GuestsSectionForm />);
    expect(screen.getByText("setup.accommodationUrlHint")).toBeDefined();
  });

  it("calls updateFormField on kids policy checkbox click (select)", () => {
    render(<GuestsSectionForm />);
    const checkboxes = getAllCheckboxes();
    fireEvent.click(checkboxes[0]!);
    expect(mockUpdateFormField).toHaveBeenCalledWith("kidsPolicy", "playArea");
  });

  it("calls updateFormField on kids policy checkbox click (deselect)", () => {
    mockFormData.kidsPolicy = "playArea";
    render(<GuestsSectionForm />);
    const checkboxes = getAllCheckboxes();
    fireEvent.click(checkboxes[0]!);
    expect(mockUpdateFormField).toHaveBeenCalledWith("kidsPolicy", "");
  });

  it("calls updateFormField on dress code selection", () => {
    render(<GuestsSectionForm />);
    fireEvent.click(screen.getByLabelText("setup.dressCodeGala"));
    expect(mockUpdateFormField).toHaveBeenCalledWith("weddingDressCode", "gala");
  });

  it("calls updateFormField on dress code deselection", () => {
    mockFormData.weddingDressCode = "gala";
    render(<GuestsSectionForm />);
    fireEvent.click(screen.getByLabelText("setup.dressCodeGala"));
    expect(mockUpdateFormField).toHaveBeenCalledWith("weddingDressCode", "");
  });

  it("calls updateFormField on menu enabled toggle", () => {
    // El toggle del menú es un SetupToggleField (switch moderno): se encuentra
    // por su aria-label, como el resto de toggles del formulario.
    render(<GuestsSectionForm />);
    fireEvent.click(screen.getByLabelText("setup.menuEnabledLabel"));
    expect(mockUpdateFormField).toHaveBeenCalledWith("menuEnabled", "true");
  });

  it("calls updateFormField to disable menu", () => {
    mockFormData.menuEnabled = "true";
    render(<GuestsSectionForm />);
    fireEvent.click(screen.getByLabelText("setup.menuEnabledLabel"));
    expect(mockUpdateFormField).toHaveBeenCalledWith("menuEnabled", "false");
  });

  it("selects the 'Otro' dress code option", () => {
    render(<GuestsSectionForm />);
    fireEvent.click(screen.getByLabelText("setup.dressCodeOther"));
    expect(mockUpdateFormField).toHaveBeenCalledWith("weddingDressCode", "custom");
  });

  it("updates the custom dress code message", () => {
    mockFormData.weddingDressCode = "custom";
    render(<GuestsSectionForm />);
    const input = document.getElementById("dressCodeCustom") as HTMLInputElement;
    fireEvent.change(input, { target: { value: "Vestimenta vintage" } });
    expect(mockUpdateFormField).toHaveBeenCalledWith("weddingDressCodeCustom", "Vestimenta vintage");
  });

  it("keeps the custom message when another predefined option is chosen", () => {
    mockFormData.weddingDressCode = "custom";
    mockFormData.weddingDressCodeCustom = "Vestimenta vintage";
    render(<GuestsSectionForm />);
    fireEvent.click(screen.getByLabelText("setup.dressCodeGala"));
    expect(mockUpdateFormField).toHaveBeenCalledWith("weddingDressCode", "gala");
    expect(mockUpdateFormField).not.toHaveBeenCalledWith("weddingDressCodeCustom", "");
  });

  it("updates the accommodationMapMode dropdown", () => {
    render(<GuestsSectionForm />);
    fireEvent.change(screen.getByLabelText("setup.mapModeLabel"), { target: { value: "name" } });
    expect(mockUpdateFormField).toHaveBeenCalledWith("accommodationMapMode", "name");
  });

  it("renders menu dish editors when menu is enabled", () => {
    mockFormData.menuEnabled = "true";
    render(<GuestsSectionForm />);
    expect(screen.getByText("setup.menuHint")).toBeDefined();
    expect(screen.getByText("setup.menuCarneLabel")).toBeDefined();
    expect(screen.getByText("setup.menuPescadoLabel")).toBeDefined();
    expect(screen.getByText("setup.menuVeganoLabel")).toBeDefined();
    expect(screen.getByText("setup.menuRequiredText")).toBeDefined();
    expect(screen.getAllByRole("button", { name: /setup.menuAddDish/ }).length).toBeGreaterThanOrEqual(3);
  });

  it("adds a dish to the fixed menu editor", () => {
    render(<GuestsSectionForm />);
    fireEvent.click(screen.getByRole("button", { name: /setup.menuAddDish/ }));
    expect(mockUpdateFormField).toHaveBeenCalledWith(
      "menuTextoDishes",
      JSON.stringify([{ order: "entrante", text: "" }]),
    );
  });

  it("edits the dish text in the fixed menu editor", () => {
    mockFormData.menuTextoDishes = JSON.stringify([{ order: "primero", text: "" }]);
    render(<GuestsSectionForm />);
    const input = screen.getByPlaceholderText("setup.menuDishPlaceholder");
    fireEvent.change(input, { target: { value: "Lubina al horno" } });
    expect(mockUpdateFormField).toHaveBeenCalledWith(
      "menuTextoDishes",
      JSON.stringify([{ order: "primero", text: "Lubina al horno" }]),
    );
  });

  it("removes a dish from the fixed menu editor", () => {
    mockFormData.menuTextoDishes = JSON.stringify([
      { order: "entrante", text: "Ensalada" },
      { order: "postre", text: "Tarta" },
    ]);
    render(<GuestsSectionForm />);
    const removeButtons = screen.getAllByLabelText("setup.menuRemoveDish");
    fireEvent.click(removeButtons[0]!);
    expect(mockUpdateFormField).toHaveBeenCalledWith(
      "menuTextoDishes",
      JSON.stringify([{ order: "postre", text: "Tarta" }]),
    );
  });

  it("changes the dish order in the fixed menu editor", () => {
    mockFormData.menuTextoDishes = JSON.stringify([{ order: "entrante", text: "Ensalada" }]);
    render(<GuestsSectionForm />);
    const select = screen.getByLabelText("setup.menuOrderLabel") as HTMLSelectElement;
    fireEvent.change(select, { target: { value: "postre" } });
    expect(mockUpdateFormField).toHaveBeenCalledWith(
      "menuTextoDishes",
      JSON.stringify([{ order: "postre", text: "Ensalada" }]),
    );
  });

  it("edits a dish of a selectable menu option", () => {
    mockFormData.menuEnabled = "true";
    mockFormData.menuCarneDishes = JSON.stringify([{ order: "primero", text: "" }]);
    render(<GuestsSectionForm />);
    const inputs = screen.getAllByPlaceholderText("setup.menuDishPlaceholder");
    fireEvent.change(inputs[0]!, { target: { value: "Solomillo" } });
    expect(mockUpdateFormField).toHaveBeenCalledWith(
      "menuCarneDishes",
      JSON.stringify([{ order: "primero", text: "Solomillo" }]),
    );
  });

  it("calls updateFormField on accommodation URL change", () => {
    render(<GuestsSectionForm />);
    const input = screen.getByPlaceholderText("setup.accommodationUrlPlaceholder");
    fireEvent.change(input, { target: { value: "https://www.google.com/maps/place/Hotel+Sol/@40.41,-3.70,17z" } });
    expect(mockUpdateFormField).toHaveBeenCalledWith(
      "accommodationURL",
      "https://www.google.com/maps/place/Hotel+Sol/@40.41,-3.70,17z",
    );
  });

  it("marks an invalid accommodation URL as error", () => {
    mockFormData.accommodationURL = "https://maps.app.goo.gl/abc";
    render(<GuestsSectionForm />);
    const input = screen.getByPlaceholderText("setup.accommodationUrlPlaceholder");
    expect(input.className).toContain("setup-input--error");
    expect(screen.getByText(/setup.mapUrlInvalid/)).toBeDefined();
  });

  it("shows the accommodation site name for a valid place URL", () => {
    mockFormData.accommodationURL = "https://www.google.com/maps/place/Hotel+Sol/@40.41,-3.70,17z";
    render(<GuestsSectionForm />);
    expect(screen.getByText(/setup.siteNameLabel/)).toBeDefined();
    expect(screen.getByText((text: string) => text.includes("Hotel Sol"))).toBeDefined();
  });

  // Fecha límite: el toggle habilita el input date; verificar ambas piezas.
  it("toggles rsvpDeadlineEnabled from its row switch", () => {
    render(<GuestsSectionForm />);
    fireEvent.click(screen.getByLabelText("setup.rsvpDeadlineLabel"));
    expect(mockUpdateFormField).toHaveBeenCalledWith("rsvpDeadlineEnabled", "true");
  });

  it("updates rsvpDeadline when enabled", () => {
    mockFormData.rsvpDeadlineEnabled = "true";
    render(<GuestsSectionForm />);
    const input = document.querySelector('input[type="date"]') as HTMLInputElement;
    fireEvent.change(input, { target: { value: "2030-06-01" } });
    expect(mockUpdateFormField).toHaveBeenCalledWith("rsvpDeadline", "2030-06-01");
  });

  // Editores de platos por tipo de menú: localizar el botón añadir dentro del
  // bloque de su etiqueta evita depender del orden global de los editores.
  const dishCases: Array<[string, string]> = [
    ["setup.menuPescadoLabel", "menuPescadoDishes"],
    ["setup.menuVeganoLabel", "menuVeganoDishes"],
  ];
  it.each(dishCases)("adds a dish to the %s editor", (label, field) => {
    mockFormData.menuEnabled = "true";
    render(<GuestsSectionForm />);
    const section = screen.getByText(label).parentElement as HTMLElement;
    fireEvent.click(section.querySelector("button") as HTMLButtonElement);
    expect(mockUpdateFormField).toHaveBeenCalledWith(field, JSON.stringify([{ order: "entrante", text: "" }]));
  });
});
