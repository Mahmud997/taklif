import { Suspense } from "react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import { MemoryRouter } from "react-router";
import { setAdminMode } from "../lib/chrome-store";

const mockSuperadminModule = vi.hoisted(() => ({
  SUPERADMIN_ROUTE: "/superadmin",
  SUPERADMIN_DASHBOARD: "",
}));

vi.mock("react-i18next", () => ({
  useTranslation: () => ({ t: (key: string) => key, i18n: { language: "en" } }),
  initReactI18next: { type: "3rdParty", init: vi.fn() },
  Trans: ({ i18nKey }: { i18nKey: string }) => i18nKey,
}));

vi.mock("../providers", () => ({
  // v2.192: AppProviders pasa directo; InviteChrome se prueba en
  // providers.test.tsx con los contextos reales stubbeados.
  AppProviders: ({ children }: { children: React.ReactNode }) => <>{children}</>,
  SuperAdminProviders: ({ children }: { children: React.ReactNode }) => <>{children}</>,
  InviteChrome: () => null,
}));

vi.mock("../contexts/AppContext", () => ({
  AppProvider: ({ children }: { children: React.ReactNode }) => <>{children}</>,
  // v2.192: el árbol por ruta (sin UIProvider) — el mock lo pasa directo.
  AppProvidersTree: ({ children }: { children: React.ReactNode }) => <>{children}</>,
}));

vi.mock("../contexts/SuperAdminContext", () => ({
  SuperAdminProvider: ({ children }: { children: React.ReactNode }) => <>{children}</>,
}));

vi.mock("../contexts/ToastContext", () => ({
  ToastProvider: ({ children }: { children: React.ReactNode }) => <>{children}</>,
}));

const mockUseApp = vi.fn();
vi.mock("../contexts", () => ({
  useConfigActions: () => ({
    updateFormField: vi.fn(),
    handleDayChange: vi.fn(),
    handleTimeChange: vi.fn(),
    handleTimeBlur: vi.fn(),
    handleYearChange: vi.fn(),
    maxAllowedYear: 2099,
    inviteToken: "",
    hasStoredConfig: false,
  }),

  useApp: (...args: unknown[]) => mockUseApp(...args),
  useConfig: (...args: unknown[]) => mockUseApp(...args),
  useAuth: (...args: unknown[]) => mockUseApp(...args),
  useAppUI: () => ({ setCookiePrefsOpen: vi.fn() }),

  useUIMessages: () => ({
    saveMessage: "", setSaveMessage: vi.fn(),
    saveError: "", setSaveError: vi.fn(),
    adminMessage: "", setAdminMessage: vi.fn(),
    adminMessageType: "success", setAdminMessageType: vi.fn(),
  }),
  // App lee el theme del setup con useFormField (tienda por campo): devuelve
  // el valor del formData simulado por el test.
  useFormField: (field: string) => (mockUseApp().formData as Record<string, string | undefined>)?.[field] ?? "",
  // Animaciones: provider de paso y prefs activas por defecto.
  AnimationsProvider: ({ children }: { children: React.ReactNode }) => <>{children}</>,
  ConfirmProvider: ({ children }: { children: React.ReactNode }) => <>{children}</>,
  useAnimations: () => ({
    adminDisabled: new Set<string>(),
    guestDisabled: new Set<string>(),
    effectiveDisabled: new Set<string>(),
    isDisabled: () => false,
    isGroupFullyDisabled: () => false,
    toggleGuestAnimation: vi.fn(),
    setGuestGroup: vi.fn(),
    allOff: false,
    setAllGuest: vi.fn(),
    resetGuest: vi.fn(),
  }),
  useConfirm: () => ({
    confirm: vi.fn(async () => true),
    prompt: vi.fn(async () => null),
  }),
}));

vi.mock("../components/AccessibilityPanel", () => ({
  default: () => <div data-testid="a11y-panel" />,
}));

vi.mock("../components/ErrorBoundary", () => ({
  default: ({ children }: { children: React.ReactNode }) => <>{children}</>,
}));

vi.mock("../components/LanguageSwitcher", () => ({
  default: () => <div data-testid="lang-switcher" />,
}));

vi.mock("../components/CookieConsent", () => ({
  default: () => <div data-testid="cookie-consent" />,
}));

vi.mock("../components/MusicPlayer", () => ({
  default: () => <div data-testid="music-player" />,
}));

vi.mock("../components/LegalModal", () => ({
  default: ({ section, onClose }: { section: string; onClose?: () => void }) =>
    section ? (
      <div data-testid="legal-modal">
        {section}
        <button onClick={onClose}>close</button>
      </div>
    ) : null,
}));

vi.mock("../components/ChangelogModal", () => ({
  default: ({ onClose }: { onClose?: () => void }) => (
    <div data-testid="changelog-modal">
      <button onClick={onClose}>close</button>
    </div>
  ),
}));

vi.mock("../components/DataRequestModal", () => ({
  default: ({ onClose }: { onClose?: () => void }) => (
    <div data-testid="data-request-modal">
      <button onClick={onClose}>close</button>
    </div>
  ),
}));

vi.mock("../components/Fireflies", () => ({
  default: () => <div data-testid="fireflies" />,
}));

vi.mock("../pages/LandingPage", () => ({
  default: () => <div data-testid="landing-page" />,
}));

vi.mock("../pages/PublicInvitation", () => ({
  default: () => <div data-testid="public-invitation" />,
}));

vi.mock("../pages/SetupPage", () => ({
  default: () => <div data-testid="setup-page" />,
}));

vi.mock("../pages/AdminPage", () => ({
  default: () => <div data-testid="admin-page" />,
}));

vi.mock("../pages/SuperAdminLogin", () => ({
  default: () => <div data-testid="superadmin-login" />,
}));

vi.mock("../pages/SuperAdminPanel", () => ({
  default: () => <div data-testid="superadmin-panel" />,
}));

vi.mock("../pages/PrintPage", () => ({
  default: () => <div data-testid="print-page" />,
}));

vi.mock("../lib/error-utils", () => ({
  logError: vi.fn(),
}));

vi.mock("../lib/superadmin", () => mockSuperadminModule);

import App from "../App";

const baseUseApp = {
  config: { theme: "golden", musicFile: "", firstName: "Test", secondName: "User" },
  formData: {},
  isConfigLoading: false,
  configLoadError: "",
  rsvpForm: { attendance: "" },
  isAdminTokenLoggedIn: false,
  tokenLoginUsername: "",
  inviteToken: undefined,
};

describe("App", () => {
  beforeEach(() => {
    mockUseApp.mockReturnValue(baseUseApp);
    // Evita contaminación entre tests del banner de actualización.
    const store: Record<string, string> = {};
    const mkStorage = () => ({
      getItem: (k: string) => store[k] ?? null,
      setItem: (k: string, v: string) => {
        store[k] = String(v);
      },
      removeItem: (k: string) => {
        delete store[k];
      },
      clear: () => {
        Object.keys(store).forEach((k) => delete store[k]);
      },
    });
    Object.defineProperty(globalThis, "sessionStorage", { value: mkStorage(), configurable: true });
    Object.defineProperty(globalThis, "localStorage", { value: mkStorage(), configurable: true });
    document.querySelectorAll('meta[name="deploy-id"]').forEach((m) => m.remove());
  });

  it("renders landing page at root route", async () => {
    render(
      <MemoryRouter initialEntries={["/"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    expect(await screen.findByTestId("landing-page")).toBeDefined();
    expect(screen.getByTestId("fireflies")).toBeDefined();
    expect(screen.getByTestId("cookie-consent")).toBeDefined();
  });

  it("renders lang switcher in nav and footer", () => {
    render(
      <MemoryRouter initialEntries={["/"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    expect(screen.getAllByTestId("lang-switcher").length).toBe(2);
  });

  it("shows offline banner when offline", () => {
    Object.defineProperty(navigator, "onLine", { configurable: true, get: () => false });

    render(
      <MemoryRouter initialEntries={["/"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    expect(screen.getByText("common.offline")).toBeDefined();

    Object.defineProperty(navigator, "onLine", { configurable: true, get: () => true });
  });

  it("does not show offline banner when online", () => {
    render(
      <MemoryRouter initialEntries={["/"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    expect(screen.queryByText("common.offline")).toBeNull();
  });



  it("does not render admin bar when no admin token", () => {
    render(
      <MemoryRouter initialEntries={["/"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    expect(screen.queryByText("admin.tabs.invitation")).toBeNull();
  });

  it("renders setup route", async () => {
    mockUseApp.mockReturnValue({ ...baseUseApp, inviteToken: "abc123" });

    render(
      <MemoryRouter initialEntries={["/abc123/setup"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    expect(await screen.findByTestId("setup-page")).toBeDefined();
  });

  it("renders admin route", async () => {
    mockUseApp.mockReturnValue({ ...baseUseApp, inviteToken: "abc123" });

    render(
      <MemoryRouter initialEntries={["/abc123/admin"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    expect(await screen.findByTestId("admin-page")).toBeDefined();
  });

  it("renders superadmin login route", async () => {
    mockUseApp.mockReturnValue({ ...baseUseApp });

    render(
      <MemoryRouter initialEntries={["/superadmin"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    expect(await screen.findByTestId("superadmin-login")).toBeDefined();
  });

  it("renders superadmin panel route when dashboard is configured", async () => {
    (mockSuperadminModule as { SUPERADMIN_ROUTE: string; SUPERADMIN_DASHBOARD?: string }).SUPERADMIN_DASHBOARD =
      "/superadmin/dashboard";
    mockUseApp.mockReturnValue({ ...baseUseApp });

    render(
      <MemoryRouter initialEntries={["/superadmin/dashboard"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    expect(await screen.findByTestId("superadmin-panel")).toBeDefined();

    (mockSuperadminModule as { SUPERADMIN_DASHBOARD: string }).SUPERADMIN_DASHBOARD = "";
  });

  it("renders print route", async () => {
    mockUseApp.mockReturnValue({ ...baseUseApp, inviteToken: "abc123" });

    render(
      <MemoryRouter initialEntries={["/abc123/print"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    expect(await screen.findByTestId("print-page")).toBeDefined();
  });

  it("renders public invitation at token route", async () => {
    mockUseApp.mockReturnValue({ ...baseUseApp, inviteToken: "abc123" });

    render(
      <MemoryRouter initialEntries={["/abc123"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    expect(await screen.findByTestId("public-invitation")).toBeDefined();
  });



  it("renders nav toggle when not editing and not admin", () => {
    render(
      <MemoryRouter initialEntries={["/"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    const toggle = document.querySelector(".app-nav-toggle");
    expect(toggle).toBeDefined();
  });

  it("shows overlay when nav toggle is clicked", () => {
    render(
      <MemoryRouter initialEntries={["/"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    fireEvent.click(document.querySelector(".app-nav-toggle")!);
    expect(document.querySelector(".app-nav-overlay--open")).toBeDefined();
  });

  it("opens accessibility panel from overlay", () => {
    render(
      <MemoryRouter initialEntries={["/"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    fireEvent.click(document.querySelector(".app-nav-toggle")!);
    const buttons = document.querySelectorAll(".app-nav-overlay__link");
    const a11yButton = Array.from(buttons).find((b) => b.textContent?.includes("common.accessibility"));
    expect(a11yButton).toBeDefined();
    fireEvent.click(a11yButton!);
    expect(screen.getByTestId("a11y-panel")).toBeDefined();
  });

  it("opens legal modal from overlay privacy button", async () => {
    render(
      <MemoryRouter initialEntries={["/"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    fireEvent.click(document.querySelector(".app-nav-toggle")!);
    const buttons = document.querySelectorAll(".app-nav-overlay__link");
    const privacyButton = Array.from(buttons).find((b) => b.textContent === "public.privacyPolicy");
    expect(privacyButton).toBeDefined();
    fireEvent.click(privacyButton!);
    expect(await screen.findByTestId("legal-modal")).toBeDefined();
  });

  it("opens changelog from overlay version button", async () => {
    render(
      <MemoryRouter initialEntries={["/"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    fireEvent.click(document.querySelector(".app-nav-toggle")!);
    const buttons = document.querySelectorAll(".app-nav-overlay__link");
    const versionButton = Array.from(buttons).find((b) => b.textContent?.includes("common.version"));
    expect(versionButton).toBeDefined();
    fireEvent.click(versionButton!);
    expect(await screen.findByTestId("changelog-modal")).toBeDefined();
  });

  it("renders footer when not editing route", () => {
    render(
      <MemoryRouter initialEntries={["/"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    expect(screen.getAllByText("public.privacyPolicy").length).toBe(2);
    expect(screen.getAllByText("public.terms").length).toBe(2);
    expect(screen.getAllByText("public.legalNotice").length).toBe(2);
  });

  it("shows the 404 page for unknown multi-segment paths", async () => {
    render(
      <MemoryRouter initialEntries={["/random/test"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    expect(await screen.findByTestId("not-found-page")).toBeDefined();
  });

  it("opens legal modal for terms from overlay", async () => {
    render(
      <MemoryRouter initialEntries={["/"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    fireEvent.click(document.querySelector(".app-nav-toggle")!);
    const buttons = document.querySelectorAll(".app-nav-overlay__link");
    const termsButton = Array.from(buttons).find((b) => b.textContent === "public.terms");
    expect(termsButton).toBeDefined();
    fireEvent.click(termsButton!);
    expect(await screen.findByTestId("legal-modal")).toBeDefined();
  });

  it("opens legal modal for legal notice from overlay", async () => {
    render(
      <MemoryRouter initialEntries={["/"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    fireEvent.click(document.querySelector(".app-nav-toggle")!);
    const buttons = document.querySelectorAll(".app-nav-overlay__link");
    const legalButton = Array.from(buttons).find((b) => b.textContent === "public.legalNotice");
    expect(legalButton).toBeDefined();
    fireEvent.click(legalButton!);
    expect(await screen.findByTestId("legal-modal")).toBeDefined();
  });

  it("opens legal modal from footer privacy button", async () => {
    render(
      <MemoryRouter initialEntries={["/"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    const footerButtons = document.querySelectorAll(".app-footer__link");
    const privacyBtn = Array.from(footerButtons).find((b) => b.textContent === "public.privacyPolicy");
    expect(privacyBtn).toBeDefined();
    fireEvent.click(privacyBtn!);
    expect(await screen.findByTestId("legal-modal")).toBeDefined();
  });

  it("opens legal modal from footer terms button", async () => {
    render(
      <MemoryRouter initialEntries={["/"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    const footerButtons = document.querySelectorAll(".app-footer__link");
    const termsBtn = Array.from(footerButtons).find((b) => b.textContent === "public.terms");
    expect(termsBtn).toBeDefined();
    fireEvent.click(termsBtn!);
    expect(await screen.findByTestId("legal-modal")).toBeDefined();
  });

  it("opens legal modal from footer legal button", async () => {
    render(
      <MemoryRouter initialEntries={["/"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    const footerButtons = document.querySelectorAll(".app-footer__link");
    const legalBtn = Array.from(footerButtons).find((b) => b.textContent === "public.legalNotice");
    expect(legalBtn).toBeDefined();
    fireEvent.click(legalBtn!);
    expect(await screen.findByTestId("legal-modal")).toBeDefined();
  });

  it("opens changelog from footer version button", async () => {
    render(
      <MemoryRouter initialEntries={["/"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    const footerButtons = document.querySelectorAll(".app-footer__link");
    const versionBtn = Array.from(footerButtons).find((b) => b.textContent?.includes("common.version"));
    expect(versionBtn).toBeDefined();
    fireEvent.click(versionBtn!);
    expect(await screen.findByTestId("changelog-modal")).toBeDefined();
    // Cerrar el changelog cubre su onClose (arrow del AppShell).
    fireEvent.click(screen.getByRole("button", { name: "close" }));
    await vi.waitFor(() => expect(screen.queryByTestId("changelog-modal")).toBeNull());
  });

  it("opens and closes the data request modal from the footer", async () => {
    render(
      <MemoryRouter initialEntries={["/"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    const footerButtons = document.querySelectorAll(".app-footer__link");
    const dataBtn = Array.from(footerButtons).find((b) => b.textContent === "public.dataRequest");
    expect(dataBtn).toBeDefined();
    fireEvent.click(dataBtn!);
    expect(await screen.findByTestId("data-request-modal")).toBeDefined();
    fireEvent.click(screen.getByRole("button", { name: "close" }));
    await vi.waitFor(() => expect(screen.queryByTestId("data-request-modal")).toBeNull());
  });

  it("renders a11y trigger in admin mode", () => {
    mockUseApp.mockReturnValue({
      ...baseUseApp,
      isAdminTokenLoggedIn: true,
      inviteToken: "abc123",
    });
    render(
      <MemoryRouter initialEntries={["/abc123"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    const adminA11y = document.querySelector(".a11y-trigger--admin");
    expect(adminA11y).toBeDefined();
  });

  it("navigating overlay closes nav", () => {
    render(
      <MemoryRouter initialEntries={["/"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    fireEvent.click(document.querySelector(".app-nav-toggle")!);
    expect(document.querySelector(".app-nav-overlay--open")).toBeDefined();
    const buttons = document.querySelectorAll(".app-nav-overlay__link");
    const privacyButton = Array.from(buttons).find((b) => b.textContent === "public.privacyPolicy")!;
    fireEvent.click(privacyButton);
    expect(document.querySelector(".app-nav-overlay--open")).toBeNull();
  });






  it("does not set the admin username for a short session identifier", () => {
    const sessionMock = (() => {
      let store: Record<string, string> = {};
      return {
        getItem: vi.fn((k: string) => store[k] ?? null),
        setItem: vi.fn((k: string, v: string) => {
          store[k] = v;
        }),
        removeItem: vi.fn((k: string) => {
          delete store[k];
        }),
        clear: vi.fn(() => {
          store = {};
        }),
      };
    })();
    Object.defineProperty(window, "sessionStorage", {
      value: sessionMock,
      configurable: true,
    });
    sessionMock.setItem("wedin_session", JSON.stringify({ identifier: "ab", expiresAt: Date.now() + 99999 }));
    mockUseApp.mockReturnValue(baseUseApp);
    render(
      <MemoryRouter initialEntries={["/"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    expect(screen.getByText("common.skipToContent")).toBeDefined();
    Object.defineProperty(window, "sessionStorage", { value: undefined, configurable: true });
  });

  it("handles corrupted localStorage JSON", () => {
    const sessionMock = (() => {
      let store: Record<string, string> = {};
      return {
        getItem: vi.fn((k: string) => store[k] ?? null),
        setItem: vi.fn((k: string, v: string) => {
          store[k] = v;
        }),
        removeItem: vi.fn((k: string) => {
          delete store[k];
        }),
        clear: vi.fn(() => {
          store = {};
        }),
      };
    })();
    Object.defineProperty(window, "sessionStorage", {
      value: sessionMock,
      configurable: true,
    });
    sessionMock.setItem("wedin_session", "{invalid json}");
    render(
      <MemoryRouter initialEntries={["/"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    expect(screen.getByTestId("landing-page")).toBeDefined();
    Object.defineProperty(window, "sessionStorage", { value: undefined, configurable: true });
  });

  it("handles expired localStorage data", () => {
    const sessionMock = (() => {
      let store: Record<string, string> = {};
      return {
        getItem: vi.fn((k: string) => store[k] ?? null),
        setItem: vi.fn((k: string, v: string) => {
          store[k] = v;
        }),
        removeItem: vi.fn((k: string) => {
          delete store[k];
        }),
        clear: vi.fn(() => {
          store = {};
        }),
      };
    })();
    Object.defineProperty(window, "sessionStorage", {
      value: sessionMock,
      configurable: true,
    });
    sessionMock.setItem("wedin_session", JSON.stringify({ identifier: "user", expiresAt: Date.now() - 1000 }));
    render(
      <MemoryRouter initialEntries={["/"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    expect(screen.getByTestId("landing-page")).toBeDefined();
    Object.defineProperty(window, "sessionStorage", { value: undefined, configurable: true });
  });

  it("handles null localStorage gracefully", () => {
    const sessionMock = (() => {
      let store: Record<string, string> = {};
      return {
        getItem: vi.fn(() => null),
        setItem: vi.fn((k: string, v: string) => {
          store[k] = v;
        }),
        removeItem: vi.fn((k: string) => {
          delete store[k];
        }),
        clear: vi.fn(() => {
          store = {};
        }),
      };
    })();
    Object.defineProperty(window, "sessionStorage", {
      value: sessionMock,
      configurable: true,
    });
    render(
      <MemoryRouter initialEntries={["/"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    expect(screen.getByTestId("landing-page")).toBeDefined();
    Object.defineProperty(window, "sessionStorage", { value: undefined, configurable: true });
  });

  it("renders DEV badge in dev mode", () => {
    render(
      <MemoryRouter initialEntries={["/"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    expect(screen.getByText("DEV")).toBeDefined();
  });

  it("renders changelog modal directly when showChangelog is true", async () => {
    render(
      <MemoryRouter initialEntries={["/"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    fireEvent.click(document.querySelector(".app-nav-toggle")!);
    const buttons = document.querySelectorAll(".app-nav-overlay__link");
    const versionButton = Array.from(buttons).find((b) => b.textContent?.includes("common.version"));
    fireEvent.click(versionButton!);
    expect(await screen.findByTestId("changelog-modal")).toBeDefined();
  });

  it("renders legal modal when legalSection is set via overlay", async () => {
    render(
      <MemoryRouter initialEntries={["/"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    // El nav overlay es async (los modales bajo demanda montan tras el
    // Suspense): se espera a que el toggle exista antes de pulsarlo.
    await vi.waitFor(() => expect(document.querySelector(".app-nav-toggle")).not.toBeNull());
    fireEvent.click(document.querySelector(".app-nav-toggle")!);
    const buttons = document.querySelectorAll(".app-nav-overlay__link");
    const privacyButton = Array.from(buttons).find((b) => b.textContent === "public.privacyPolicy");
    fireEvent.click(privacyButton!);
    expect(await screen.findByTestId("legal-modal")).toBeDefined();
    expect((await screen.findByTestId("legal-modal")).textContent).toContain("privacy");
    // Cerrar el modal cubre su onClose (arrow del AppShell).
    fireEvent.click(screen.getByRole("button", { name: "close" }));
  });

  it("renders accessibility panel when showA11y is true via overlay", () => {
    render(
      <MemoryRouter initialEntries={["/"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    fireEvent.click(document.querySelector(".app-nav-toggle")!);
    const buttons = document.querySelectorAll(".app-nav-overlay__link");
    const a11yButton = Array.from(buttons).find((b) => b.textContent?.includes("common.accessibility"));
    fireEvent.click(a11yButton!);
    expect(screen.getByTestId("a11y-panel")).toBeDefined();
  });

  it("opens accessibility panel from footer a11y trigger", () => {
    render(
      <MemoryRouter initialEntries={["/"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    const footerTrigger = document.querySelector(".app-footer .a11y-trigger");
    expect(footerTrigger).toBeDefined();
    fireEvent.click(footerTrigger!);
    expect(screen.getByTestId("a11y-panel")).toBeDefined();
  });

  it("opens accessibility panel from admin a11y trigger", async () => {
    setAdminMode(true);
    render(
      <MemoryRouter initialEntries={["/"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    // El botón del modo admin existe (el panel completo se prueba en
    // AccessibilityPanel con su propio foco; aquí basta el disparador).
    await vi.waitFor(() => {
      const trigger = document.querySelector(".a11y-trigger--admin");
      expect(trigger).not.toBeNull();
    });
    fireEvent.click(document.querySelector(".a11y-trigger--admin")!);
    expect(screen.getByTestId("a11y-panel")).toBeDefined();
    setAdminMode(false);
  });

  it("handles window error event via logError", async () => {
    const { logError } = await import("../lib/error-utils");
    mockUseApp.mockReturnValue({ ...baseUseApp });
    render(
      <MemoryRouter initialEntries={["/"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    window.dispatchEvent(new ErrorEvent("error", { message: "test error", error: new Error("test") }));
    expect(logError).toHaveBeenCalled();
  });

  it("logs a window error using the message when error is absent", async () => {
    const { logError } = await import("../lib/error-utils");
    mockUseApp.mockReturnValue({ ...baseUseApp });
    render(
      <MemoryRouter initialEntries={["/"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    window.dispatchEvent(new ErrorEvent("error", { message: "plain message" }));
    expect(logError).toHaveBeenCalledWith("plain message", "global");
  });

  it("handles unhandledrejection event via logError", async () => {
    const { logError } = await import("../lib/error-utils");
    mockUseApp.mockReturnValue({ ...baseUseApp });
    render(
      <MemoryRouter initialEntries={["/"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    const reason = new Error("rejected");
    const promise = Promise.reject(reason);
    promise.catch(() => {});
    window.dispatchEvent(new PromiseRejectionEvent("unhandledrejection", { promise, reason }));
    await vi.waitFor(() => {
      expect(logError).toHaveBeenCalledWith(reason, "unhandledRejection");
    });
  });

  it("renders a skip link to main content", () => {
    render(
      <MemoryRouter initialEntries={["/"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    const skipLink = document.querySelector(".skip-link");
    expect(skipLink).not.toBeNull();
    expect(skipLink?.getAttribute("href")).toBe("#main-content");
  });

  it("handles service worker registration in PROD", () => {
    const origEnv = import.meta.env.PROD;
    const registerMock = vi.fn().mockResolvedValue(undefined);
    Object.defineProperty(navigator, "serviceWorker", {
      value: { register: registerMock },
      configurable: true,
    });
    import.meta.env.PROD = true;
    render(
      <MemoryRouter initialEntries={["/"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    expect(registerMock).toHaveBeenCalledWith("/sw.js");
    import.meta.env.PROD = origEnv;
  });

  it("handles service worker registration failure", () => {
    const origEnv = import.meta.env.PROD;
    const registerMock = vi.fn().mockRejectedValue(new Error("register failed"));
    Object.defineProperty(navigator, "serviceWorker", {
      value: { register: registerMock },
      configurable: true,
    });
    import.meta.env.PROD = true;
    render(
      <MemoryRouter initialEntries={["/"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    expect(registerMock).toHaveBeenCalledWith("/sw.js");
    import.meta.env.PROD = origEnv;
  });

  it("does not register service worker in DEV", () => {
    const origEnv = import.meta.env.PROD;
    const registerMock = vi.fn().mockResolvedValue(undefined);
    Object.defineProperty(navigator, "serviceWorker", {
      value: { register: registerMock },
      configurable: true,
    });
    import.meta.env.PROD = false;
    render(
      <MemoryRouter initialEntries={["/"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    expect(registerMock).not.toHaveBeenCalled();
    import.meta.env.PROD = origEnv;
  });

  it("shows the update banner when a new deploy is detected", async () => {
    const meta = document.createElement("meta");
    meta.setAttribute("name", "deploy-id");
    meta.setAttribute("content", "999");
    document.head.appendChild(meta);
    localStorage.setItem("wedin_deploy_id", "111");
    // El aviso de actualización usa safeGetItem: requiere consentimiento de
    // almacenamiento (ePrivacy 5.3).
    localStorage.setItem("wedin_cookie_consent", "accepted");

    render(
      <MemoryRouter initialEntries={["/"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    expect(await screen.findByText("common.updateAvailable")).toBeDefined();
    localStorage.removeItem("wedin_deploy_id");
    localStorage.removeItem("wedin_cookie_consent");
    meta.remove();
  });

  it("does not show the update banner on the first visit", async () => {
    const meta = document.createElement("meta");
    meta.setAttribute("name", "deploy-id");
    meta.setAttribute("content", "555");
    document.head.appendChild(meta);

    render(
      <MemoryRouter initialEntries={["/"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    await screen.findByTestId("landing-page");
    expect(screen.queryByText("common.updateAvailable")).toBeNull();
    localStorage.removeItem("wedin_deploy_id");
    localStorage.removeItem("wedin_cookie_consent");
    meta.remove();
  });

  it("reloads the page when the update banner button is clicked", async () => {
    const meta = document.createElement("meta");
    meta.setAttribute("name", "deploy-id");
    meta.setAttribute("content", "222");
    document.head.appendChild(meta);
    localStorage.setItem("wedin_deploy_id", "111");
    // safeGetItem exige consentimiento de almacenamiento (ePrivacy 5.3).
    localStorage.setItem("wedin_cookie_consent", "accepted");
    const reload = vi.fn();
    Object.defineProperty(window, "location", {
      value: { ...window.location, reload },
      configurable: true,
      writable: true,
    });
    render(
      <MemoryRouter initialEntries={["/"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    const bannerBtn = await screen.findByText("common.reload");
    fireEvent.click(bannerBtn);
    expect(reload).toHaveBeenCalled();
    localStorage.removeItem("wedin_deploy_id");
    localStorage.removeItem("wedin_cookie_consent");
    meta.remove();
  });

  it("adds noindex robots on non-landing routes", async () => {
    render(
      <MemoryRouter initialEntries={["/abc123/admin"]}>
        <Suspense fallback={null}>
          <App />
        </Suspense>
      </MemoryRouter>,
    );
    await screen.findByText("DEV");
    const robots = document.querySelector('meta[name="robots"]');
    expect(robots?.getAttribute("content")).toBe("noindex, nofollow");
    document.querySelectorAll('meta[name="robots"]').forEach((m) => m.remove());
  });
});
