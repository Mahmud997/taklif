import { describe, it, expect, vi, beforeEach } from "vitest";

vi.mock("firebase/firestore", () => ({
  getDocs: vi.fn(() => Promise.resolve({ empty: true, docs: [] })),
  collection: vi.fn(() => "audio-coll-ref"),
  doc: vi.fn(() => ({ id: "audio-doc-id" })),
  writeBatch: vi.fn(() => ({
    set: vi.fn(),
    delete: vi.fn(),
    commit: vi.fn(() => Promise.resolve()),
  })),
  query: vi.fn(),
  orderBy: vi.fn(),
}));

vi.mock("../firebase", () => ({
  db: {},
}));

vi.mock("../crypto-utils", () => ({
  encrypt: vi.fn((data: string) => Promise.resolve(btoa(data))),
  decrypt: vi.fn(() => Promise.resolve("data:audio/mp3;base64,decoded")),
}));

vi.mock("../audio-utils", () => ({
  compressAudio: vi.fn(() => Promise.resolve("data:audio/mp3;base64,...")),
}));

import { getDocs } from "firebase/firestore";
import { uploadAudio, addAudio, loadAudio, deleteAudio, clearAudioCache } from "../music-store";

describe("music-store", () => {
  beforeEach(() => {
    // La caché de módulo de loadAudio (v2.185) es por token y vive entre
    // tests: se limpia para que cada caso aísle lecturas/descifrados reales.
    clearAudioCache();
    vi.clearAllMocks();
  });

  it("exports uploadAudio", () => {
    expect(typeof uploadAudio).toBe("function");
  });
  it("exports addAudio", () => {
    expect(typeof addAudio).toBe("function");
  });
  it("exports loadAudio", () => {
    expect(typeof loadAudio).toBe("function");
  });
  it("exports deleteAudio", () => {
    expect(typeof deleteAudio).toBe("function");
  });

  it("uploadAudio compresses and encrypts", async () => {
    const onProgress = vi.fn();
    const result = await uploadAudio("token", new File([], "test.mp3", { type: "audio/mpeg" }), onProgress);
    expect(result).toHaveProperty("encrypted");
    expect(result).toHaveProperty("dataUrl");
    expect(onProgress).toHaveBeenCalled();
  });

  it("uploadAudio throws on encrypt failure", async () => {
    const mockEncrypt: () => Promise<string | null> = vi.fn(() => Promise.resolve(null));
    (
      vi.mocked((await import("../crypto-utils")).encrypt) as unknown as {
        mockImplementationOnce: (fn: () => Promise<string | null>) => void;
      }
    ).mockImplementationOnce(mockEncrypt);
    await expect(uploadAudio("token", new File([], "test.mp3", { type: "audio/mpeg" }))).rejects.toThrow(
      "Encryption failed",
    );
  });

  it("addAudio chunks and writes to firestore", async () => {
    const onProgress = vi.fn();
    const encrypted = "a".repeat(600 * 1024);
    const result = await addAudio("token", encrypted, "data:audio/mp3;base64,...", onProgress);
    expect(result).toHaveProperty("id");
    expect(result).toHaveProperty("dataUrl");
    expect(result).toHaveProperty("chunks");
    expect(result.chunks).toBeGreaterThan(1);
  });

  it("addAudio clears previous orphan chunks before writing", async () => {
    // Hay chunks viejos de una subida anterior (incompleta).
    vi.mocked(getDocs).mockResolvedValueOnce({
      empty: false,
      docs: [{ ref: { id: "old1" } }, { ref: { id: "old2" } }],
    } as never);
    const result = await addAudio("token", "enc", "data:audio/mp3;base64,...");
    expect(result).toHaveProperty("id");
    // La limpieza (getDocs) se consultó una vez con los chunks previos.
    expect(getDocs).toHaveBeenCalled();
  });

  it("loadAudio returns null when no audio exists", async () => {
    const result = await loadAudio("token");
    expect(result).toBeNull();
  });

  it("loadAudio returns null on error", async () => {
    vi.mocked((await import("firebase/firestore")).getDocs).mockRejectedValueOnce(new Error("Network error"));
    const result = await loadAudio("token");
    expect(result).toBeNull();
  });

  it("deleteAudio resolves", async () => {
    await expect(deleteAudio("token")).resolves.toBeUndefined();
  });

  it("deleteAudio resolves when empty", async () => {
    await expect(deleteAudio("no-audio-token")).resolves.toBeUndefined();
  });

  it("loadAudio decrypts chunks when audio exists", async () => {
    vi.mocked((await import("firebase/firestore")).getDocs).mockResolvedValueOnce({
      empty: false,
      docs: [{ data: () => ({ data: "chunk-data" }) }],
    } as never);
    const result = await loadAudio("token");
    expect(result).not.toBeNull();
    expect(result?.id).toBe("token_audio");
  });

  it("loadAudio returns null when decryption returns falsy", async () => {
    const { decrypt } = await import("../crypto-utils");
    vi.mocked(decrypt as unknown as ReturnType<typeof vi.fn>).mockResolvedValueOnce("");
    vi.mocked((await import("firebase/firestore")).getDocs).mockResolvedValueOnce({
      empty: false,
      docs: [{ data: () => ({ data: "chunk-data" }) }],
    } as never);
    const result = await loadAudio("token");
    expect(result).toBeNull();
  });

  it("deleteAudio deletes docs when audio exists", async () => {
    vi.mocked((await import("firebase/firestore")).getDocs).mockResolvedValueOnce({
      empty: false,
      docs: [{ ref: "doc-ref" }],
    } as never);
    await expect(deleteAudio("token")).resolves.toBeUndefined();
  });
});
