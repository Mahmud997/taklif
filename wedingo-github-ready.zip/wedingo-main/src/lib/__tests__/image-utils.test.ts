import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { compressImage, compressImageTransparent } from "../image-utils";

// ── Mocks del DOM (canvas, Image, FileReader, URL) ─────────────────────
let imgInstance: {
  width: number;
  height: number;
  onload: (() => void) | null;
  onerror: (() => void) | null;
  src: string;
} | null;

const origImage = globalThis.Image;
const origCreateObjectURL = URL.createObjectURL;
const origRevokeObjectURL = URL.revokeObjectURL;

function makeFile(type: string, size: number): File {
  return new File([new ArrayBuffer(size)], "test.jpg", { type });
}

function installCanvasMocks(toDataUrlValue?: string, getCtxValue?: unknown) {
  Object.defineProperty(HTMLCanvasElement.prototype, "getContext", {
    configurable: true,
    value: vi.fn(() => (getCtxValue === undefined ? { drawImage: vi.fn() } : getCtxValue)),
  });
  Object.defineProperty(HTMLCanvasElement.prototype, "toDataURL", {
    configurable: true,
    value: vi.fn(() => (toDataUrlValue === undefined ? "data:image/webp;base64,AAAA" : toDataUrlValue)),
  });
}

function installImageMock(onLoad?: () => void) {
  globalThis.Image = class {
    width = 100;
    height = 100;
    onload: (() => void) | null = null;
    onerror: (() => void) | null = null;
    src = "";
    constructor() {
      imgInstance = this;
      if (onLoad) this.onload = onLoad;
    }
  } as unknown as typeof Image;
}

beforeEach(() => {
  imgInstance = null;
  URL.createObjectURL = vi.fn(() => "blob:mock");
  URL.revokeObjectURL = vi.fn();
  installCanvasMocks();
  installImageMock();
});

afterEach(() => {
  globalThis.Image = origImage;
  URL.createObjectURL = origCreateObjectURL;
  URL.revokeObjectURL = origRevokeObjectURL;
});


describe("compressImage", () => {
  it("uses the fast path for a small JPEG", async () => {
    const file = makeFile("image/jpeg", 100);
    const FakeReader = class {
      result: string | ArrayBuffer = "data:image/jpeg;base64,FAST";
      onload: (() => void) | null = null;
      readAsDataURL() {
        this.onload?.();
      }
      readAsArrayBuffer() {
        // Magic bytes JPEG (FF D8 FF) para validar el fast path.
        this.result = new Uint8Array([0xff, 0xd8, 0xff]).buffer;
        this.onload?.();
      }
    };
    vi.stubGlobal("FileReader", FakeReader);
    installImageMock(() => {});
    const promise = compressImage(file);
    imgInstance?.onload?.();
    await expect(promise).resolves.toBe("data:image/jpeg;base64,FAST");
    vi.unstubAllGlobals();
  });

  it("falls back to the canvas path when a JPEG lacks valid magic bytes", async () => {
    const file = makeFile("image/jpeg", 100);
    const FakeReader = class {
      result: string | ArrayBuffer = "data:image/png;base64,SLOW";
      onload: (() => void) | null = null;
      readAsDataURL() {
        this.onload?.();
      }
      readAsArrayBuffer() {
        // No es JPEG: no debe tomar el fast path.
        this.result = new Uint8Array([0x47, 0x49, 0x46]).buffer;
        this.onload?.();
      }
    };
    vi.stubGlobal("FileReader", FakeReader);
    installCanvasMocks();
    installImageMock(() => {});
    const promise = compressImage(file);
    imgInstance?.onload?.();
    // Al no superar la validación de magic bytes se re-codifica en canvas.
    await expect(promise).resolves.toContain("data:image/webp");
    vi.unstubAllGlobals();
  });

  it("re-encodes a large or non-JPEG image to WebP", async () => {
    const file = makeFile("image/png", 500 * 1024);
    const promise = compressImage(file);
    imgInstance!.width = 2000;
    imgInstance!.height = 2000;
    imgInstance!.onload?.();
    const result = await promise;
    expect(result).toContain("data:image/webp");
  });

  it("shrinks dimensions and reduces quality for oversized images", async () => {
    installCanvasMocks("data:image/webp;base64," + "A".repeat(200000));
    const file = makeFile("image/png", 50 * 1024);
    const promise = compressImage(file);
    imgInstance!.width = 5000;
    imgInstance!.height = 5000;
    imgInstance!.onload?.();
    const result = await promise;
    expect(result).toContain("data:image");
  });

  it("falls back to PNG when WebP is not supported", async () => {
    installCanvasMocks("data:image/png;base64,PNG");
    const file = makeFile("image/png", 500 * 1024);
    const promise = compressImage(file);
    imgInstance!.onload?.();
    const result = await promise;
    expect(result).toContain("data:image/png");
  });

  it("throws when canvas context is unavailable", async () => {
    installCanvasMocks(undefined, null);
    const file = makeFile("image/png", 500 * 1024);
    const promise = compressImage(file);
    imgInstance!.onload?.();
    await expect(promise).rejects.toThrow();
  });

  it("rejects when the image fails to load", async () => {
    const file = makeFile("image/png", 500 * 1024);
    const promise = compressImage(file);
    imgInstance!.onerror?.();
    await expect(promise).rejects.toThrow();
  });
});

describe("compressImageTransparent", () => {
  it("compresses and preserves the data URL", async () => {
    const file = makeFile("image/webp", 500 * 1024);
    const promise = compressImageTransparent(file);
    imgInstance!.onload?.();
    const result = await promise;
    expect(result).toContain("data:image/webp");
  });

  it("does not downscale a small PNG (no reduction paths)", async () => {
    const file = makeFile("image/png", 10 * 1024);
    const promise = compressImage(file);
    imgInstance!.onload?.();
    const result = await promise;
    expect(result).toContain("data:image");
  });

  it("keeps a small transparent image without reducing quality", async () => {
    const file = makeFile("image/png", 10 * 1024);
    const promise = compressImageTransparent(file);
    imgInstance!.onload?.();
    const result = await promise;
    expect(result).toContain("data:image");
  });

  it("downscales only the oversized dimension", async () => {
    const file = makeFile("image/png", 500 * 1024);
    const promise = compressImageTransparent(file);
    imgInstance!.width = 100;
    imgInstance!.height = 3000;
    imgInstance!.onload?.();
    const result = await promise;
    expect(result).toContain("data:image");
  });

  it("reduces quality when the image exceeds the target size", async () => {
    // Una cadena grande para forzar estimatedBytes > TARGET_BYTES.
    const bigData = "data:image/webp;base64," + "A".repeat(600 * 1024);
    installCanvasMocks(bigData);
    const file = makeFile("image/webp", 600 * 1024);
    const promise = compressImageTransparent(file);
    imgInstance!.onload?.();
    const result = await promise;
    expect(result).toContain("data:image");
  });

  it("degrades to PNG when the canvas cannot encode WebP", async () => {
    // canvasToType re-encodea a PNG cuando el prefijo del dataURL no coincide
    // con el tipo pedido (navegadores sin soporte real de toDataURL webp).
    installCanvasMocks();
    const pngOnly = vi.fn(() => "data:image/png;base64,ZZ");
    HTMLCanvasElement.prototype.toDataURL = pngOnly as typeof HTMLCanvasElement.prototype.toDataURL;
    const promise = compressImage(makeFile("image/png", 500 * 1024));
    imgInstance!.onload?.();
    const result = await promise;
    expect(result.startsWith("data:image/png")).toBe(true);
  });

  it("iterates the quality ladder and shrinks oversized encodes", async () => {
    // Con un objetivo minúsculo (targetBytes=10) ningún encode cabe: cubre el
    // bucle de calidad (0.7→0.1) y shrinkToFit reduciendo dimensiones ×0.75
    // hasta que el lienzo queda bajo el mínimo de 200px.
    installCanvasMocks();
    const alwaysWebp = vi.fn(() => "data:image/webp;base64," + "A".repeat(4000));
    HTMLCanvasElement.prototype.toDataURL = alwaysWebp as typeof HTMLCanvasElement.prototype.toDataURL;
    // imgInstance solo existe tras llamar a compressImage (ahí se construye el
    // Image); dimensionamos el lienzo simulado antes de disparar el onload.
    const promise = compressImage(makeFile("image/jpeg", 500 * 1024), 1600, 10);
    imgInstance!.width = 1000;
    imgInstance!.height = 1000;
    imgInstance!.onload?.();
    const result = await promise;
    expect(result).toContain("webp");
    // ~7 llamadas del escalado de calidad + ~7 del encogido de dimensiones.
    expect(alwaysWebp.mock.calls.length).toBeGreaterThan(12);
  });
});
