import { describe, it, expect, vi, beforeEach } from "vitest";
import { getFirestoreErrorMessage, logError } from "../error-utils";

const mockCaptureException = vi.hoisted(() => vi.fn());
vi.mock("@sentry/react", () => ({
  captureException: (...args: unknown[]) => mockCaptureException(...args),
}));

describe("getFirestoreErrorMessage", () => {
  it("returns message for known error codes", () => {
    const t = (key: string) => key;
    expect(getFirestoreErrorMessage({ code: "permission-denied" }, t)).toBe("errors.permissionDenied");
    expect(getFirestoreErrorMessage({ code: "unavailable" }, t)).toBe("errors.serviceUnavailable");
    expect(getFirestoreErrorMessage({ code: "not-found" }, t)).toBe("errors.notFound");
  });

  it("returns message for all known error codes", () => {
    const t = (key: string) => key;
    const codeMap: Record<string, string> = {
      "permission-denied": "errors.permissionDenied",
      unavailable: "errors.serviceUnavailable",
      "not-found": "errors.notFound",
      "deadline-exceeded": "errors.timeout",
      "resource-exhausted": "errors.quotaExceeded",
      "already-exists": "errors.alreadyExists",
      "failed-precondition": "errors.failedPrecondition",
      aborted: "errors.aborted",
      unauthenticated: "errors.unauthenticated",
    };
    Object.entries(codeMap).forEach(([code, expected]) => {
      expect(getFirestoreErrorMessage({ code }, t)).toBe(expected);
    });
  });

  it("returns default message for unknown codes", () => {
    const t = (key: string) => key;
    const error = new Error("Something broke");
    expect(getFirestoreErrorMessage(error, t)).toBe("Something broke");
  });

  it("returns error message without translation function", () => {
    expect(getFirestoreErrorMessage({ code: "permission-denied" })).toBe("Permission denied");
    expect(getFirestoreErrorMessage(new Error("Oops"))).toBe("Oops");
  });

  it("returns string representation for non-Error objects", () => {
    expect(getFirestoreErrorMessage("just a string")).toBe("just a string");
    expect(getFirestoreErrorMessage(42)).toBe("42");
  });

  it("returns default for empty error object", () => {
    expect(getFirestoreErrorMessage({})).toBe("[object Object]");
  });
});

describe("logError", () => {
  beforeEach(() => {
    vi.restoreAllMocks();
    // Consentimiento de analítica: el fetch a Sentry está gateado por él.
    Object.defineProperty(globalThis, "localStorage", {
      value: {
        getItem: (k: string) =>
          k === "wedin_cookie_consent" ? "accepted" : k === "wedin_cookie_prefs" ? '{"analytics":true}' : null,
        setItem: () => {},
        removeItem: () => {},
        clear: () => {},
      },
      configurable: true,
    });
  });

  it("logs an Error to console.error in DEV", () => {
    const err = new Error("test error");
    const consoleSpy = vi.spyOn(console, "error").mockImplementation(() => {});
    logError(err, "TestContext");
    expect(consoleSpy).toHaveBeenCalledWith("[TestContext]", "test error", expect.stringContaining("test error"));
  });

  it("logs a string to console.error in DEV", () => {
    const consoleSpy = vi.spyOn(console, "error").mockImplementation(() => {});
    logError("string error", "Ctx");
    expect(consoleSpy).toHaveBeenCalledWith("[Ctx]", "string error", "");
  });

  it("uses 'App' as default context", () => {
    const consoleSpy = vi.spyOn(console, "error").mockImplementation(() => {});
    logError(new Error("e"));
    expect(consoleSpy).toHaveBeenCalledWith("[App]", "e", expect.any(String));
  });

  it("sends error to Sentry when SENTRY_DSN is set", async () => {
    vi.resetModules();
    vi.stubEnv("VITE_SENTRY_DSN", "https://sentry.example.com/123");
    const { logError: sentryLogError } = await import("../error-utils");
    sentryLogError(new Error("sentry error"), "SentryCtx");
    await new Promise((r) => setTimeout(r, 10));
    expect(mockCaptureException).toHaveBeenCalled();
    vi.unstubAllEnvs();
  });

  it("handles Sentry capture failure gracefully", async () => {
    vi.resetModules();
    vi.stubEnv("VITE_SENTRY_DSN", "https://sentry.example.com/123");
    mockCaptureException.mockImplementationOnce(() => {
      throw new Error("Sentry failed");
    });
    const { logError: sentryLogError } = await import("../error-utils");
    expect(() => sentryLogError(new Error("err"))).not.toThrow();
    vi.unstubAllEnvs();
  });

  it("handles synchronous fetch throw in Sentry path", async () => {
    vi.resetModules();
    vi.stubEnv("VITE_SENTRY_DSN", "https://sentry.example.com/123");
    const fetchSpy = vi.spyOn(globalThis, "fetch").mockImplementation(() => {
      throw new Error("Sync fetch fail");
    });
    const { logError: sentryLogError } = await import("../error-utils");
    expect(() => sentryLogError(new Error("err"))).not.toThrow();
    fetchSpy.mockRestore();
    vi.unstubAllEnvs();
  });

  it("skips Sentry when SENTRY_DSN is empty", async () => {
    vi.resetModules();
    vi.stubEnv("VITE_SENTRY_DSN", "");
    const fetchSpy = vi.spyOn(globalThis, "fetch");
    const { logError: sentryLogError } = await import("../error-utils");
    sentryLogError(new Error("err"));
    expect(fetchSpy).not.toHaveBeenCalled();
    fetchSpy.mockRestore();
    vi.unstubAllEnvs();
  });

  it("does not log to console.error when not in DEV mode", async () => {
    vi.resetModules();
    vi.stubEnv("DEV", false);
    const consoleSpy = vi.spyOn(console, "error").mockImplementation(() => {});
    const { logError } = await import("../error-utils");
    logError(new Error("should not appear"), "Test");
    expect(consoleSpy).not.toHaveBeenCalled();
    consoleSpy.mockRestore();
    vi.unstubAllEnvs();
  });
});
